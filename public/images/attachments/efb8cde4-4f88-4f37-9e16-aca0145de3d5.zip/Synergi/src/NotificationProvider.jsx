import { ToastContainer } from "react-toastify";

const NotificationProvider = () => {
  return (
    <ToastContainer
      hideProgressBar
      pauseOnHover
      closeOnClick={true}
      theme='light'
      limit={10}
    />
  );
};

export default NotificationProvider;
