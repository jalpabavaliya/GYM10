export const API_URL =
  "https://41s4mwjcib.execute-api.us-east-1.amazonaws.com/v1/";

// segment api config
export const POST_CREATE_SEGMENT_API = API_URL + "create";
export const DELETE_SEGMENT_API =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/delete_item";
export const POST_SEGMENT_CUSTOM_ADD_CONDITION_API =
  API_URL + "segment_offer_custom_add_condition";
export const GET_TOP_PERFORMING_SEGMENT_API =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_top_performing_KPI";
export const GET_SEGMENT_HISTORICAL_EVENT_DATA_API =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_historical_event_data";
export const GET_SEGMENT_CONDITION_COLUMNS_API =
  API_URL + "segment_offer_condition_columns";
export const GET_AI_CRAFTED_SEGMENT_API =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/get_all_ai_created_segments_or_offers";
export const POST_AI_CRAFTED_SEGMENT_CREATE_API =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/segment_offer_ai_create";

// offer api config
export const POST_CREATE_OFFER_API = API_URL + "create";
export const DELETE_OFFER_API =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/delete_item";
export const POST_OFFER_CUSTOM_ADD_CONDITION_API =
  API_URL + "segment_offer_custom_add_condition";
export const POST_OFFER_CUSTOM_UPDATE_ADD_START_END_TIME_API =
  API_URL + "offer_custom_update_add_start_end_time";
export const GET_TOP_PERFORMING_OFFER_API =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_top_performing_KPI";
export const GET_OFFER_HISTORICAL_EVENT_DATA_API =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_historical_event_data";
export const GET_OFFER_CONDITION_COLUMNS_API =
  API_URL + "segment_offer_condition_columns";
export const GET_AI_CRAFTED_OFFER_API =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/get_all_ai_created_segments_or_offers";
export const POST_AI_CRAFTED_OFFER_CREATE_API =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/segment_offer_ai_create";

/* Imports */
// export const GET_TYPES_OF_UPLOAD = API_URL + "mapping_tables";
export const GET_TYPES_OF_UPLOAD =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/mapping_tables";

export const GET_HISTORICAL_EVENT_DATA =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_historical_event_data";

export const GET_TOP_PERFORMING_KPI =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_top_performing_KPI";

export const POST_FILE_TO_S3 =
  " https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/document_upload_to_s3";

export const POST_MAPPED_DOCUMENT =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/document_mapping_and_restore";

export const POST_DOCUMENT_UPDATE_WITH_SLECTED_CHANNELS =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/document_update_with_selected_channels";

/* Campaigns */
export const POST_CREATE_CAMPAIGN_ID_API =
  "https://9isknipkab.execute-api.us-east-1.amazonaws.com/v1/create_campaign_id";

export const GET_AI_API_WITH_KPI =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_historical_event_data";

export const GET_SEGMENT_AI_API =
  "https://9isknipkab.execute-api.us-east-1.amazonaws.com/v1/campaign_ai_segments";

export const GET_SEGMENT_OFFER_API =
  "https://9isknipkab.execute-api.us-east-1.amazonaws.com/v1/segment_offers";

export const GET_SUMMARY_SEGMENT_OFFER_API =
  "https://9isknipkab.execute-api.us-east-1.amazonaws.com/v1/add_data_source_or_segment_2_campaign";

export const GET_ABOUT_CAMPAIGN_API =
  "https://9isknipkab.execute-api.us-east-1.amazonaws.com/v1/get_campaign_objective_channel_vendors";

export const GET_FINALIZE_AND_CONFIRM_API =
  "https://9isknipkab.execute-api.us-east-1.amazonaws.com/v1/add_segment_offers_campagin";

/* All Campaigns */

export const GET_MANAGE_ALL_CAMPAIGN_API =
  "https://29hmzepz60.execute-api.us-east-1.amazonaws.com/v1/get_historical_event_data";


export const POST_MANAGE_ALL_CAMPAIGN_API =
  " https://9isknipkab.execute-api.us-east-1.amazonaws.com/v1/update_campaign_channel_offer_segment";

/* Exprot Data */
export const GET_ALL_EXPORTS =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/export_get_all";

export const DOWNLOD_S3_FILE =
  "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/export_file_download";

