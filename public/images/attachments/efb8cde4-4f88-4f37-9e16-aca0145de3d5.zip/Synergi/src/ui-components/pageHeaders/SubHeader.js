import { Box, Grid } from "@mui/material";
import React from "react";
import KeyboardArrowLeftOutlinedIcon from "@mui/icons-material/KeyboardArrowLeftOutlined";
import "../../view/style.css";
import IconDropdown from "./IconDropdown";
import { useNavigate } from "react-router-dom";

const HEADERGRID = {
  "Sales Pipeline": "$789M",
  "Conversion Rate": "34%",
  "Cost/Lead": "$23.56",
  "Lead Volume": "25.26K",
  ROI: "0.1812%",
};

const SubHeader = ({ title }) => {
  const navigate = useNavigate();
  const MenuOperations = [
    {
      // icon: <KeyboardArrowLeftOutlinedIcon fontSize="small" />,
      name: "Marketing Automation",
    },
    {
      // icon: <KeyboardArrowLeftOutlinedIcon fontSize="small" />,
      name: "Customer Data Intelligence",
    },
    {
      // icon: <KeyboardArrowLeftOutlinedIcon fontSize="small" />,
      name: "AI Modeling Platform",
    },
  ];

  const onMenuItemClick = ({ selectedOption }) => {
    switch (selectedOption.name) {
      case "Marketing Automation":
        navigate("/OnBoarding");
        break;
      case "Customer Data Intelligence":
        navigate("/CustmerDataintelligence");
        break;
      case "AI Modeling Platform":
        break;
      default:
      // invalid option
    }
  };

  return (
    <Grid container>
      <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}>
        {/* <List
          component="div"
          disablePadding
          sx={{
            width: "100%",
            maxWidth: 280,
            minWidth: 280,
            bgcolor: "background.paper",
            borderRadius: "0px 8px 8px 0px",
          }}
        >
          <ListItemButton sx={{ "&:hover": { bgcolor: "background.paper" } }}>
            <ListItemIcon>
              <img src={Group_Icon} alt="Group Icon" />
            </ListItemIcon>
            {<ListItemText primary="My Synergi" />}
            {<KeyboardArrowLeftOutlinedIcon />}
          </ListItemButton>
        </List> */}
        <IconDropdown
          onMenuClick={onMenuItemClick}
          options={MenuOperations}
          keyField="name"
        />
      </Grid>
      <Grid item xs={12} sm={8.6} md={8.6} lg={9.6}>
        <Grid
          container
          justifyContent="space-between"
          alignItems="center"
          spacing={2}
        >
          <Grid
            item
            className="headerText"
            style={{
              marginLeft: "4vh",
              color: "var(--c-ol-1, #3E004A)",
              fontSize: "26px",
            }}
          >
            {title}
          </Grid>
          <Grid item className="GridComp">
            <Grid container spacing={1}>
              {Object.entries(HEADERGRID).map(([key, value]) => (
                <Grid item xs={12 / Object.keys(HEADERGRID).length}>
                  <Box>
                    <div
                      className="grid-content-key"
                      style={{ fontSize: "14px" }}
                      key={key}
                    >
                      {key}
                    </div>
                    <br />
                    <div className="grid-content-value" key={value}>
                      {value}
                    </div>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default SubHeader;
