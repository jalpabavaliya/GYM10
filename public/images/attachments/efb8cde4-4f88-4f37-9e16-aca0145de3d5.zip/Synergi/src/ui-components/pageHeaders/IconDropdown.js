import {
  Box,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Tooltip,
} from "@mui/material";
import React, { useState } from "react";
import PropTypes from "prop-types";
import Group_Icon from "../../assets/Group_Icon.svg";
import KeyboardArrowLeftOutlinedIcon from "@mui/icons-material/KeyboardArrowLeftOutlined";
import { FormattedMessage } from "react-intl";

const IconDropdown = ({ options, onMenuClick, keyField, index }) => {
  const [anchorEl, setAnchorEl] = useState(null);

  const openButton = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = (e) => {
    setAnchorEl(null);
  };

  return (
    <>
      <Box sx={{
        width: "96%",
      }}>
        <Tooltip title="Menu settings">
          <List
            component="div"
            disablePadding
            sx={{
              width: "100%",
              // maxWidth: 280,
              // minWidth: 280,
              bgcolor: "background.paper",
              borderRadius: "0px 8px 8px 0px",
            }}
          >
            <ListItemButton
              sx={{ "&:hover": { bgcolor: "background.paper" } }}
              onClick={handleClick}
            >
              <ListItemIcon>
                <img src={Group_Icon} alt="Group Icon" />
              </ListItemIcon>
              {<ListItemText primary="My Synergi" />}
              {<KeyboardArrowLeftOutlinedIcon />}
            </ListItemButton>
          </List>
        </Tooltip>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={openButton}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        {options.map((opt, idx) => (
          <MenuItem
            key={idx}
            sx={{ p: 1, px: 5 }}
            onClick={() => onMenuClick({ selectedOption: opt, index })}
            value={opt[keyField]}
          >
            {/* <ListItemIcon>{opt.icon ? opt.icon : ""}</ListItemIcon> */}
            <ListItemText primary={opt[keyField]} />
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

IconDropdown.propTypes = {
  options: PropTypes.array,
  onMenuClick: PropTypes.func,
  keyField: PropTypes.string,
};

export default IconDropdown;
