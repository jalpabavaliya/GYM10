import {
  Badge,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  Menu,
  MenuItem,
  IconButton,
  ListItemIcon,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import PermIdentityIcon from "@mui/icons-material/PermIdentity";
import LogoutIcon from "@mui/icons-material/Logout";
import "../../view/style.css";
import { CognitoUserPool } from "amazon-cognito-identity-js";
import SettingsIcon from "@mui/icons-material/Settings";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";

const containerStyle = {
  display: "flex",
  alignItems: "center",
  marginLeft: "2vh",
};

const containerProfileStyle = {
  display: "flex",
  alignItems: "center",
  marginLeft: "2vh",
  marginRight: "4vh",
};

const Header = () => {
  const navigate = useNavigate();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClickCreate = () => {};

  const handleLogout = () => {
    setDialogOpen(true);
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const closeDialog = () => {
    setDialogOpen(false);
  };

  const handleProfileClick = () => {
    navigate("/Setting");
    console.log("Profile clicked!");
    handleMenuClose();
  };

  const handleNotificationsClick = () => {
    console.log("Notifications clicked!");
    handleMenuClose();
  };

  const handleLogoutConfirmed = async () => {
    setDialogOpen(false);

    const userPool = new CognitoUserPool({
      UserPoolId: "us-east-1_lSBztqHit",
      ClientId: "3bcfutrtvoh4fn838l4a6qfl6v",
    });

    const currentUser = userPool.getCurrentUser();

    if (currentUser) {
      currentUser.signOut();
      navigate("/login");
    }
  };

  return (
    <Grid
      container
      justifyContent="space-between"
      alignItems="center"
      sx={{ p: 1, bgcolor: "background.paper" }}
    >
      <Grid item>
        <Grid container justifyContent="flex-start" alignItems="center">
          <Grid item className="LeftSide">
            <img
              alt="header"
              style={{
                marginLeft: "1.7vh",
                height: "4.43vh",
                width: "17.60vh",
              }}
              src="https://generation-sessions.s3.amazonaws.com/c2fdc9dc1907f3591108e718a8db0a65/img/image-255@2x.png"
            />
          </Grid>
          <Grid item>
            {/* <Button
              type="submit"
              variant="outlined"
              onClick={handleClickCreate}
              style={{
                marginLeft: "20vh",
                color: "var(--col-12, #FFF)",
                textAlign: "center",
                fontFamily: "DM Sans",
                fontSize: "14px",
                lineHeight: "normal",
                letterSpacing: "0.45vh",
                width: "12.95vh",
                height: "4.3vh",
                borderRadius: "0.65vh",
                background: "#3E004A",
                border: "1px solid var(--col-12, #3E004A)",
                textTransform: "capitalize",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              + Create
            </Button> */}
          </Grid>
        </Grid>
      </Grid>
      <Grid item>
        <Grid container justifyContent="flex-start">
          <Grid item>{/* SearchBar component */}</Grid>
          {/* <Grid item style={containerStyle}>
            <Badge badgeContent={2} color="error">
              <NotificationsNoneIcon />
            </Badge>
          </Grid> */}
          {/* <Grid item style={containerProfileStyle}>
            <PermIdentityIcon />
          </Grid> */}
          <Grid item>
            {/* <Button onClick={handleLogout} color="secondary">
              <LogoutIcon />
            </Button> */}
            <Grid item sx={{ marginRight: "30px" }}>
              <IconButton onClick={handleMenuOpen} color="secondary">
                <SettingsIcon />
              </IconButton>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Dialog open={dialogOpen} onClose={closeDialog}>
        <DialogTitle>Confirm Logout</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to log out?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeDialog} color="secondary">
            Cancel
          </Button>
          <Button onClick={handleLogoutConfirmed} color="secondary">
            Logout
          </Button>
        </DialogActions>
      </Dialog>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleProfileClick} style={{ marginBottom: "8px" }}>
          <ListItemIcon>
            <AccountCircleIcon color="secondary" />
          </ListItemIcon>
          <Typography variant="inherit">Profile</Typography>
        </MenuItem>
        <MenuItem
          onClick={handleNotificationsClick}
          style={{ marginBottom: "8px" }}
        >
          <ListItemIcon>
            <NotificationsActiveIcon color="secondary" />
          </ListItemIcon>
          <Typography variant="inherit">Notifications</Typography>
        </MenuItem>
        <MenuItem onClick={handleLogout}>
          <ListItemIcon>
            <LogoutIcon color="secondary" />
          </ListItemIcon>
          <Typography variant="inherit">Log Out</Typography>
        </MenuItem>
      </Menu>
    </Grid>
  );
};

export default Header;
