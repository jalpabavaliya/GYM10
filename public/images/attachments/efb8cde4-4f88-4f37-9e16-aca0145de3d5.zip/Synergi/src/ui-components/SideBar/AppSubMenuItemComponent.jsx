import { Button, ListItem } from "@mui/material";
import React, { forwardRef } from "react";
import { NavLink } from "react-router-dom";

const AppSubMenuItemComponent = ({
  link,
  style,
  name,
  title,
  onClick,
  children,
}) => {
  if (!link || typeof link !== "string") {
    return (
      <ListItem style={style} disablePadding onClick={() => onClick(name)}>
        {children}
      </ListItem>
    );
  }

  return (
    <ListItem
      style={style}
      disablePadding
      component={forwardRef((props, ref) => (
        <Button
          {...props}
          innerRef={ref}
          onClick={() => onClick(name)}
          sx={{ color: "#852598" }}
        />
      ))}
      to={link}
    >
      {children}
    </ListItem>
  );
};

export default AppSubMenuItemComponent;
