import React, { useEffect, useState } from "react";
import AppMenuItemComponent from "./AppMenuItemComponent";
import {
  Box,
  Collapse,
  Divider,
  List,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import AppSubMenuItemComponent from "./AppSubMenuItemComponent";
import { Navigate, useNavigate, useLocation } from "react-router-dom";

const AppMenuItem = ({
  title,
  name,
  icon,
  whiteIcon,
  link,
  items = [],
  selectedMenu,
  setSelectedMenu,
  selectedIndex,
  setSelectedIndex,
}) => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [selectedSubMenu, setSelectedSubMenu] = useState("");
  const location = useLocation();
  const currentPath = location.pathname;

  const isExpandable = items && items.length > 0;

  const handleClick = (name) => {
    if (selectedMenu === name) {
      return;
    } else {
      setSelectedMenu(name);
      setSelectedSubMenu("");
      localStorage.setItem("selectedMenu", name); // Save to local storage
    }
    if (selectedIndex !== null) {
      setSelectedIndex(null);
    }
  };

  const handleSelectSubMenu = (name, itemLink) => {
    if (!itemLink) {
      return;
    }
    setSelectedSubMenu(name);
    localStorage.setItem("selectedMenu", name); // Save to local storage
    setSelectedIndex(null);
    navigate(`/${name}`);
  };

  useEffect(() => {
    if (selectedIndex !== null) {
      setSelectedMenu(name); // Open the menu if an index is selected
    }
  }, [selectedIndex, name]);

  useEffect(() => {
    const savedMenu = localStorage.getItem("selectedMenu");
    if (savedMenu) {
      setSelectedMenu(savedMenu);
    }

    // Use the currentPath to determine which submenu should be open
    items.forEach((item) => {
      if (currentPath.includes(item.link)) {
        setSelectedMenu(name);
        setSelectedSubMenu(item.name);
      }
    });
  }, []);

  return (
    <React.Fragment>
      {/* Menu */}
      <AppMenuItemComponent
        link={link}
        onClick={() => handleClick(name)}
        name={name}
        style={
          selectedMenu === name
            ? {
                width: "100%",
                backgroundColor: "#3e004a",
                borderRadius: "8px",
                color: "#ffffff",
                "&:hover": { backgroundColor: "#3e004a", color: "#ffffff" },
              }
            : {
                "&:hover": { bgcolor: "background.paper", borderRadius: "8px" },
              }
        }
      >
        <ListItemIcon style={{ minWidth: "2rem" }}>
          {selectedMenu === name ? whiteIcon : icon}
        </ListItemIcon>
        <ListItemText primary={title} />
        {isExpandable && selectedMenu !== name && <ExpandMore />}
        {isExpandable && selectedMenu === name && <ExpandLess />}
      </AppMenuItemComponent>

      {/* Sub Menu */}
      {isExpandable ? (
        <Collapse in={selectedMenu === name} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            {items.map((item, index) => (
              <AppSubMenuItemComponent
                {...item}
                key={index}
                onClick={() => handleSelectSubMenu(item.name, item.link)}
                style={{
                  padding: "0",
                  paddingLeft: "4rem",
                  width: "100%",
                  textTransform: "capitalize",
                  cursor: !item.link ? "not-allowed" : "pointer",
                }}
                disabled={!item.link}
              >
                <Box
                  sx={{
                    width: "1rem",
                    height: "1rem",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {selectedSubMenu === item.name && (
                    <Box
                      sx={{
                        bgcolor: "#3e004a",
                        height: "5px",
                        width: "5px",
                        borderRadius: "100%",
                      }}
                    />
                  )}
                </Box>
                <ListItemText primary={item.title} />
              </AppSubMenuItemComponent>
            ))}
          </List>
        </Collapse>
      ) : null}
    </React.Fragment>
  );
};

export default AppMenuItem;
