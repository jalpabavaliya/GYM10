import { useNavigate } from "react-router-dom";

function PrivateRouteContent({ children, isAuthenticated }) {
  const navigate = useNavigate();

  if (!isAuthenticated) {
    navigate('/login');
    return null;  // or return some kind of placeholder/loading component if you wish
  }

  return children;
}

export default PrivateRouteContent;