/* eslint-disable react-hooks/exhaustive-deps */
import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import Header from "../ui-components/pageHeaders/Header";
import SubHeader from "../ui-components/pageHeaders/SubHeader";
import MainFooter from "../view/mainFooter/MainFooter";
import Dashboard from "../assets/360 Dashboard.svg";
import Campaigns from "../assets/Campaigns.svg";
import Integration from "../assets/Integration.svg";
import Segments from "../assets/Segments.svg";
import Offers from "../assets/Offers.svg";
import Reports from "../assets/Reports.svg";
import Dashboard_White from "../assets/360 Dashboard_White.svg";
import Campaigns_White from "../assets/Campaigns_White.svg";
import Integration_White from "../assets/Integration_White.svg";
import Segments_White from "../assets/Segments_White.svg";
import Offers_White from "../assets/Offers_White.svg";
import Reports_White from "../assets/Reports_White.svg";
import { Navigate, Outlet, useLocation, useNavigate } from "react-router-dom";
import AppMenu from "../ui-components/SideBar/AppMenu";
import Loader from "../view/integration/Components/Loader";

const Icon = ({ icon, alt }) => <img src={icon} alt={alt} />;

const Layout = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const getSubheaderTitle = () => {
    const pathname = location.pathname;
    switch (pathname) {
      case "/all-campaigns":
        return "AllCampaigns";
      case "/new-campaign":
        return "Campaigns";
      case "/app-integrations":
        return "Integrations";
      case "/segments":
        return "Segments";
      case "/offers":
        return "Offers";
      case "/OnBoarding":
        return "On Boarding";
      case "/CustmerDataintelligence":
        return "Custmer Data Intelligence";
      case "/funnel":
        return "Funnel";
        case "/Setting":
        return "Setting";
      // Add more cases as needed...
      default:
        return "Integration"; // Default title
    }
  };

  const subheaderTitle = getSubheaderTitle();

  const appMenuItems = [
    {
      title: "360 Dashboard",
      name: "dashboard",
      // link: "/dashboard",
      icon: <Icon icon={Dashboard} alt='Group Icon' />,
      whiteIcon: <Icon icon={Dashboard_White} alt='Reports Icon' />,
      items: [
        {
          title: "Funnel",
          name: "funnel",
          link: "funnel",
        },
        {
          title: "Channels",
          name: "channels",
        },
        {
          title: "Campaigns",
          name: "campaigns",
        },
        {
          title: "Industry Comparison",
          name: "industry-comparison",
        },
      ],
    },
    {
      title: "Campaigns",
      name: "Campaigns",
      icon: <Icon icon={Campaigns} alt='Group Icon' />,
      whiteIcon: <img src={Campaigns_White} alt='Group Icon' />,
      items: [
        {
          title: "All Campaigns",
          name: "all-campaigns",
          link: "/all-campaigns",
        },
        {
          title: "New Campaign",
          name: "new-campaign",
          link: "/new-campaign",
        },
        {
          title: "Draft",
          name: "draft",
        },
        {
          title: "Completed",
          name: "completed",
        },
      ],
    },
    {
      title: "Integrations",
      name: "integrations",
      icon: <Icon icon={Integration} alt='Group Icon' />,
      whiteIcon: <Icon icon={Integration_White} alt='Reports Icon' />,
      items: [
        {
          title: "App Integrations",
          name: "app-integrations",
          link: "/app-integrations",
        },
        { title: "Imports", name: "imports", link: "/imports" },
        {
          title: "Exports",
          name: "exports",
          link: "/exports",
        },
      ],
    },
    {
      title: "Segments",
      name: "segments",
      icon: <Icon icon={Segments} alt='Group Icon' />,
      whiteIcon: <Icon icon={Segments_White} alt='Reports Icon' />,
      items: [
        {
          title: "All Segments",
          name: "segments",
          link: "/segments",
        },
        {
          title: "New Segments",
          name: "new-segments",
        },
      ],
    },
    {
      title: "Offers",
      name: "offers",
      icon: <Icon icon={Offers} alt='Group Icon' />,
      whiteIcon: <Icon icon={Offers_White} alt='Reports Icon' />,
      items: [
        {
          title: "All Offers",
          name: "offers",
          link: "/offers",
        },
        {
          title: "New Offers",
          name: "new-offers",
        },
      ],
    },
    {
      title: "Reports(Coming Soon)",
      name: "reports",
      icon: <Icon icon={Reports} alt='Group Icon' />,
      whiteIcon: <Icon icon={Reports_White} alt='Reports Icon' />,
    },
  ];

  const [selectedMenu, setSelectedMenu] = React.useState("");
  const [selectedIndex, setSelectedIndex] = React.useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const acessToken = localStorage.getItem("accessToken");
    console.log("ACESS TOKEN", acessToken);
    if (acessToken) setIsAuthenticated(true);
    else navigate("/");
  }, []);

  return (
    <Grid container direction='column' sx={{ backgroundColor: {lg:"#FAF8F7",md:"#FAF8F7",xs:"#fff"} }}>
      <Grid item>
        <Header />
      </Grid>
      <Grid item sx={{ mt: "10px", mb: "5px" }}>
        <SubHeader title={subheaderTitle} />
      </Grid>
      <Grid item>
        <Grid container spacing={2}>
          <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}>
            {/* <SideBar /> */}
            <AppMenu
              appMenuItems={appMenuItems}
              selectedMenu={selectedMenu}
              setSelectedMenu={setSelectedMenu}
              selectedIndex={selectedIndex} // Pass the selected index
              setSelectedIndex={setSelectedIndex} // Pass the setSelectedIndex function
            />
          </Grid>
          <Grid
            item
            xs={12}
            sm={8.6}
            md={8.6}
            lg={9.6}
            sx={{
              borderRadius: 2,
              display: "flex",
              flexDirection: "column",
              rowGap: "1rem",
            }}
          >
            {isAuthenticated ? <Outlet /> : <Loader />}
          </Grid>
        </Grid>
      </Grid>
      <Grid item sx={{ paddingLeft: {lg:"35vh",md:"35vh",xs:"0vh"} }}>
        <MainFooter />
      </Grid>
    </Grid>
  );
};

export default Layout;
