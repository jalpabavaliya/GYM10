import { Utils as QbUtils, MuiConfig } from "@react-awesome-query-builder/mui";
import { workflowAutomationActions } from "../slices/rules";
import { getFieldList } from "../../view/offers/Components/workFlow/Step2_SetRule";
import { getUserFields } from "../../view/offers/Components/workFlow/userConfig";

const { updateNewTriggerSettings, setNewWaWizardInfo, setEditWaWizardInfo } =
  workflowAutomationActions;
const {
  setTableData,
  setAutomation,
  removeRule,
  setFilterTableData,
  LOGIN_SUCCESS,
  LOGOUT_SUCCESS,
} = workflowAutomationActions;

const initialConfig = MuiConfig;

const config = {
  ...initialConfig,
  fields: {},
};

export const getConfigByType = (level) => {
  let newConfig = { ...config, fields: {} };
  if (level === "USER") {
    const userFieldConfig = {};
    const userFields = getUserFields();
    Array.isArray(userFields) && userFields.forEach((userField) => {
      userFieldConfig[userField.field] = { ...userField };
    });
    newConfig = { ...config, fields: userFieldConfig };
  }
  return { ...newConfig };
};

export const getUserConfigWithSettings = () => {
  const innerConfig = getConfigByType("USER");
  const settings = { ...innerConfig.settings };

  // hide not operator
  if (settings.notLabel === "Not") {
    settings.showNot = false;
  }

  innerConfig.operators = {
    ...innerConfig.operators,
    equal: {
      ...innerConfig.operators.equal,
      label: "Matches",
    },
    not_equal: {
      ...innerConfig.operators.not_equal,
      label: "Does not match",
    },
  };

  innerConfig.settings = settings;
  return innerConfig;
};

// editWaExistingInfo: ACTION DETAILS TO PRE-POPULATE IN WIZARD...
export const addEditAutomation =
  (existingExp, editWaExistingInfo) => (dispatch) => {
    const newConfig = getUserConfigWithSettings();
    const [immutableTree, ignoredPart] = QbUtils.loadFromSpel(
      existingExp,
      newConfig
    );
    const expression = QbUtils.spelFormat(immutableTree, newConfig);
    const fieldTree = QbUtils.getTree(immutableTree, true, false);
    const fields = getFieldList(fieldTree, new Set());
    const waStepsInfo = {
      expression,
      config: newConfig,
      tree: immutableTree,
    };
    // NOTE: editWaExistingInfo: similar to 'newWaDefaultInfo'
    dispatch(
      setEditWaWizardInfo({
        editWaExistingInfo,
        editWaExistingConfig: waStepsInfo,
      })
    );
  };

export const addNewAutomation = () => (dispatch) => {
  const newConfig = getUserConfigWithSettings();
  const queryValue = { id: QbUtils.uuid(), type: "group" };
  const tree = QbUtils.checkTree(QbUtils.loadTree(queryValue), config);
  const expression = QbUtils.spelFormat(tree, config);
  const waStepsInfo = {
    expression,
    config: newConfig,
    tree,
  };
  dispatch(setNewWaWizardInfo({ newWaConfig: waStepsInfo }));
};

export const updateWAConfigTree =
  (expression, config, tree, fields) => (dispatch) => {
    dispatch(updateNewTriggerSettings({ expression, config, tree, fields }));
  };

export const setAutomationData = (automation) => (dispatch) => {
  dispatch(setAutomation(automation));
  dispatch();
  // openSnackbar({
  //   open: true,
  //   message: "Add rule successfully",
  //   variant: "alert",
  //   alert: {
  //     color: "success",
  //   },
  //   close: false,
  // })
};

// export const removeAutomationRule =
//   (triggerId, setConfirmRemoveAutomation) => (dispatch) => {
//     setConfirmRemoveAutomation(false);
//     const { automations } = store.getState().workflowAutomation;
//     const newAutomations = automations?.filter(
//       (automation) => automation.triggerId !== triggerId
//     );
//     dispatch(removeRule(newAutomations));
//   };
