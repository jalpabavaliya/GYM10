import { importsActions } from "../slices/imports";

const { getTypesofUpload } = importsActions;

export const typesOfUpload = (values) => (dispatch) => {
  dispatch(getTypesofUpload(values));
};
