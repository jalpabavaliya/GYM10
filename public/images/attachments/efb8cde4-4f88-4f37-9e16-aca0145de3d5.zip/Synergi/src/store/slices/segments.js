import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  segmentList: [],
  segmentInfo: {},
  dataType: {},
  segmentAICrafetdList: [],
  aICraftedClickedItems: {}
};

const segmentsSlice = createSlice({
  name: "segments", 
  initialState,
  reducers: {
    setSegmentList(state, action) {
      state.segmentList = action.payload.segmentList;
    },

    setAICraftedList(state, action) {
      state.segmentAICrafetdList = action.payload.segmentAICrafetdList;
    },

    setCreateSegmentDetails(state, action) {
      state.segmentInfo = action.payload.response;
    },

    setDataType(state, action) {
      state.dataType = action.payload.dataType;
    },

    addSegmentConditionDetails(state, action) {
      state.segmentInfo = action.payload.response;
    },

    setAICraftedClickedItems(state, action) {
      state.aICraftedClickedItems = { ...state.aICraftedClickedItems, ...action.payload};
    }
  },
});

export const segmentsActions = segmentsSlice.actions;
export const segmentsReducer = segmentsSlice.reducer;
