import { createSlice } from "@reduxjs/toolkit";

const newWaDefaultInfo = {
  name: "",
  description: "",
};

const initialState = {
  activeTriggerId: null,
  wizardOperation: "",
  waStepsInfo: {},
  automations: [],
  tableData: [],
  dataType: {},
  isSetApplyRule: false,
  searchAutomationResult: [],
  filterTableData: [],
  tokens: {
    access: null,
    refresh: null,
  },
};

const workflowAutomationSlice = createSlice({
  name: "workflowAutomation",
  initialState,
  reducers: {
    setActiveTriggerId(state, action) {
      state.activeTriggerId = action.payload;
    },

    resetActiveTriggerId(state) {
      state.activeTriggerId = null;
    },

    updateNewTriggerSettings(state, action) {
      const { expression, tree, config, fields } = action.payload;
      state.waStepsInfo.config = config;
      state.waStepsInfo.tree = tree;
      state.waStepsInfo.expression = expression;
      state.waStepsInfo.fields = fields;
    },

    setEditWaWizardInfo(state, action) {
      const { editWaExistingInfo, editWaExistingConfig } = action.payload;
      state.waStepsInfo = { ...editWaExistingInfo, ...editWaExistingConfig };
    },

    setNewWaWizardInfo(state, action) {
      const { newWaConfig } = action.payload;
      state.waStepsInfo = { ...newWaDefaultInfo, ...newWaConfig };
    },

    setTableData(state, action) {
      const { data, data_type } = action.payload;
      state.tableData = data;
      state.dataType = data_type;
      state.waStepsInfo.data_type = data_type;
      state.waStepsInfo.tableData = data;
    },
    setFilterTableData(state, action) {
      state.filterTableData = action.payload;
    },

    setAutomation(state, action) {
      state.automations = [...state.automations, action.payload];
      state.searchAutomationResult = [...state.automations];
    },

    setSearchAutomation(state, action) {
      state.searchAutomationResult = [...action.payload];
    },

    updateAutomation(state, action) {
      const { updatedAutomation } = action.payload;
      state.automations = updatedAutomation;
      state.searchAutomationResult = updatedAutomation;
    },

    removeRule(state, action) {
      state.automations = [...action.payload];
      state.searchAutomationResult = [...action.payload];
    },

    updateRulePrimaryInfo(state, action) {
      const { name, description } = action.payload;
      state.waStepsInfo.name = name;
      state.waStepsInfo.description = description;
    },

    LOGIN_SUCCESS(state, action) {
        const { access_token, refresh_token } = action.payload;
        state.tokens.access = access_token;
        state.tokens.refresh = refresh_token;
    },

    LOGOUT_SUCCESS(state, action) {
        state.tokens.access = null;
        state.tokens.refresh = null;
    },

    resetWaWizardInfo(state) {
      state.waStepsInfo.config = {};
      state.waStepsInfo.tree = {};
      state.waStepsInfo.expression = "";
      state.waStepsInfo.fields = {};
      state.waStepsInfo.name = "";
      state.waStepsInfo.description = "";
    },
  },
});

export const workflowAutomationActions = workflowAutomationSlice.actions;
export const workflowAutomationReducer = workflowAutomationSlice.reducer;
