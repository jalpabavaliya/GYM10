import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  typesOfUpload: [],
};

const importsSlice = createSlice({
  name: "imports",
  initialState,
  reducers: {
    getTypesOfUpload(state, action) {
      state.typesOfUpload = action.payload;
    },
  },
});

export const importsActions = importsSlice.actions;
export const importsReducers = importsSlice.reducer;
