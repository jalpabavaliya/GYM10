import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    offerList: [],
    offerInfo: {},
    dataType: {},
    offerAICrafetdList: [],
    aICraftedClickedItems: {}
};

const offersSlice = createSlice({
  name: "offers",
  initialState,
  reducers: {
    setOfferList(state, action) {
      state.offerList = action.payload.offerList;
    },

    setAICraftedList(state, action) {
      state.offerAICrafetdList = action.payload.offerAICrafetdList;
    },

    setCreateOfferDetails(state, action) {
      state.offerInfo = action.payload.response;
    },

    setDataType(state, action) {
      state.dataType = action.payload.dataType;
    },

    addOfferConditionDetails(state, action) {
      state.offerInfo = action.payload.response;
    },

    saveOfferDetails(state, action) {
      state.offerInfo = action.payload.response;
    },

    setAICraftedClickedItems(state, action) {
      state.aICraftedClickedItems = { ...state.aICraftedClickedItems, ...action.payload};
    }
  },
});

export const offersActions = offersSlice.actions;
export const offersReducer = offersSlice.reducer;
