import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { snackbarReducer } from "./slices/snackbar";
import { loginReducer } from "./slices/login-slice";
import { workflowAutomationReducer } from "./slices/rules";
import { segmentsReducer } from "./slices/segments";
import { offersReducer } from "./slices/offers";
import { segmentRuleReducer } from "./slices/segmentRule";

const allReduces = combineReducers({
  snackbar: snackbarReducer,
  login: loginReducer,
  workflowAutomation: workflowAutomationReducer,
  segments: segmentsReducer,
  segmentRules: segmentRuleReducer,
  offers: offersReducer
});

const store = configureStore({
  reducer: allReduces,
});

export default store;
