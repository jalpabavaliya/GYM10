import React, { useEffect } from "react";

const MainTitle =
  (Component) =>
  ({ title, ...props }) => {
    const useEffectc =
      (() => {
        document.title = title || "Default Title"; // Set default title if no title provided
      },
      [title]);

    return <Component {...props} />;
  };

export default MainTitle;
