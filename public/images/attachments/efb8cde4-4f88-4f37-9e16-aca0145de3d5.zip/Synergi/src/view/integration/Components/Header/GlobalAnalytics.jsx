import React from "react";
import "./GlobalAnalytics.css";
import { Box, Typography } from "@mui/material";

const Title = ({ title }) => (
  <Typography
    sx={{
      color: "#9853A6",
      fontFamily: "Roboto Condensed",
      fontSize: "0.8rem",
    }}
  >
    {title}
  </Typography>
);

const Value = ({ value }) => (
  <Typography
    sx={{
      color: "#414446",
      fontFamily: "IBM Plex Serif",
      fontSize: "1.5rem",
    }}
  >
    {value}
  </Typography>
);

const GlobalAnalytics = ({ data }) => {
  return (
    <div style={{ display: "flex" }}>
      {!!data.length &&
        data.map((key, index) => (
          <Box
            key={index}
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              padding: { lg: "0 2rem", md: "0 1rem", xs: "0 1rem" },
            }}
          >
            <Title title={key.title} />
            <Value value={key.value} />
          </Box>
        ))}
    </div>
  );
};

export default GlobalAnalytics;
