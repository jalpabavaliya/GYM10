import { Box, Typography } from "@mui/material";
import React from "react";
import SynergyIcon from "../../Components/SynergyIcon";
const ConnectApp = ({ icon, companyName, description }) => {
  return (
    <Box
      sx={{
        borderRadius: "5px",
        border: "1px solid #e2dded",
        background: "#ffffff",
        display: "flex",
        alignItems: "flex-start",
        padding: "1rem",
        gap: "1rem",
        width: "100%",
      }}
    >
      <div
        style={{
          width: "64px",
          height: "64px",
          AspectRatio: 1,
          padding: "0.5rem 0",
        }}
      >
        <img src={icon} alt='logo' />
      </div>
      <div
        style={{
          color: "#414446",
          width: "calc(100% - 50px)",
        }}
      >
        <Typography
          sx={{
            fontFamily: "IBM Plex Serif",
            fontSize: "1.25rem",
            fontWeight: "Bold",
            lineHeight: "2.5rem",
            textTransform: "capitalize",
          }}
        >
          {companyName}
        </Typography>
        <Typography
          sx={{
            fontFamily: "Roboto",
            fontSize: "0.9rem",
          }}
        >
          {description}
        </Typography>
      </div>
    </Box>
  );
};

export default ConnectApp;
