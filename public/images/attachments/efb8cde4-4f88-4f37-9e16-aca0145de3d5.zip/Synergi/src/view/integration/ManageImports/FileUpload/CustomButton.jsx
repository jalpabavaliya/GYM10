import React from "react";
import Button from "@mui/material/Button";
import { LoadingButton } from "@mui/lab";

export default function CustomButton(props) {
  return (
    <div style={{ marginTop: "1vh" }}>
      <Button
        type='submit'
        variant='outlined'
        disabled={props.pageType === 1}
        onClick={props.handleClickBack}
        style={{
          color: "var(--col-12, #852598)",
          textAlign: "center",
          fontFamily: "Noto Sans",
          fontSize: "16px",
          fontStyle: "normal",
          fontWeight: 600,
          lineHeight: "normal",
          textTransform: "capitalize",
          width: "20vh",
          height: "48px",
          borderRadius: "6px",
          background: "#fff",
          border: "1px solid var(--col-12, #852598)",
        }}
      >
        Back
      </Button>

      {props.isDataUploading ? (
        <LoadingButton
          loading
          loadingPosition='end'
          variant='contained'
          sx={{
            textAlign: "center",
            fontFamily: "Roboto",
            fontSize: "0.9",
            fontStyle: "normal",
            fontWeight: "Bold",
            lineHeight: "normal",
            textTransform: "capitalize",
            width: "fit-content",
            borderRadius: "6px",
            padding: "1rem 2rem 1rem 2rem",
            marginLeft: "1vh",
          }}
        >
          <span style={{ marginRight: "0.5rem" }}>Uploading</span>
        </LoadingButton>
      ) : (
        <Button
          type='submit'
          variant='contained'
          onClick={props.handleClickNext}
          style={{
            color: "#FFF",
            textAlign: "center",
            fontFamily: "Noto Sans",
            fontSize: "16px",
            fontStyle: "normal",
            fontWeight: 600,
            lineHeight: "normal",
            textTransform: "capitalize",
            width: "20vh",
            height: "48px",
            borderRadius: "6px",
            marginLeft: "1vh",
            background: "#852598",
          }}
        >
          Next
        </Button>
      )}
    </div>
  );
}
