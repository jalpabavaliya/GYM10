import { Box, Button, Typography, Zoom } from "@mui/material";
import { useState } from "react";
import Tooltip from "rc-tooltip";
import "rc-tooltip/assets/bootstrap_white.css";
import ArrowLeftIcon from "@mui/icons-material/ArrowLeft";

const statusColorSelector = (status) => {
  switch (status) {
    case "Successful":
      return "#158C6F";
    case "In Progress":
      return "#E08029";
    case "Failed":
      return "#8E0000";
    default:
      return "#158C6F";
  }
};

const ToolTipBox = ({ status, dateTime, children }) => {
  const date = new Date(dateTime).toLocaleString({
    day: "2-digit",
    month: "short",
    year: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  switch (status) {
    case "Successful":
      return (
        <Tooltip
          placement='right'
          overlayInnerStyle={{
            marginLeft: "3px",
            borderRadius: "5px",
            background: "#e9f3f1",
            border: "2px solid #158c6f",
            width: "22rem",
          }}
          showArrow={false}
          overlayStyle={{ backgroundColor: "unset" }}
          trigger={["hover"]}
          overlay={
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                width: "100%",
                fontSize: "0.8rem",
                textTransform: "capitalize",
              }}
            >
              <div
                style={{
                  fontWeight: "Bold",
                  fontSize: "1rem",
                  color: "#158c6f",
                }}
              >
                Integration Failed
              </div>
              <div>
                Connection with App unsuccessful. Attempted on
                {date}. Please reattempt or check integration settings.
              </div>
            </div>
          }
        >
          {children}
        </Tooltip>
      );
    case "In Progress":
      return (
        <Tooltip
          placement='right'
          overlayInnerStyle={{
            marginLeft: "3px",
            borderRadius: "5px",
            background: "#f9f3ee",
            border: "2px solid #e08029",
            width: "22rem",
          }}
          showArrow={false}
          overlayStyle={{ backgroundColor: "unset" }}
          trigger={["hover"]}
          overlay={
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                width: "100%",
                fontSize: "0.8rem",
                textTransform: "capitalize",
              }}
            >
              <div
                style={{
                  fontWeight: "Bold",
                  fontSize: "1rem",
                  color: "#e08029",
                }}
              >
                Integration Failed
              </div>
              <div>
                Connection with App unsuccessful. Attempted on
                {date}. Please reattempt or check integration settings.
              </div>
            </div>
          }
        >
          {children}
        </Tooltip>
      );
    case "Failed":
    default:
      return (
        <Tooltip
          placement='right'
          overlayInnerStyle={{
            marginLeft: "3px",
            borderRadius: "5px",
            background: "#f7eded",
            border: "2px solid #8e0000",
            width: "22rem",
          }}
          showArrow={false}
          destroyTooltipOnHide={true}
          overlayStyle={{ backgroundColor: "unset" }}
          trigger={["click"]}
          overlay={
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                width: "100%",
                fontSize: "0.8rem",
                textTransform: "capitalize",
              }}
            >
              <div
                style={{
                  fontWeight: "Bold",
                  fontSize: "1rem",
                  color: "#8e0000",
                }}
              >
                Integration Failed
              </div>
              <div>
                Connection with App unsuccessful. Attempted on
                {date}. Please reattempt or check integration settings.
              </div>
            </div>
          }
        >
          {children}
        </Tooltip>
      );
  }
};

const AppNameCategoryConnection = ({ name, category, status, dateTime }) => (
  <Box
    sx={{
      display: "flex",
      alignItems: "flex-start",
      gap: "0.5rem",
    }}
  >
    <Box
      sx={{
        height: "10px",
        width: "10px",
        borderRadius: "100%",
        backgroundColor: statusColorSelector(status),
        mt: "0.7rem",
        aspectRatio: "1",
      }}
    />
    <Box>
      <ToolTipBox status={status} dateTime={dateTime}>
        <Typography
          sx={{
            fontWeight: "bold",
            fontSize: "1.2rem",
            color: "#414446",
            overflow: "hidden",
            textOverflow: "ellipsis",
            display: "-webkit-box",
            "-webkit-line-clamp": "1",
            "-webkit-box-orient": "vertical",
            width: "fit-content",
          }}
        >
          {name}
        </Typography>
      </ToolTipBox>
      <Typography
        sx={{
          fontSize: "1rem",
          color: "#414446",
          mb: "1rem",
          overflow: "hidden",
          textOverflow: "ellipsis",
          display: "-webkit-box",
          "-webkit-line-clamp": "1",
          "-webkit-box-orient": "vertical",
        }}
      >
        Category: {category}
      </Typography>
      <Button
        variant='text'
        sx={{
          width: "fit-content",
          fontWeight: "Bold",
          fontSize: "0.7rem",
          color: "#a35bb1",
          padding: "0",
        }}
      >
        Disconnect
      </Button>
    </Box>
  </Box>
);

export default AppNameCategoryConnection;
