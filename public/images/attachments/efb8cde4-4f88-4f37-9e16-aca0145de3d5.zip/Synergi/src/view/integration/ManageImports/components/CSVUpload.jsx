/* eslint-disable react-hooks/exhaustive-deps */
import {
  Button,
  CircularProgress,
  Paper,
  TextField,
  Typography,
  Select,
  MenuItem,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import "./CSVUpload.css";
import { getTypesOfUpload, uploadFile } from "../../../../services/Imports";

const CSVUpload = () => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [importName, setImportName] = useState("");
  const [description, setDescription] = useState("");
  const [uploadType, setUploadType] = useState("");
  const [typesOfUpload, setTypesOfUpload] = useState([]);

  const handleFileDrop = (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    setFile(file);
  };

  const handleFileBrowse = () => {
    const fileInput = document.getElementById("csvFileInput");
    fileInput.click();
  };

  const handleFileInputChange = (event) => {
    const file = event.target.files[0];
    setUploading(true);
    setTimeout(() => {
      setUploading(false);
    }, 1000);

    console.log("File", file);
    setFile(file);
  };

  const handleImportNameChange = (event) => setImportName(event.target.value);
  const handleDescriptionChange = (event) => setDescription(event.target.value);
  const handleUploadTypeChange = (event) => setUploadType(event.target.value);

  const handleFormSubmit = async (event) => {
    event.preventDefault();

    console.log("FILES", file);

    const response = await uploadFile(
      file,
      importName,
      uploadType,
      description
    );
    console.log("Input Data:", response);
  };

  const shouldEnableButton = () =>
    file !== null &&
    importName.trim() !== "" &&
    description.trim() !== "" &&
    uploadType.trim() !== "";

  const getUploadTypes = async () => {
    const response = await getTypesOfUpload();
    console.log("Response - 2", response);
    if (response.status === 200) {
      const uploads = [];
      for (let upload of response.data)
        uploads.push({ label: upload.replaceAll("_", " "), value: upload });
      setTypesOfUpload(uploads);
    }
  };

  useEffect(() => {
    if (!typesOfUpload.length) getUploadTypes();
  }, []);

  return (
    <Paper
      id='csv_upload'
      sx={{
        borderRadius: "6px",
        border: "1px solid #EBE8F1",
        backgroundColor: "#ffffff",
        padding: "1rem",
      }}
    >
      <div
        style={{
          color: "#414446",
          fontFamily: "IBM Plex Serif",
          fontSize: "1.5rem",
          fontStyle: "normal",
          lineHeight: "2.5rem",
          marginBottom: "1rem",
        }}
      >
        New Data Upload
      </div>
      <form
        onSubmit={handleFormSubmit}
        style={{
          height: "auto",
          display: "flex",
          flexDirection: "column",
          gap: "3rem",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "1rem",
          }}
        >
          <span
            style={{
              color: "#414446",
              fontFamily: "Roboto",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: 400,
              lineHeight: "24px",
            }}
          >
            Can't find the exact dataset you need? No problem! Upload your own
            sheet to tailor your campaigns to perfection.
          </span>
          <div
            onDrop={handleFileDrop}
            onDragOver={(e) => e.preventDefault()}
            onClick={handleFileBrowse}
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              flexShrink: 0,
              borderRadius: "5px",
              height: "8vh",
              border: "2px dashed #B9B4C3",
              background: "#F6F5F8",
              cursor: "pointer",
              padding: "20px",
              width: "40rem",
            }}
          >
            <input
              type='file'
              id='csvFileInput'
              style={{ display: "none" }}
              onChange={handleFileInputChange}
            />
            <Typography
              variant='body2'
              color='textSecondary'
              style={{
                textAlign: "center",
                color: "#B9B4C3",
                fontFamily: "Noto Sans",
                fontSize: "14px",
                fontWeight: 500,
              }}
            >
              {file || uploading
                ? ""
                : "Drag and drop your files here or browse"}
            </Typography>
            {uploading ? (
              <div style={{ textAlign: "center", marginTop: "20px" }}>
                <CircularProgress />
                <Typography
                  variant='body2'
                  color='textSecondary'
                  style={{
                    marginTop: "10px",
                    fontFamily: "Noto Sans",
                    fontSize: "12px",
                    fontWeight: 500,
                  }}
                >
                  Uploading...
                </Typography>
              </div>
            ) : (
              file && (
                <Typography
                  variant='body2'
                  color='textSecondary'
                  style={{
                    marginTop: "20px",
                    fontFamily: "Noto Sans",
                    fontSize: "12px",
                    fontWeight: 500,
                    textAlign: "center",
                  }}
                >
                  {file.name}
                </Typography>
              )
            )}
          </div>
        </div>

        <div
          style={{
            width: "43rem",
            display: "flex",
            flexDirection: "column",
            gap: "0.75rem",
          }}
        >
          <Typography
            sx={{
              color: "#000000",
              fontFamily: "Roboto",
              fontSize: "0.9rem",
              fontWeight: "Bold",
              textTransform: "capitalize",
            }}
          >
            Import Name
          </Typography>
          <TextField
            value={importName}
            onChange={handleImportNameChange}
            placeholder='File name will appear here'
            style={{
              width: "100%",
              borderRadius: "6px",
              border: "1px solid #ebe8f1",
              background: "#ffffff",
            }}
          />

          <Typography
            sx={{
              color: "#000000",
              fontFamily: "Roboto",
              fontSize: "0.9rem",
              fontWeight: "Bold",
              textTransform: "capitalize",
            }}
          >
            Description
          </Typography>
          <TextField
            value={description}
            onChange={handleDescriptionChange}
            placeholder='Add an optional description for your import'
            multiline
            rows={4}
            style={{
              width: "100%",
              borderRadius: "6px",
              border: "1px solid #EBE8F1",
              background: "#FFF",
            }}
          />

          <Select
            labelId='types-of-upload'
            id='types-of-upload'
            value={uploadType}
            placeholder='Type of Upload'
            onChange={handleUploadTypeChange}
            sx={{
              color: "#000000",
            }}
          >
            {!!typesOfUpload.length &&
              typesOfUpload.map((upload) => (
                <MenuItem value={upload.value}>{upload.label}</MenuItem>
              ))}
          </Select>

          <div
            className='text-subheadings'
            style={{ marginBottom: "4.5vh", marginTop: "2vh" }}
          >
            By proceeding, you confirm that you legally own this data and adhere
            to all applicable industry standards and <br /> regulations for its
            use.
          </div>

          <Button
            type='submit'
            disabled={!shouldEnableButton() || uploading}
            sx={{
              color: "#ffffff",
              textAlign: "center",
              fontFamily: "Roboto",
              fontSize: "0.9",
              fontStyle: "normal",
              fontWeight: "Bold",
              lineHeight: "normal",
              textTransform: "capitalize",
              width: "fit-content",
              borderRadius: "6px",
              padding: "1rem 2rem",
              background: !shouldEnableButton() ? "#d3abdb" : "#852598",
              ":disabled": {
                color: "#ffffff",
              },
            }}
          >
            Agree And Upload
          </Button>
        </div>
      </form>
    </Paper>
  );
};

export default CSVUpload;
