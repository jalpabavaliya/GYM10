import { Box, Button, InputAdornment, TextField } from "@mui/material";
import React from "react";
import FilterHorizontal from "../assets/filterHorizontal.svg";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DropDown from "./DropDown";
import Search from "../../AllCampaigns/Search/Search";
import ImportedFiles from "../ManageImports/ImportedFiles";
import { CustomPaidSearchIcon } from "../../Utils/icons/icons";

const FilterAndSearch = ({
  selectedFilter,
  filterValue,
  handleFilter,
  data,
  setData,
}) => {
  const performanceFilterOptions = [
    {
      label: "By Top Performing",
      value: "by_top_performing",
    },
    {
      label: "Channels",
      options: [
        {
          label: "Direct Mail",
          value: "direct_mail",
        },
        { label: "Email", value: "email" },
        { label: "Telemarketing", value: "telemarketing" },
        { label: "SMS", value: "sms" },
        { label: "Social Media", value: "social_media" },
        { label: "Paid Search", value: "paid_search" },
        { label: "Paid Display", value: "paid_display" },
      ],
    },
    {
      label: "Unused",
      value: "unused",
    },
  ];

  const timeFrameOptions = [
    {
      label: "By Time Frame",
      options: [
        {
          label: "Recent",
          value: "recent",
        },
        {
          label: "Past 30 Days",
          value: "before_30_days",
        },
        {
          label: "Past 90 Days",
          value: "before_90_days",
        },
        {
          label: "Past 120 Days",
          value: "before_120_days",
        },
        {
          label: "Archived",
          value: "archived",
        },
      ],
    },
  ];

  return (
    <Box
      sx={{
        display: "flex",
        width: "100%",
        alignItems: "center",
        gap: "1rem",
        paddingBottom: "1rem",
        borderBottom: "1px solid #ebe8f1",
      }}
    >
      <DropDown
        defaultValue={selectedFilter === "topPerforming" ? filterValue : null}
        options={performanceFilterOptions}
        value={selectedFilter === "topPerforming" ? filterValue : null}
        handleChange={(value) => {
          handleFilter("topPerforming", value);
        }}
        placeholder='By Top Performing'
      />

      <DropDown
        defaultValue={selectedFilter === "historicalData" ? filterValue : null}
        options={timeFrameOptions}
        value={selectedFilter === "historicalData" ? filterValue : null}
        handleChange={(value) => {
          handleFilter("historicalData", value);
        }}
        placeholder='Recent'
      />

      <TextField
        id='app-integration-search'
        size='small'
        margin='none'
        variant='outlined'
        sx={{}}
        placeholder='Search files'
        InputProps={{
          sx: {
            height: "2.1rem",
          },
          endAdornment: (
            <InputAdornment position='end'>
              <SearchRoundedIcon />
            </InputAdornment>
          ),
        }}
      />

      {/* <Search
        data={data}
        onSearchResult={(results) => {
          setData(results);
        }}
        style={{ marginLeft: "10px" }}
        CustomIcon={<CustomPaidSearchIcon />}
      /> */}
    </Box>
  );
};

export default FilterAndSearch;
