import SouthRoundedIcon from "@mui/icons-material/SouthRounded";
import { Box, Button, Paper, Typography } from "@mui/material";
import React from "react";
import FilterAndSearch from "../../../Components/FilterAndSearch";
import Header from "./Header";
import IntegratedApps from "./IntegratedApps";
import Loader from "../../../Components/Loader";

const AppIntegration = ({
  integratedApps,
  selectedFilter,
  filterValue,
  handleFilter,
  isLoading,
}) => {
  const heading = "Manage App Integration";
  const lastUpdatedAt = "11 AM EST On July 11, 2023";

  return (
    <Paper
      sx={{
        backgroundColor: "#ffffff",
        width: "100%",
        height: "100%",
        borderRadius: "6px",
      }}
    >
      <Header heading={heading} lastUpdatedAt={lastUpdatedAt} />
      <section>
        <Box padding='1rem'>
          <FilterAndSearch
            selectedFilter={selectedFilter}
            filterValue={filterValue}
            handleFilter={handleFilter}
          />

          {isLoading ? (
            <Loader />
          ) : !!integratedApps.length ? (
            <IntegratedApps integratedApps={integratedApps} />
          ) : (
            <Typography
              sx={{
                fontFamily: "Roboto",
                fontWeight: "Normal",
                textTransform: "capitalize",
                color: "#b9b4c3",
                textAlign: "center",
                padding: "1rem",
              }}
            >
              No Apps Available
            </Typography>
          )}

          {/* {integratedApps.length >= 5 && (
            <Button
              style={{
                width: "100%",
                height: "4rem",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                padding: "1rem",
                color: "#A35BB1",
              }}
            >
              <Typography
                sx={{
                  fontFamily: "Roboto",
                  fontWeight: "Medium",
                  fontSize: "0.7rem",
                  textTransform: "capitalize",
                }}
              >
                View More
              </Typography>
              <SouthRoundedIcon />
            </Button>
          )} */}
        </Box>
      </section>
    </Paper>
  );
};

export default AppIntegration;
