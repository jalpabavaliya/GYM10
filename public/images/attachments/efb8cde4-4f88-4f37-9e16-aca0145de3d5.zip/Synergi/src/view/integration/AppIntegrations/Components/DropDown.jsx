import React from "react";
import Select, { components } from "react-select";
import FilterHorizontal from "../../assets/filterHorizontal.svg";

const FilterHorizontalSvg = () => (
  <img src={FilterHorizontal} alt='By Top Performing' />
);

const DropDown = ({ defaultValue, value, options, handleChange }) => {
  const styles = {
    container: (provided) => ({
      ...provided,
    }),
    control: (provided) => ({
      ...provided,
      border: "1px solid #a35bb1",
      boxShadow: "none",
      ":hover": {
        border: "1px solid #a35bb1",
      },
    }),
    indicatorsContainer: (provided) => ({
      ...provided,
      display: "none",
    }),
    valueContainer: (provided) => ({
      ...provided,
      padding: 0,
    }),
    placeholder: (provided) => ({
      ...provided,
      color: "#a35bb1",
    }),
    input: (provided) => ({
      ...provided,
      color: "#a35bb1",
    }),
  };

  // const DropdownIndicator = (props) => (
  //   <components.DropdownIndicator {...props}>
  //     <FilterHorizontalSvg />
  //   </components.DropdownIndicator>
  // );

  const Control = ({ children, ...props }) => (
    <components.Control {...props}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          padding: "0 1rem",
          height: "100%",
          gap: "1rem",
          width: "10rem",
        }}
      >
        <FilterHorizontalSvg />
        <div>{children}</div>
      </div>
    </components.Control>
  );

  return (
    <Select
      options={options}
      defaultValue={defaultValue}
      value={value}
      handleChange={handleChange}
      components={{ Control }}
      styles={styles}
      placeholder='By Channels'
    />
  );
};

export default DropDown;
