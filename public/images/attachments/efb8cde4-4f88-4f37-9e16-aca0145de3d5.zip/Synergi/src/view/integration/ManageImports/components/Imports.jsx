import { Button, TextField } from "@mui/material";
import React from "react";
import FilterHorizontal from "../../assets/filterHorizontal.svg";
import SouthIcon from "@mui/icons-material/South";
import CSVList from "./CSVList";

const Imports = () => {
  const data = [
    {
      status: "ACTIVE",
      name: "US Bank refining camapign above 5%",
      description: "Help new customers understand the value ....",
      imageUrl:
        "https://generation-sessions.s3.amazonaws.com/86e827c7bfb09b49caba0a55fabf1da0/img/image-262@2x.png",
      category: "Paid Search and Paid Display",
      analytics: {
        conversion: "36%",
        cpl: "$6.5",
        cac: "$456",
        roi: "$0.22",
      },
      campaign: "22",
      data: "236K",
      createdBy: "Alex S",
      createdAt: "July, 6 2023",
    },
    {
      status: "ACTIVE",
      name: "US Bank refining camapign above 5%",
      description: "Help new customers understand the value ....",
      imageUrl:
        "https://generation-sessions.s3.amazonaws.com/86e827c7bfb09b49caba0a55fabf1da0/img/image-262@2x.png",
      category: "Paid Search and Paid Display",
      analytics: {
        conversion: "36%",
        cpl: "$6.5",
        cac: "$456",
        roi: "$0.22",
      },
      campaign: "22",
      data: "236K",
      createdBy: "Alex S",
      createdAt: "July, 6 2023",
    },
    {
      status: "ACTIVE",
      name: "US Bank refining camapign above 5%",
      description: "Help new customers understand the value ....",
      imageUrl:
        "https://generation-sessions.s3.amazonaws.com/86e827c7bfb09b49caba0a55fabf1da0/img/image-262@2x.png",
      category: "Paid Search and Paid Display",
      analytics: {
        conversion: "36%",
        cpl: "$6.5",
        cac: "$456",
        roi: "$0.22",
      },
      campaign: "22",
      data: "236K",
      createdBy: "Alex S",
      createdAt: "July, 6 2023",
    },
    {
      status: "ACTIVE",
      name: "US Bank refining camapign above 5%",
      description: "Help new customers understand the value ....",
      imageUrl:
        "https://generation-sessions.s3.amazonaws.com/86e827c7bfb09b49caba0a55fabf1da0/img/image-262@2x.png",
      category: "Paid Search and Paid Display",
      analytics: {
        conversion: "36%",
        cpl: "$6.5",
        cac: "$456",
        roi: "$0.22",
      },
      campaign: "22",
      data: "236K",
      createdBy: "Alex S",
      createdAt: "July, 6 2023",
    },
    {
      status: "ACTIVE",
      name: "US Bank refining camapign above 5%",
      description: "Help new customers understand the value ....",
      imageUrl:
        "https://generation-sessions.s3.amazonaws.com/86e827c7bfb09b49caba0a55fabf1da0/img/image-262@2x.png",
      category: "Paid Search and Paid Display",
      analytics: {
        conversion: "36%",
        cpl: "$6.5",
        cac: "$456",
        roi: "$0.22",
      },
      campaign: "22",
      data: "236K",
      createdBy: "Alex S",
      createdAt: "July, 6 2023",
    },
  ];

  return (
    <div
      style={{
        backgroundColor: "#ffffff",
        width: "100%",
        height: "100vh",
        borderRadius: "6px",
      }}
    >
      <header
        style={{
          borderBottom: "1px solid #EBE8F1",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "2rem 1rem 1rem 1rem",
          }}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              color: "#414446",
              lineHeight: "1.5",
            }}
          >
            <span
              style={{
                fontFamily: "IBM Plex Serif",
                fontSize: "24px",
              }}
            >
              Manage Imports
            </span>
          </div>
          <Button
            type='submit'
            variant='contained'
            style={{
              color: "#FFF",
              textAlign: "center",
              fontFamily: "Roboto",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: 600,
              lineHeight: "normal",
              textTransform: "capitalize",
              width: "17rem",
              height: "48px",
              borderRadius: "6px",
              marginLeft: "1vh",
              background: "#852598",
            }}
          >
            Import CSV
          </Button>
        </div>
      </header>
      <section>
        <div
          style={{
            padding: "1rem",
          }}
        >
          <div
            className='IntegrationFilter'
            style={{
              width: "100%",
              display: "flex",
              gap: "15px",
              paddingBottom: "1rem",
              borderBottom: "1px solid #EBE8F1",
            }}
          >
            <Button
              variant='outline'
              style={{
                fontFamily: "Roboto",
                fontStyle: "medium",
                fontSize: "12px",
                border: "2px solid #A35BB1",
                color: "#A35BB1",
                display: "flex",
                width: "12rem",
                height: "2rem",
                alignItems: "center",
                padding: "1rem",
                gap: "10px",
                borderRadius: "3px",
              }}
              start
            >
              <img className='icon' src={FilterHorizontal} alt='filter' />
              <span>By Top Performing</span>
            </Button>

            <Button
              variant='outline'
              style={{
                fontFamily: "Roboto",
                fontStyle: "medium",
                fontSize: "12px",
                border: "2px solid #A35BB1",
                color: "#A35BB1",
                display: "flex",
                width: "fit-content",
                height: "2rem",
                alignItems: "center",
                padding: "1rem",
                gap: "10px",
                borderRadius: "3px",
              }}
            >
              <img className='icon' src={FilterHorizontal} alt='filter' />
              <span>Recent</span>
            </Button>

            <div>
              <TextField
                id='app-integration-search'
                size='small'
                margin='none'
                variant='outlined'
                style={{}}
                InputProps={{
                  style: {
                    height: "2.3rem",
                  },
                }}
              />
            </div>
          </div>
        </div>
        {!!data.length && data.map((list) => <CSVList list={list} />)}

        {data.length > 4 && (
          <Button
            style={{
              width: "100%",
              height: "4rem",
              fontFamily: "Roboto",
              fontWeight: "medium",
              fontSize: "12px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              padding: "1rem",
              color: "#A35BB1",
            }}
          >
            <span>View More</span>
            <SouthIcon />
          </Button>
        )}
      </section>
    </div>
  );
};

export default Imports;
