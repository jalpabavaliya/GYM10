import { Box, Table, TableBody, TableHead } from "@mui/material";
import React from "react";
import TableRow from "./TableRow";

const DataTable = ({ exportFiles }) => {
  console.log("DATA");
  return (
    <Box sx={{ padding: "1rem" }}>
      {/* <TableHead>
        <TableRow sx={{ width: "40%" }}>Campaign</TableRow>
        <TableRow sx={{ width: "20%" }}>Channel</TableRow>
        <TableRow sx={{ width: "20%" }}>Totl no. Records</TableRow>
        <TableRow sx={{ width: "20%" }}>Download</TableRow>
      </TableHead> */}
      <Box
        sx={{
          width: "100%",
          display: "flex",
          paddingBottom: "1rem",
          borderBottom: "1px solid #ebe8f1",
          marginBottom: "1rem",
          fontWeight: "Bold",
        }}
      >
        <Box sx={{ width: "40%" }}>Campaign</Box>
        <Box sx={{ width: "20%" }}>Channel</Box>
        <Box sx={{ width: "20%" }}>Total no. Records</Box>
        <Box sx={{ width: "20%", textAlign: "center" }}>Download</Box>
      </Box>
      <div>
        {exportFiles.map((fileData) => (
          <TableRow fileData={fileData} />
        ))}
      </div>
    </Box>
  );
};

export default DataTable;
