import { Box, Typography } from "@mui/material";
import React from "react";
import LoaderSvg from "../../assets/loader.svg";

const Loader = () => {
  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: "1rem",
        padding: "1rem",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          width: "2rem",
          height: "2rem",
          aspectRatio: "1",
        }}
      >
        <img src={LoaderSvg} alt='loading' />
      </div>
      <Typography
        sx={{
          color: "#852598",
          fontFamily: "Roboto",
          fontSize: "0.9rem",
          textTransform: "capitalize",
        }}
      >
        Loading
      </Typography>
    </Box>
  );
};

export default Loader;
