import React, { useState } from "react";
import { Grid, Box } from "@mui/material";
import CustomButton from "./CustomButton";
import { documentUpdateWithSelectedChannels } from "../../../../services/Imports";
import { GET_HISTORICAL_EVENT_DATA } from "../../../../common/config";
import notification from "../../../../components/Notification/notification";

const First = {
  "Invalid Data Format": "2312",
  "Mismatched Data": "666",
  "Incompatible Characters": "56",
  "Removed from Import": "236",
};
const Second = {
  "UPB  >$20k": "28",
  "Under 60 Months": "56",
  "No AVM": "36",
  "Not Priced": "4,290",
  "Selected Dataset": "51,864",
};

const areAllFieldsSelected = () => {
  return true;
};

const CSV_NAME = "EG CSV Name";
const DESC =
  "Data related to New York Zip code 10026 of people earning over $450k and own home";

const Finalize = ({
  onDataSelected,
  importName,
  importDescription,
  fileKpi,
  applicationDataMatrix,
  documentId,
  togglePopUp,
  setPageType,
  imports,
}) => {
  const [isDataUploading, setIsDataUploading] = useState(false);

  const handleClickNext = async () => {
    setIsDataUploading(true);
    const checkboxes = document.getElementsByName("checkbox");
    const selectedValues = [];
    checkboxes.forEach((checkbox) => {
      if (checkbox.checked) {
        selectedValues.push(checkbox.value);
      }
    });
    onDataSelected(selectedValues);
    const response = await documentUpdateWithSelectedChannels(
      documentId,
      selectedValues
    );
    setIsDataUploading(false);
    if (response.status === 200) {
      alert("File Uploaded Successfully");
      setPageType(1);
      imports(GET_HISTORICAL_EVENT_DATA, "document");
      togglePopUp(false);
    } else {
      notification(
        "error",
        "Error",
        response.data.message ?? "Failed to fetch the data"
      );
    }
  };

  const handleClickBack = () => {
    setPageType(1);
  };

  return (
    <div className="main-screen">
      <div className="text-headings" style={{ fontSize: "22px" }}>
        Finalize Data Import & Review
      </div>
      <div className="grid-content">
        <Grid
          container
          spacing={1}
          className="content"
          style={{
            marginTop: "2vh",
          }}
        >
          {Object.entries(fileKpi).map(([key, value]) => (
            <Grid item xs={12 / Object.keys(First).length}>
              <Box>
                <div className="grid-content-key" key={key}>
                  {key}
                </div>
                <br />
                <div className="grid-content-value" key={value}>
                  {value}
                </div>
              </Box>
            </Grid>
          ))}
        </Grid>
      </div>
      <div className="text-subheading">*All error data be not be imported</div>
      <hr
        style={{
          backgroundColor: "#d3abdb",
          border: "none",
          height: "1px",
          marginBottom: "2vh",
          marginTop: "2vh",
        }}
      />
      <div className="text-headings" style={{ fontSize: "22px" }}>
        Summary of Data
      </div>
      <div
        className="text-headings"
        style={{ fontSize: "18px", fontWeight: 550 }}
      >
        CSV Name
      </div>
      <div className="text-subheadings" style={{ fontSize: "14px" }}>
        {importName}
      </div>
      <div
        className="text-headings"
        style={{ fontSize: "18px", fontWeight: 550 }}
      >
        Description
      </div>
      <div className="text-subheadings" style={{ fontSize: "14px" }}>
        {importDescription}
      </div>
      <div
        className="text-headings"
        style={{ fontSize: "18px", fontWeight: 550 }}
      >
        Actionable Data Matrix
      </div>
      <div className="grid-content">
        <Grid container spacing={1} className="content">
          {Object.entries(applicationDataMatrix).map(([key, value]) => (
            <Grid item xs={12 / Object.keys(Second).length}>
              <Box>
                <div className="grid-content-key">{key}</div>
                <br />
                <div className="grid-content-value">{value}</div>
              </Box>
            </Grid>
          ))}
        </Grid>
      </div>
      <hr
        style={{
          backgroundColor: "#d3abdb",
          border: "none",
          height: "1px",
          marginTop: "2vh",
          marginBottom: "2vh",
        }}
      />
      {/* <div className='text-headings' style={{ fontSize: "22px" }}>
        Select Channels
      </div>
      <div
        className='text-subheadings'
        style={{ fontSize: "14px", marginTop: "1vh" }}
      >
        Select the channels compatible with your imported data type for optimum
        results
      </div>
      <div className='checkbox-container'>
        <label>
          <input type='checkbox' name='checkbox' value='Direct-Mail'></input>
          <span className='checkbox-label'>Direct Mail</span>
        </label>
        <label>
          <input type='checkbox' name='checkbox' value='E-mail'></input>
          <span className='checkbox-label'>E-mail</span>
        </label>
        <label>
          <input type='checkbox' name='checkbox' value='Call'></input>
          <span className='checkbox-label'>Call</span>
        </label>
        <label>
          <input type='checkbox' name='checkbox' value='Digital'></input>
          <span className='checkbox-label'>Digital</span>
        </label>
        <label>
          <input type='checkbox' name='checkbox' value='Social Media'></input>
          <span className='checkbox-label'>Social Media</span>
        </label>
      </div> */}
      <CustomButton
        handleClickBack={handleClickBack}
        areAllFieldsSelected={areAllFieldsSelected}
        handleClickNext={handleClickNext}
        isDataUploading={isDataUploading}
      />
    </div>
  );
};

export default Finalize;
