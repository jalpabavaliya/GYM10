import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import {
  Box,
  Button,
  Grid,
  InputAdornment,
  Item,
  Paper,
  TextField,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import FilterHorizontal from "../../../assets/filterHorizontal.svg";
import Select from "react-select";
import DropDown from "../../../Components/DropDown";
import Banner from "./Banner";
import ConnectApp from "../ConnectApp";
import Loader from "../../../Components/Loader";
import Adobe from "../../../assets/adobe.png";
import Altair from "../../../assets/altair.png";
import BKMSP from "../../../assets/bk_msp.png";

const FilterHorizontalSvg = () => (
  <img src={FilterHorizontal} alt='By Top Performing' />
);

const ConnectApps = () => {
  const menuOptions = [
    { label: "Direct Email", value: "direct-email" },
    { label: "Email", value: "email" },
    { label: "Telemarketing", value: "telemarketing" },
    { label: "SMS", value: "sms" },
    { label: "Social Media", value: "social-media" },
    { label: "Paid Search", value: "paid-search" },
    { label: "Paid Delay", value: "paid-delay" },
  ];

  const apps = [
    {
      icon: Adobe,
      companyName: "Adobe",
      description: "Boost creative design and asset management with Adobe.",
    },
    {
      icon: Altair,
      companyName: "Altair",
      description: "Amplify targeting precision with Altair.",
    },
    {
      icon: BKMSP,
      companyName: "BK MSP",
      description: "Enhance loan servicing and default management with BK MSP.",
    },
  ];

  const [selectChannels, setSelectChannels] = useState("");

  return (
    <Paper
      sx={{
        borderRadius: "6px",
        border: "1px solid #ebe8f1",
        marginBottom: "1rem",
      }}
      id='connect-apps'
    >
      <Box
        sx={{
          padding: "1rem",
          borderBottom: "1px solid #ebe8f1",
        }}
      >
        <Typography
          sx={{
            lineHeight: "2.5rem",
            fontWeight: "Regular",
            fontFamily: "IBM Plex Serif",
            fontSize: "1.5rem",
            color: "#414446",
          }}
        >
          Connected apps that power your leads
        </Typography>
      </Box>
      <Box
        sx={{
          padding: "1.5rem 1rem",
          display: "flex",
          flexDirection: "column",
          gap: "1rem",
        }}
      >
        <Typography
          sx={{
            fontFamily: "Roboto",
            fontSize: "0.9rem",
            color: "#414446",
          }}
        >
          Discover new ways to save time and expand your reachwith these
          powerful apps & integrations.
        </Typography>

        <div
          style={{
            display: "flex",
            gap: "1rem",
          }}
        >
          <DropDown
            defaultValue={selectChannels}
            options={menuOptions}
            value={selectChannels}
            handleChange={setSelectChannels}
            placeholder='By Channels'
          />
          {/* <Button
            variant='outline'
            sx={{
              width: "10rem",
              height: "2rem",
              display: "flex",
              alignItems: "center",
              fontFamily: "Roboto",
              fontSize: "0.75rem",
              color: "#a35bb1",
              border: "1px solid #a35bb1",
              padding: "1rem",
              gap: "10px",
              borderRadius: "3px",
              textTransform: "capitalize",
            }}
            startIcon={<FilterHorizontalSvg />}
          >
            By Channels
          </Button> */}
          <TextField
            id='app-integration-search'
            size='small'
            margin='none'
            variant='outlined'
            sx={{}}
            placeholder='Search files'
            InputProps={{
              sx: {
                height: "2.1rem",
              },
              endAdornment: (
                <InputAdornment position='end'>
                  <SearchRoundedIcon />
                </InputAdornment>
              ),
            }}
          />
        </div>

        <div
          style={{
            display: "flex",
            gap: "1rem",
          }}
        >
          <Banner />
        </div>

        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            gap: "1rem",
          }}
        >
          <Grid container spacing={1} xs={12}>
            {apps.map((app) => (
              <Grid
                item
                md={4}
                xs={6}
                sx={{
                  display: "flex",
                  gridAutoColumns: "1fr",
                  gridAutoFlow: "column",
                }}
              >
                <ConnectApp
                  icon={app.icon}
                  companyName={app.companyName}
                  description={app.description}
                />
              </Grid>
            ))}
          </Grid>

          <Loader />
        </Box>
      </Box>
    </Paper>
  );
};

export default ConnectApps;
