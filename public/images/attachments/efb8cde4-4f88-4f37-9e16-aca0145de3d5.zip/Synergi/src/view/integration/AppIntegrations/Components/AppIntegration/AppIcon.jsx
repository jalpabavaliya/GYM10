import { Box } from "@mui/material";

const AppIcon = ({ icon }) => (
  <div
    style={{
      width: "100%",
      display: "flex",
      justifyContent: "center",
      marginTop: "0.3rem",
    }}
  >
    <Box
      style={{
        width: "1.5rem",
        height: "1.5rem",
        borderRadius: "100%",
        border: "1px solid #ebe8f1",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <img src={icon} alt='pic' height='15px' width='15px' />
    </Box>
  </div>
);

export default AppIcon;
