import { Box, Button, Paper, Typography } from "@mui/material";
import React from "react";

const DataExport = () => {
  return (
    <Paper
      sx={{
        backgroundColor: "#ffffff",
        width: "100%",
        height: "100%",
        borderRadius: "6px",
        padding: "1rem",
        gap: "2rem",
        flexDirection: "column",
        display: "flex",
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: "0.5rem",
          paddingBottom: "2rem",
          borderBottom: "1px solid #ebe8f1",
        }}
      >
        <Typography
          sx={{
            color: "#414446",
            fontFamily: "IBM Plex Serif",
            fontSize: "1.5rem",
            lineHeight: "2.5rem",
          }}
        >
          Data Export
        </Typography>
        <Typography
          sx={{
            color: "#414446",
            fontFamily: "Roboto",
            fontSize: "1rem",
            lineHeight: "1.5rem",
            maxWidth: "55rem",
          }}
        >
          Tailor your data export to your needs. Start by selecting the data
          category, the specific time frame, and the campaign or segment, if
          applicable.
        </Typography>
      </Box>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: "2.5rem",
          marginBottom: "3rem",
        }}
      >
        <div
          style={{
            borderRadius: "5px",
            background: "#f6f5f8",
            height: "18rem",
          }}
        ></div>

        <Button
          variant='contained'
          sx={{
            color: "#ffffff",
            textAlign: "center",
            fontFamily: "Roboto",
            fontSize: "1rem",
            fontWeight: "Bold",
            textTransform: "capitalize",
            borderRadius: "6px",
            backgroundColor: "#852598",
            paddingLeft: "2.5rem",
            paddingRight: "2.5rem",
            width: "fit-content",
          }}
        >
          Export As CSV
        </Button>
      </Box>
    </Paper>
  );
};

export default DataExport;
