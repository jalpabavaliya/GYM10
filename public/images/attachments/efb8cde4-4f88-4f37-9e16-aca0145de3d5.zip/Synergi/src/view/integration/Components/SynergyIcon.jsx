import React from "react";
import SynergySvg from "../assets/synergiIcon.svg";

const SynergyIcon = () => {
  return <img src={SynergySvg} alt='Synergy Logo' width='100%' height='100%' />;
};

export default SynergyIcon;
