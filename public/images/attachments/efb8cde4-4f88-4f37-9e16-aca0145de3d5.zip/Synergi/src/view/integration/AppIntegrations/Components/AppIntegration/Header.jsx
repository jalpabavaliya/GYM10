import { Box, Button, Typography } from "@mui/material";
import React from "react";

const Title = ({ title }) => (
  <Typography
    sx={{
      fontFamily: "IBM Plex Serif",
      fontSize: "1.5rem",
    }}
  >
    {title}
  </Typography>
);

const LastUpdatedAt = ({ dateTime }) => (
  <Typography
    sx={{
      fontFamily: "Roboto",
      fontStyle: "normal",
      fontSize: "0.75rem",
    }}
  >
    {/* TODO: Need to update  according to api response */}
    Last Date Updated At {dateTime}
  </Typography>
);

const Header = ({ heading, lastUpdatedAt }) => {
  const screenViewIntoConnectApps = () => {
    const connectApps = document.getElementById("connect-apps");
    connectApps.scrollIntoView({ behavior: "smooth", block: "center" }, true);
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "1rem",
        borderBottom: "1px solid #ebe8f1",
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          color: "#414446",
          lineHeight: "1.5",
        }}
      >
        <Title title={heading} />
        <LastUpdatedAt dateTime={lastUpdatedAt} />
      </Box>
      {/* TODO: To add Auto Scroll - onClick - connect apps */}
      <Button
        type='submit'
        variant='contained'
        sx={{
          color: "#ffffff",
          fontFamily: "Roboto",
          fontSize: "1rem",
          fontWeight: "Bold",
          textAlign: "center",
          textTransform: "capitalize",
          width: "17rem",
          height: "48px",
          borderRadius: "6px",
          backgroundColor: "#852598",
          ":hover": {
            backgroundColor: "#852598",
          },
        }}
        onClick={() => screenViewIntoConnectApps()}
      >
        Create New Integrations
      </Button>
    </div>
  );
};

export default Header;
