import { Box, Button, Paper, Typography } from "@mui/material";
import React from "react";
import Header from "./Header";
import FilterAndSearch from "../Components/FilterAndSearch";
import ImportedFiles from "./ImportedFiles";
import SouthRoundedIcon from "@mui/icons-material/SouthRounded";
import Loader from "../Components/Loader";

const ManageImports = ({
  importedFiles,
  setImportedFiles,
  selectedFilter,
  filterValue,
  handleFilter,
  isLoading,
}) => {
  const heading = "Manage Imports";

  return (
    <Paper
      sx={{
        backgroundColor: "#ffffff",
        width: "100%",
        height: "100%",
        borderRadius: "6px",
      }}
    >
      <Header heading={heading} />
      <section>
        <Box padding='1rem'>
          <FilterAndSearch
            selectedFilter={selectedFilter}
            filterValue={filterValue}
            handleFilter={handleFilter}
            data={importedFiles}
            setData={setImportedFiles}
          />

          {isLoading ? (
            <Loader />
          ) : !!importedFiles.length ? (
            <ImportedFiles importedFiles={importedFiles} />
          ) : (
            <Typography
              sx={{
                fontFamily: "Roboto",
                fontWeight: "Normal",
                textTransform: "capitalize",
                color: "#b9b4c3",
                textAlign: "center",
                padding: "1rem",
              }}
            >
              No Imports Available
            </Typography>
          )}

          {/* {importedFiles.length >= 5 && (
            <Button
              style={{
                width: "100%",
                height: "4rem",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                padding: "1rem",
                color: "#A35BB1",
              }}
            >
              <Typography
                sx={{
                  fontFamily: "Roboto",
                  fontWeight: "Medium",
                  fontSize: "0.7rem",
                  textTransform: "capitalize",
                }}
              >
                View More
              </Typography>
              <SouthRoundedIcon />
            </Button>
          )} */}
        </Box>
      </section>
    </Paper>
  );
};

export default ManageImports;
