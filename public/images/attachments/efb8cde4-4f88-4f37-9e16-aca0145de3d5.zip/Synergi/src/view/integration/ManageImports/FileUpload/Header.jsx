import React from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import Grid from "@mui/material/Grid";
import StepLabel from "@mui/material/StepLabel";
import { createTheme, ThemeProvider } from "@mui/material/styles";

const steps = ["Map Fields", "Finalize"];

const theme = createTheme({
  palette: {
    primary: {
      main: "#852598", // Change the primary color to #5D596C
    },
  },
});

const Header = (props) => {
  return (
    <div>
      <ThemeProvider theme={theme}>
        <Grid container spacing={2} style={{ height: "100%" }}>
          <Grid item xs={8}>
            <div className='header'>Import Data</div>
          </Grid>
          <Grid item xs={4}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                height: "100%",
                marginTop: "0.5vh",
              }}
            >
              <Stepper
                activeStep={props.type}
                alternativeLabel
                sx={{ padding: 0, height: "100%" }}
              >
                {steps.map((label) => (
                  <Step key={label}>
                    <StepLabel sx={{ flexGrow: 1 }}>{label}</StepLabel>
                  </Step>
                ))}
              </Stepper>
            </Box>
          </Grid>
          <Grid item xs={12}>
            <hr
              style={{
                backgroundColor: "#852598",
                border: "none",
                height: "1px",
              }}
            />
          </Grid>
        </Grid>
      </ThemeProvider>
    </div>
  );
};

export default Header;
