import { Box, Button, InputAdornment, TextField } from "@mui/material";
import React from "react";
import FilterHorizontal from "../../../assets/filterHorizontal.svg";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";

const FilterHorizontalSvg = () => (
  <img src={FilterHorizontal} alt='By Top Performing' />
);

const FilterAndSearch = () => {
  return (
    <Box
      sx={{
        display: "flex",
        width: "100%",
        alignItems: "center",
        gap: "1rem",
        paddingBottom: "1rem",
        borderBottom: "1px solid #ebe8f1",
      }}
    >
      <Button
        variant='outline'
        sx={{
          width: "11rem",
          height: "2rem",
          display: "flex",
          alignItems: "center",
          fontFamily: "Roboto",
          fontSize: "0.75rem",
          color: "#a35bb1",
          border: "1px solid #a35bb1",
          padding: "1rem",
          gap: "10px",
          borderRadius: "3px",
          textTransform: "capitalize",
        }}
        startIcon={<FilterHorizontalSvg />}
      >
        By Top Performing
      </Button>
      <Button
        variant='outline'
        sx={{
          width: "7rem",
          height: "2rem",
          display: "flex",
          alignItems: "center",
          fontFamily: "Roboto",
          fontSize: "0.75rem",
          color: "#a35bb1",
          border: "1px solid #a35bb1",
          padding: "1rem",
          gap: "10px",
          borderRadius: "3px",
          textTransform: "capitalize",
        }}
        startIcon={<FilterHorizontalSvg />}
      >
        Recent
      </Button>
      <TextField
        id='app-integration-search'
        size='small'
        margin='none'
        variant='outlined'
        sx={{}}
        placeholder='Search files'
        InputProps={{
          sx: {
            height: "2.1rem",
          },
          endAdornment: (
            <InputAdornment position='end'>
              <SearchRoundedIcon />
            </InputAdornment>
          ),
        }}
      />
    </Box>
  );
};

export default FilterAndSearch;
