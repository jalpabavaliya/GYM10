/* eslint-disable react-hooks/exhaustive-deps */
import {
  Box,
  Button,
  CircularProgress,
  MenuItem,
  OutlinedInput,
  Paper,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { getTypesOfUpload, uploadFile } from "../../../../services/Imports";
import { LoadingButton } from "@mui/lab";
import SaveIcon from "@mui/icons-material/Save";
import notification from "../../../../components/Notification/notification";

const CsvFileUpload = ({ togglePopUp, setUploadResponse }) => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [importName, setImportName] = useState("");
  const [description, setDescription] = useState("");
  const [uploadType, setUploadType] = useState("");
  const [typesOfUpload, setTypesOfUpload] = useState([]);
  const [showWarning, setShowWarning] = useState(false);
  const [isFileUploading, setIsFileUploading] = useState(false);

  const handleFileDrop = (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    setFile(file);
  };

  const handleFileBrowse = () => {
    const fileInput = document.getElementById("csvFileInput");
    fileInput.click();
  };

  const handleFileInputChange = (event) => {
    const file = event.target.files[0];
    setUploading(true);
    setTimeout(() => {
      setUploading(false);
    }, 1000);
    setFile(file);
  };
  const handleImportNameChange = (event) => setImportName(event.target.value);
  const handleDescriptionChange = (event) => setDescription(event.target.value);
  const handleUploadTypeChange = (event) => setUploadType(event.target.value);

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    setIsFileUploading(true);
    const response = await uploadFile(
      file,
      importName,
      uploadType,
      description
    );
    setIsFileUploading(false);
    if (response.status === 200) {
      setUploadResponse(response.data.response);
      togglePopUp(true);
    } else {
      setShowWarning(true);
      setFile(null);
      setImportName("");
      setDescription("");
      setUploadType("");
      notification(
        "error",
        "Error",
        response.data.message ?? "Failed to fetch the data"
      );
    }
  };

  const shouldEnableButton = () => {
    return (
      file !== null &&
      importName.trim() !== "" &&
      description.trim() !== "" &&
      uploadType.trim() !== ""
    );
  };

  const getUploadTypes = async () => {
    const response = await getTypesOfUpload();
    if (response.status === 200) {
      const uploads = [];
      for (let upload of response.data)
        uploads.push({ label: upload.replaceAll("_", " "), value: upload });
      setTypesOfUpload(uploads);
    }
  };

  useEffect(() => {
    if (!typesOfUpload.length) getUploadTypes();
  }, []);

  return (
    <Paper
      id='csv_file_upload'
      sx={{
        borderRadius: "6px",
        border: "1px solid #ebe8f1",
        backgroundColor: "#ffffff",
        padding: "1rem",
      }}
    >
      <Typography
        sx={{
          color: "#414446",
          fontFamily: "IBM Plex Serif",
          fontSize: "1.5rem",
          lineHeight: "2.5rem",
          marginBottom: "1rem",
        }}
      >
        New Data Upload
      </Typography>
      <form
        onSubmit={handleFormSubmit}
        style={{
          height: "auto",
          display: "flex",
          flexDirection: "column",
          gap: "3rem",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: "1rem",
          }}
        >
          <Typography
            sx={{
              color: "#414446",
              fontFamily: "Roboto",
              fontSize: "0.9rem",
              lineHeight: "24px",
            }}
          >
            Can't find the exact dataset you need? No problem! Upload your own
            sheet to tailor your campaigns to perfection.
          </Typography>
        </Box>
        <div
          onDrop={handleFileDrop}
          onDragOver={(e) => e.preventDefault()}
          onClick={handleFileBrowse}
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            flexShrink: 0,
            borderRadius: "5px",
            height: "8vh",
            border: "2px dashed #B9B4C3",
            background: "#F6F5F8",
            cursor: "pointer",
            padding: "20px",
            width: "40rem",
          }}
        >
          <input
            type='file'
            id='csvFileInput'
            style={{ display: "none" }}
            onChange={handleFileInputChange}
          />
          <Typography
            variant='body2'
            color='textSecondary'
            sx={{
              textAlign: "center",
              color: "#b9b4c3",
              fontFamily: "Roboto",
              fontSize: "0.9rem",
              fontWeight: 500,
            }}
          >
            {file || uploading ? "" : "Drag and drop your files here or browse"}
          </Typography>

          {uploading ? (
            <Box sx={{ textAlign: "center", marginTop: "0.2rem" }}>
              <CircularProgress />
              <Typography variant='body2'>Uploading...</Typography>
            </Box>
          ) : (
            file && (
              <Typography
                variant='body2'
                color='textSecondary'
                style={{
                  marginTop: "0.2remx",
                  fontFamily: "12px",
                  fontWeight: 500,
                  textAlign: "center",
                }}
              >
                {file.name}
              </Typography>
            )
          )}
        </div>

        <div
          style={{
            width: "43rem",
            display: "flex",
            flexDirection: "column",
            gap: "0.75rem",
          }}
        >
          <Typography
            sx={{
              color: "#000000",
              fontFamily: "Roboto",
              fontSize: "0.9rem",
              fontWeight: "Bold",
              textTransform: "capitalize",
            }}
          >
            Import Name
          </Typography>
          <TextField
            value={importName}
            onChange={handleImportNameChange}
            placeholder='File name will appear here'
            style={{
              width: "100%",
              borderRadius: "6px",
              border: "1px solid #ebe8f1",
              background: "#ffffff",
            }}
          />

          <Typography
            sx={{
              color: "#000000",
              fontFamily: "Roboto",
              fontSize: "0.9rem",
              fontWeight: "Bold",
              textTransform: "capitalize",
            }}
          >
            Description
          </Typography>
          <TextField
            value={description}
            onChange={handleDescriptionChange}
            placeholder='Add an optional description for your import'
            multiline
            rows={4}
            style={{
              width: "100%",
              borderRadius: "6px",
              border: "1px solid #EBE8F1",
              background: "#FFF",
            }}
          />

          <Select
            labelId='types-of-upload'
            id='types-of-upload'
            value={uploadType}
            onChange={handleUploadTypeChange}
            sx={{
              color: "#000000",
            }}
            displayEmpty={true}
            renderValue={(selected) => {
              if (selected.length === 0) {
                return (
                  <span
                    style={{
                      color: "#838383",
                      fontFamily: "Roboto",
                      fontSize: "1rem",
                    }}
                  >
                    Select Data Source Type
                  </span>
                );
              }
              console.log(selected);
              return selected.replace("_", " ");
            }}
          >
            {!!typesOfUpload.length &&
              typesOfUpload.map((upload) => (
                <MenuItem value={upload.value}>{upload.label}</MenuItem>
              ))}
          </Select>

          <div
            className='text-subheadings'
            style={{ marginBottom: "4.5vh", marginTop: "2vh" }}
          >
            By proceeding, you confirm that you legally own this data and adhere
            to all applicable industry standards and <br /> regulations for its
            use.
          </div>

          {isFileUploading ? (
            <LoadingButton
              loading
              loadingPosition='end'
              variant='contained'
              sx={{
                textAlign: "center",
                fontFamily: "Roboto",
                fontSize: "0.9",
                fontStyle: "normal",
                fontWeight: "Bold",
                lineHeight: "normal",
                textTransform: "capitalize",
                width: "fit-content",
                borderRadius: "6px",
                padding: "1rem 2rem 1rem 2rem",
              }}
            >
              <span style={{ marginRight: "0.5rem" }}>Uploading</span>
            </LoadingButton>
          ) : (
            <Button
              type='submit'
              // disabled={!shouldEnableButton() || uploading}
              sx={{
                color: "#ffffff",
                textAlign: "center",
                fontFamily: "Roboto",
                fontSize: "0.9",
                fontStyle: "normal",
                fontWeight: "Bold",
                lineHeight: "normal",
                textTransform: "capitalize",
                width: "fit-content",
                borderRadius: "6px",
                padding: "1rem 2rem",
                background: !shouldEnableButton() ? "#d3abdb" : "#852598",
                ":disabled": {
                  color: "#ffffff",
                },
                ":hover": {
                  backgroundColor: "#d3abdb",
                },
              }}
            >
              Agree And Upload
            </Button>
          )}
        </div>
      </form>
    </Paper>
  );
};

export default CsvFileUpload;
