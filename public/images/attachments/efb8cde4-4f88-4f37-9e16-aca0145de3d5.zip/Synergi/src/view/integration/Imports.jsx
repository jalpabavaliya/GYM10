import React, { useState } from "react";
// import GlobalAnalytics from "./ManageApIntegrations/Components/GlobalAnalytics/GlobalAnalytics";
import { getImports } from "../../services/Imports";
import ManageImports from "./ManageImports/ManageImports";
import CsvFileUpload from "./ManageImports/FileUpload/CsvFileUpload";
import PopUp from "./ManageImports/FileUpload/PopUp";
import {
  GET_HISTORICAL_EVENT_DATA,
  GET_TOP_PERFORMING_KPI,
} from "../../common/config";
import notification from "../../components/Notification/notification";

const Imports = () => {
  const [importedFiles, setImportedFiles] = useState([]);
  const [isPopUpOpen, setIsPopUpOpen] = useState(false);
  const [uploadResponse, setUploadResponse] = useState({});
  const [selectedFilter, setSelectedFilter] = React.useState("");
  const [filterValue, setFilterValue] = React.useState("");
  const [isLoading, setIsLoading] = useState(false);

  const togglePopUp = (value) => setIsPopUpOpen(value);

  const imports = async (baseUrl, paramter) => {
    setIsLoading(true);
    const response = await getImports(baseUrl, paramter);
    if (response.status === 200) {
      setImportedFiles(() => response.data);
      setIsLoading(false);
      notification("sucess", "Success", "Data fetched successfully");
    } else {
      setIsLoading(false);
      notification(
        "error",
        "Error",
        response.data.message ?? "Failed to fetch the data"
      );
      setImportedFiles([]);
    }
  };

  const handleFilter = (filter, value) => {
    setSelectedFilter(filter);
    setFilterValue(value);
    if (filter === "topPerforming") {
      imports(GET_TOP_PERFORMING_KPI, "CAC_document");
    } else if (filter === "historicalData") {
      imports(GET_HISTORICAL_EVENT_DATA, "document");
    }
  };

  useState(() => {
    document.title = "Imports";
    if (!importedFiles.length) imports(GET_TOP_PERFORMING_KPI, "CAC_document");
  }, []);

  return (
    <>
      <ManageImports
        importedFiles={importedFiles}
        setImportedFiles={setImportedFiles}
        selectedFilter={selectedFilter}
        filterValue={filterValue}
        handleFilter={handleFilter}
        isLoading={isLoading}
      />
      <CsvFileUpload
        togglePopUp={togglePopUp}
        setUploadResponse={setUploadResponse}
      />
      <PopUp
        value='Upload file'
        togglePopUp={togglePopUp}
        isPopUpOpen={isPopUpOpen}
        uploadResponse={uploadResponse}
        imports={imports}
      />
    </>
  );
};

export default Imports;
