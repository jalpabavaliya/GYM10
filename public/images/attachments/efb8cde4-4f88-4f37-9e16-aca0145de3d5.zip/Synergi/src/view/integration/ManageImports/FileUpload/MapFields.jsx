/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from "react";
import { Select, MenuItem, FormControl, Grid, Typography } from "@mui/material";
import CustomButton from "./CustomButton";
import DropdownSvg from "../../assets/DropdownSvg";
import ArrowSvg from "../../assets/ArrowSvg";
import { mappedFields } from "../../../../services/Imports";
import notification from "../../../../components/Notification/notification";

// Dummy Data
const CSV_FIELD_LIST = [
  "Client ID",
  "Client",
  "First Visit",
  "Visit Location",
  "Service Category",
  "Visit Type",
  "Pricing Option",
  "Booking Method",
  "Referral Type",
  "Staff",
  "# Visits since First Visit",
  "Phone",
  "Email",
];
const TARGET_FIELD_LIST = ["a", "b", "c", "d", "e", "f", "g", "h"];
const MATCHED_LIST = { "Visit Type": "d", Email: "e", Phone: "h" };

const MapFields = ({
  onDataSelected,
  handleResponse,
  csvFieldList,
  targetFieldList,
  csvFieldToTargetField,
  documentId,
  setPageType,
}) => {
  const [selectedFields, setSelectedFields] = useState({});
  const [isDataUploading, setIsDataUploading] = useState(false);

  const handleChange = (event, csvField) => {
    setSelectedFields({
      ...selectedFields,
      [csvField]: event.target.value,
    });
  };

  const areAllFieldsSelected = () =>
    csvFieldList.every((field) => selectedFields[field]);

  const handleClickNext = async () => {
    setIsDataUploading(true);
    const response = await mappedFields(documentId, selectedFields);
    setIsDataUploading(false);
    if (response.status === 200) {
      handleResponse(response.data.response);
      onDataSelected(selectedFields);
      setPageType(2);
    } else {
      notification(
        "error",
        "Error",
        response.data.message ?? "Failed to fetch the data"
      );
    }
  };

  // Set initial selectedFields with matched values
  useEffect(() => {
    const initialValues = {};
    csvFieldList.forEach((field) => {
      initialValues[field] = csvFieldToTargetField[field] || "";
    });
    setSelectedFields(initialValues);
  }, []);

  return (
    <>
      <div>
        <div className='text-headings'>
          <h3>Data Mapping </h3>
        </div>
        <div className='text-subheadings'>
          Choose the data fields to map for use and mark any rows not required
          for import.
        </div>
      </div>

      <div className='inputs'>
        <Grid container spacing={2}>
          <Grid item xs={5}>
            <Typography
              style={{
                color: "var(--col-8, #000)",
                fontFamily: "Noto Sans",
                fontSize: "18px",
                fontStyle: "normal",
                fontWeight: "600",
                lineHeight: "normal",
                textTransform: "capitalize",
                textAlign: "left",
              }}
            >
              CSV Field
            </Typography>
          </Grid>

          <Grid item xs={2}></Grid>

          <Grid item xs={5}>
            <Typography
              style={{
                color: "var(--col-8, #000)",
                fontFamily: "Noto Sans",
                fontSize: "18px",
                fontStyle: "normal",
                fontWeight: "600",
                lineHeight: "normal",
                textTransform: "capitalize",
                textAlign: "left",
              }}
            >
              Target Field
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <hr
              style={{
                backgroundColor: "#d3abdb",
                border: "none",
                height: "1px",
              }}
            />
          </Grid>
        </Grid>
        <div className='inputs-content'>
          <Grid container spacing={2}>
            {csvFieldList.map((csvField, index) => (
              <React.Fragment key={index}>
                <Grid item xs={5}>
                  <div className='csv-field'>{csvField}</div>
                </Grid>
                <Grid item xs={2}>
                  <ArrowSvg />
                </Grid>
                <Grid item xs={5}>
                  <FormControl variant='outlined' fullWidth>
                    <Select
                      id={`select-${index}`}
                      value={selectedFields[csvField] || "placeholder"}
                      IconComponent={DropdownSvg}
                      onChange={(event) => handleChange(event, csvField)}
                      style={{
                        color:
                          selectedFields[csvField] === ""
                            ? "#838383"
                            : "var(--col-8, #000)",
                        fontFamily: "Noto Sans",
                        fontSize: "14px",
                        height: "3vh",
                        borderRadius: "3px",
                        background: "#FFF",
                        textAlign: "left",
                      }}
                    >
                      <MenuItem
                        disabled
                        value='placeholder'
                        style={{ border: "10px" }}
                      >
                        Select
                      </MenuItem>
                      {targetFieldList.map((targetField, targetIndex) => (
                        <MenuItem key={targetIndex} value={targetField}>
                          {targetField}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
              </React.Fragment>
            ))}
          </Grid>
        </div>
      </div>

      <CustomButton
        pageType={1}
        handleClickNext={handleClickNext}
        isDataUploading={isDataUploading}
      />
    </>
  );
};

export default MapFields;
