import { Box, Button, Typography } from "@mui/material";
import React from "react";
import SynergyIcon from "../../../Components/SynergyIcon";

const Banner = () => {
  return (
    <Box
      sx={{
        display: "flex",
        border: "1px solid #d0b6d6",
        backgroundColor: "#efe7ef",
        padding: "1rem",
        boxShadow: "0px 8px 20px 0px rgba(0, 0, 0, 0.06)",
        borderRadius: "6px",
        columnGap: "2rem",
        width: "100%",
        marginTop: "1rem",
      }}
    >
      <div
        style={{
          width: "64px",
          height: "64px",
          padding: "0.5rem 0",
          aspectRatio: 1,
        }}
      >
        <SynergyIcon />
      </div>
      <div>
        <Typography
          sx={{
            color: "#414446",
            fontFamily: "IBM Plex Serif",
            fontSize: "1.5rem",
            lineHeight: "2.5rem",
            textTransform: "capitalize",
            fontWeight: "Bold",
          }}
        >
          Customer Data Intelligence
        </Typography>
        <Typography
          sx={{
            color: "#5d596c",
            fontFamily: "Roboto",
            fontSize: "0.9rem",
            width: "34.3rem",
          }}
        >
          Enhance your insights by connecting with Customer Data Intelligence
        </Typography>
        <Button
          variant='text'
          sx={{
            color: "#852598",
            fontFamily: "Roboto",
            fontSize: "0.9rem",
            fontWeight: "Bold",
            paddingLeft: 0,
            paddingRight: 0,
          }}
        >
          Connect
        </Button>
      </div>
    </Box>
  );
};

export default Banner;
