import React from "react";

const DropdownSvg = (props) => {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      width='1.5vh'
      height='1.5vh'
      viewBox='0 0 24 24'
      fill='none'
      {...props}
    >
      <path
        d='M16 10L12 15L8 10'
        stroke='#5D596C'
        strokeWidth='2'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
};

export default DropdownSvg;
