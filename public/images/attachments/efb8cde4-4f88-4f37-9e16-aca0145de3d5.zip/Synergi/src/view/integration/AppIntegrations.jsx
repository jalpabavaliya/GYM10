/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import AppIntegration from "./AppIntegrations/Components/AppIntegration/AppIntegration";
import ConnectApps from "./AppIntegrations/Components/AppIntegration/ConnectApps";
// import "./Integrations.css";
import {
  GET_HISTORICAL_EVENT_DATA,
  GET_TOP_PERFORMING_KPI,
} from "../../common/config";
import { getAppIntegrations } from "../../services/appIntegrations";
import notification from "../../components/Notification/notification";

const AppIntergrations = () => {
  const [integratedApps, setIntegratedApps] = React.useState([]);
  const [selectedFilter, setSelectedFilter] = React.useState("");
  const [filterValue, setFilterValue] = React.useState("");
  const [isLoading, setIsLoading] = useState(false);

  const appIntegrations = async (baseUrl, parameter) => {
    setIsLoading(true);
    const response = await getAppIntegrations(baseUrl, parameter);
    if (response.status === 200) {
      setIsLoading(false);
      setIntegratedApps(response.data);
      notification("sucess", "Success", "Data fetched successfully");
    } else {
      setIsLoading(false);
      notification(
        "error",
        "Error",
        response.data.message ?? "Failed to fetch the data"
      );
      setIntegratedApps([]);
    }
  };

  const handleFilter = (filter, value) => {
    setSelectedFilter(filter);
    setFilterValue(value);
    if (filter === "topPerforming") {
      appIntegrations(GET_TOP_PERFORMING_KPI, "CAC_vendor");
    } else if (filter === "historicalData") {
      appIntegrations(GET_HISTORICAL_EVENT_DATA, "vendor");
    }
  };

  useEffect(() => {
    document.title = "App Integration";
    if (!integratedApps.length)
      appIntegrations(GET_TOP_PERFORMING_KPI, "CAC_vendor");
  }, []);

  return (
    <>
      <AppIntegration
        integratedApps={integratedApps}
        selectedFilter={selectedFilter}
        filterValue={filterValue}
        handleFilter={handleFilter}
        isLoading={isLoading}
      />
      <ConnectApps />
    </>
  );
};

export default AppIntergrations;
