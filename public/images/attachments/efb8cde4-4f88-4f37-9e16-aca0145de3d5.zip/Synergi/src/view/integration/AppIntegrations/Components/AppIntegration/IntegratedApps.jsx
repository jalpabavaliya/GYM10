import {
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableRow,
  Typography,
} from "@mui/material";
import React from "react";
import AppIcon from "./AppIcon";
import AppNameCategoryConnection from "./AppNameCategoryConnection";
import "./IntegratedApp.css";
import UsesCampaign from "./UsesCampaign";
import AppAnalytics from "../../../Components/AppAnalytics";

const IntegratedApps = ({ integratedApps }) => {
  return (
    <Table>
      <TableBody>
        {integratedApps.map((integratedApp) => (
          <TableRow sx={{ width: "100%", height: "100%" }}>
            <TableCell
              sx={{
                verticalAlign: "top",
                padding: "1rem 0",
                width: "3rem",
              }}
            >
              <AppIcon icon={integratedApp.imageUrl} />
            </TableCell>
            <TableCell
              sx={{
                padding: "1rem 0",
              }}
            >
              <AppNameCategoryConnection
                name={integratedApp.name}
                category={integratedApp.category}
                status={integratedApp.status ?? ""}
                dateTime={integratedApp.created_datetime}
              />
            </TableCell>
            <TableCell
              sx={{
                padding: "1rem 0",
                width: "8rem",
              }}
            >
              <UsesCampaign totalCampaign={integratedApp.total_run_campaigns} />
            </TableCell>
            <TableCell
              sx={{
                padding: "1rem 1rem",
                width: "16rem",
              }}
            >
              <AppAnalytics analytics={integratedApp.kpi} />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default IntegratedApps;
