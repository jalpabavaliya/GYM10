import React from "react";
import GlobalAnalytics from "./GlobalAnalytics";
import { Typography } from "@mui/material";

const Heading = ({ title }) => (
  <Typography
    sx={{
      color: "#3E004A",
      fontFamily: "Roboto",
      fontWeight: "Bold",
      fontSize: "1.6rem",
      textTransform: "capitalize",
    }}
  >
    {title}
  </Typography>
);

const Header = ({ heading, analytics }) => {
  return (
    <div
      style={{
        display: "flex",
        padding: "1rem",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <Heading title={heading} />
      <GlobalAnalytics data={analytics} />
    </div>
  );
};

export default Header;
