import React from "react";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import ContentCopyRoundedIcon from "@mui/icons-material/ContentCopyRounded";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";

const activeColor = "#158C6F";
const unusedColor = "#E08029";
const archivedColor = "#5D596C";

const UsesCampaign = () => (
  <div
    style={{
      display: "flex",
      alignItems: "flex",
      fontFamily: "Roboto",
      width: "100%",
    }}
  >
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex",
        fontFamily: "Roboto",
        width: "50%",
        borderRight: "1px solid #c3c3c3",
        padding: "0 0.5rem",
      }}
    >
      <span style={{ color: "#5D596C" }}>Uses</span>
      <div
        style={{
          display: "flex",
          color: "#A35BB1",
          alignItems: "center",
          gap: "0.5rem",
        }}
      >
        <span style={{ fontFamily: "IBM Plex Serif", fontSize: "24px" }}>
          22
        </span>
        <span style={{ fontSize: "12px", fontWeight: "medium" }}>
          Campaigns
        </span>
      </div>
    </div>
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex",
        fontFamily: "Roboto",
        width: "50%",
        padding: "0 0.5rem",
      }}
    >
      <span style={{ color: "#5D596C" }}>Data</span>
      <div
        style={{
          display: "flex",
          color: "#A35BB1",
          alignItems: "center",
          gap: "0.5rem",
        }}
      >
        <span style={{ fontFamily: "IBM Plex Serif", fontSize: "24px" }}>
          236K
        </span>
      </div>
    </div>
  </div>
);

const ConnectedAnalytics = () => (
  <div
    style={{
      width: "100%",
      display: "flex",
      border: "2px solid #EBE8F1",
      backgroundColor: "#F6F5F8",
      gap: "1rem",
      padding: "0.5rem",
      borderRadius: "5px",
    }}
  >
    <div className='AnalyticsProperty'>
      <span className='heading'>Conversion</span>
      <span className='value'>36%</span>
    </div>
    <div className='AnalyticsProperty'>
      <span className='heading'>CPL</span>
      <span className='value'>$6.5</span>
    </div>
    <div className='AnalyticsProperty'>
      <span className='heading'>CAC</span>
      <span className='value'>$456</span>
    </div>
    <div className='AnalyticsProperty'>
      <span className='heading'>ROI</span>
      <span className='value'>$0.22</span>
    </div>
  </div>
);

const FileDetails = ({ file }) => (
  <div
    style={{
      display: "flex",
      flexDirection: "column",
      color: "#414446",
      fontFamily: "Roboto",
      fontStyle: "normal",
      fontWeight: 400,
    }}
  >
    <div
      style={{
        fontSize: "16px",
        fontWeight: 600,
        lineHeight: "normal",
        marginBottom: "0.5rem",
      }}
    >
      US Bank refinancing campaign above 5%
      <span
        style={{
          fontSize: "14px",
          fontWeight: 400,
          marginLeft: "0.5rem",
        }}
      >
        (Active)
      </span>
    </div>
    <div
      style={{
        color: "#112333",
        fontSize: "14px",
        lineHight: "20px",
      }}
    >
      Help new customers understand the value ...
    </div>
    <div
      style={{
        fontSize: "12px",
        lineHeight: "20px",
      }}
    >
      Created by Alex S on July 6, 2023
    </div>
    <div
      style={{
        marginTop: "1rem",
        display: "flex",
        gap: "0.5rem",
        fontSize: "1rem",
        alignItems: "center",
        color: "#A35BB1",
      }}
    >
      <VisibilityOutlinedIcon />
      <ContentCopyRoundedIcon />
      <DeleteOutlineRoundedIcon />
    </div>
  </div>
);

const CSVList = ({ list }) => {
  return (
    <div
      style={{
        display: "flex",
        width: "calc(100% - 2rem)",
        gap: "0.5rem",
        padding: "1rem 1rem",
      }}
    >
      <div
        style={{
          width: "1rem",
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          marginTop: "0.3rem",
        }}
      >
        <div
          style={{
            borderRadius: "100%",
            width: "10px",
            height: "10px",
            backgroundColor: "#158C6F",
          }}
        />
      </div>

      <div
        style={{
          width: "calc(100% - 35.5rem)",
        }}
      >
        <FileDetails />
      </div>
      <div style={{ width: "12rem" }}>
        <UsesCampaign />
      </div>
      <div style={{ width: "20rem" }}>
        <ConnectedAnalytics />
      </div>
    </div>
  );
};

export default CSVList;
