import { Box, CircularProgress, Typography } from "@mui/material";
import React from "react";

const Loader = () => {
  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: "1rem",
        padding: "1rem",
        justifyContent: "center",
      }}
    >
      <CircularProgress
        size={20}
        sx={{
          color: "#852598",
        }}
      />

      <Typography
        sx={{
          color: "#852598",
          fontFamily: "Roboto",
          fontSize: "0.9rem",
          textTransform: "capitalize",
        }}
      >
        Loading...
      </Typography>
    </Box>
  );
};

export default Loader;
