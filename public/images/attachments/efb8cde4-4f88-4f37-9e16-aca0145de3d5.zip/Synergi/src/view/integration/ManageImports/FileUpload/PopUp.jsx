import React, { useState } from "react";
import MapFields from "./MapFields";
import Finalize from "./Finalize";
import { Dialog, DialogContent } from "@mui/material";
import Header from "./Header";

const PopUp = ({
  value,
  togglePopUp,
  isPopUpOpen,
  uploadResponse,
  imports,
}) => {
  const [selectedFirstPageData, setSelectedFirstPageData] = useState([]);
  const [selectedFirstPageResponse, setSelectedFirstPageResponse] =
    useState(null);
  const [selectedSecondPageData, setSelectedSecondPageData] = useState([]);
  const [pageType, setPageType] = useState(1);

  const handleFirstPageDataSelected = (data) => {
    setSelectedFirstPageData(data);
  };
  const handleSecondPageDataSelected = (data) => {
    setSelectedSecondPageData(data);
  };

  let pageComponent;
  if (pageType === 1) {
    pageComponent = (
      <MapFields
        onDataSelected={handleFirstPageDataSelected}
        handleResponse={setSelectedFirstPageResponse}
        csvFieldList={uploadResponse.csv_field_list}
        targetFieldList={uploadResponse.target_field_list}
        csvFieldToTargetField={uploadResponse.csv_field2target_field}
        documentId={uploadResponse.document_id}
        setPageType={setPageType}
      />
    );
  } else if (pageType === 2) {
    pageComponent = (
      <Finalize
        onDataSelected={handleSecondPageDataSelected}
        importName={uploadResponse.file_name}
        importDescription={uploadResponse.file_description}
        fileKpi={selectedFirstPageResponse.file_kpi}
        documentId={selectedFirstPageResponse.document_id}
        applicationDataMatrix={selectedFirstPageResponse.actionable_data_matrix}
        togglePopUp={(value) => togglePopUp(value)}
        setPageType={setPageType}
        imports={imports}
      />
    );
  }

  return (
    <React.Fragment>
      <Dialog
        open={isPopUpOpen}
        onClose={() => togglePopUp(false)}
        maxWidth='lg'
      >
        <DialogContent
          style={{
            display: "flex",
            flexDirection: "column",
            marginBottom: "5vh",
            marginLeft: "2vh",
            width: "90vh",
            height: "90vh",
          }}
        >
          <Header type={pageType - 1} />
          {pageComponent}
        </DialogContent>
      </Dialog>
    </React.Fragment>
  );
};

export default PopUp;
