import React, { useState, useEffect } from "react";
import { Popover, Grid, CircularProgress } from "@mui/material";
import {
  getCampaignSummary,
  getCampaignSummary2,
} from "../../../services/CampaignService";
import {
  aboutCampaignData as setAboutCampaignData,
  dataSourceData as setDataSourceData,
  segmetsData as setSegmetsData,
} from "../../Campaigns/GlobalStore";

export const SummaryBox = ({ CampaignSummary, which }) => {
  const [selectedArray, setSelectedArray] = useState([]);
  const [popoverAnchor, setPopoverAnchor] = useState(null);

  const [campaignSummaryData, setCampaignSummaryData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const renderValue = (value) => {
    if (Array.isArray(value)) {
      return value.length;
    }
    if (typeof value === "object" && value !== null) {
      return JSON.stringify(value);
    }
    return value;
  };

  useEffect(() => {
    if (CampaignSummary?.length > 0) {
      setIsLoading(true);
      if (which === 1) {
        (async () => {
          const response = await getCampaignSummary(CampaignSummary);

          const currentCampaignData = setAboutCampaignData();
          setAboutCampaignData({
            ...currentCampaignData,
            campaign_id: response.data.response.campaign_id,
          });

          setCampaignSummaryData(response.data.response.summary);
          setIsLoading(false);
        })();
      } else {
        (async () => {
          const response = await getCampaignSummary2(CampaignSummary);
          setCampaignSummaryData(response.data.response.summary);
          setIsLoading(false);
        })();
      }
    }
  }, [CampaignSummary]);

  const handleArrayClick = (array, event) => {
    setSelectedArray(array);
    setPopoverAnchor(event.currentTarget);
  };

  const handleClosePopover = () => {
    setPopoverAnchor(null);
  };

  return (
    <>
      <div className="summaryBox">
        <div
          className="headerText"
          style={{ paddingTop: "20px", paddingLeft: "10px" }}
        >
          Campaign Summary
        </div>
        <div className="customHR"></div>
        {campaignSummaryData ? (
          Object.entries(campaignSummaryData).map(([key, value]) => (
            <div style={{ margin: "10px" }}>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <div className="normalText">{key}</div>
                </Grid>
                <Grid item xs={6}>
                  <div
                    className="headerText"
                    onClick={(event) =>
                      Array.isArray(value) && handleArrayClick(value, event)
                    }
                    style={{
                      cursor: Array.isArray(value) ? "pointer" : "default",
                      color: Array.isArray(value) ? "#852598" : "#112333",
                      textDecoration: Array.isArray(value)
                        ? "underline"
                        : "none",
                    }}
                  >
                    {renderValue(value)}
                  </div>
                </Grid>
              </Grid>
            </div>
          ))
        ) : (
          <div
            style={{
              width: "100%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "129px",
            }}
          >
            <CircularProgress color="secondary" />
          </div>
        )}
        <Popover
          open={Boolean(popoverAnchor)}
          anchorEl={popoverAnchor}
          onClose={handleClosePopover}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "center",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "center",
          }}
          PaperProps={{
            style: {
              border: "1px solid #D3BED7",
              background: "#F5F2F5",
              padding: "20px",
              boxShadow: "0px 0px 0px 0px rgba(0, 0, 0, 0.08)",
            },
          }}
        >
          <div>
            {selectedArray.map((item, index) => (
              <div
                key={index}
                style={{ marginTop: index === 0 ? "0px" : "10px" }}
              >
                {item}
              </div>
            ))}
          </div>
        </Popover>
      </div>
    </>
  );
};

export default SummaryBox;
