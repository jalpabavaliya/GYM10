import React, { useState, useEffect } from "react";
import "../../style.css";

const InputDragNDrop = ({ setSelectedFile, selectedFile }) => {
  const [dragging, setDragging] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState(null);
  const [selectedFileHere, setSelectedFileHere] = useState(
    selectedFile || null
  );

  const handleDragEnter = (e) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const files = e.dataTransfer.files;

    setSelectedFileHere(files);

    if (files.length > 0) {
      setSelectedFileName(files[0].name);
    }
  };

  const handleFileInput = (e) => {
    const files = e.target.files;
    setSelectedFileHere(files);
    if (files.length > 0) {
      setSelectedFileName(files[0].name);
    }
  };

  useEffect(() => {
    if (selectedFile) {
      setSelectedFile({ selectedFileHere });
    }
    if (selectedFile?.length > 0) {
      setSelectedFileName(selectedFile[0]?.name);
    }
  }, [selectedFileHere]);

  const handleBoxClick = () => {
    document.getElementById("fileInput").click();
  };

  return (
    <div
      className={`DropBox ${dragging ? "Dragging" : ""}`}
      onDragEnter={handleDragEnter}
      onDragOver={(e) => e.preventDefault()}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={handleBoxClick} // Trigger file input click when the box is clicked
    >
      {selectedFileName ? (
        <div>
          <div className="FileName">{selectedFileName}</div>
        </div>
      ) : dragging ? (
        <div>
          <div className="DragText">Drop your files here</div>
        </div>
      ) : (
        <div style={{}}>
          <div className="DragText">Drag & drop your files here or</div>
          <label
            htmlFor="fileInput"
            className="BrowseText"
            style={{ justifyContent: "center", marginTop: "10px" }}
          >
            Browse
          </label>
        </div>
      )}
      <input
        id="fileInput"
        type="file"
        onChange={handleFileInput}
        style={{ display: "none" }}
      />
    </div>
  );
};

export default InputDragNDrop;
