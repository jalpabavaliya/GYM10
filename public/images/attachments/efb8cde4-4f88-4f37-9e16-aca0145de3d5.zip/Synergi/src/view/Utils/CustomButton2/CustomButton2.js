import React from "react";
import Button from "@mui/material/Button";
import "../../style.css";

const CustomButton2 = ({ CustomIcon, onClick, buttonValue, style }) => {
  return (
    <Button
      onClick={onClick}
      style={{
        borderRadius: "5px",
        border: "1px solid #A35BB1",
        background: "#FFF",
        color: "#A35BB1",
        fontFamily: "Roboto",
        fontStyle: "normal",
        height: "33px",
        fontSize: "12px",
        ...style,
      }}
    >
      <div
        style={{
          transform: "scale(0.75)",
          display: "inline-flex",
          justifyContent: "center",
          alignItems: "center",
          marginRight: "8px",
        }}
      >
        {CustomIcon}
      </div>
      {buttonValue}
    </Button>
  );
};

export default CustomButton2;
