import * as React from "react";
import TextField from "@mui/material/TextField";
import IconButton from "@mui/material/IconButton";
import SearchIcon from "@mui/icons-material/Search";
import "../../style.css";

export const SearchBar = () => {
  const containerStyle = {
    display: "flex",
    alignItems: "center",
  };

  const inputStyle = {
    height: "35px",
    borderRadius: "44px",
    border: "1px solid var(--border-light, #D0CBC3)",
    background: "var(--background-light-bg-03, #EFECE8)",
    width: "12vw",
  };

  const placeholderStyle = {
    color: "var(--text-txt-primary, #6d6961)",
    fontFamily: "DM Sans",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: "700",
    lineHeight: "26px",
  };
  const focusStyle = {
    "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#6d6961", // Set the outline color to black when focused
    },
  };

  return (
    <div style={containerStyle}>
      <TextField
        variant="outlined"
        placeholder="Search"
        InputProps={{
          style: inputStyle,
          endAdornment: (
            <IconButton edge="end" aria-label="search">
              <SearchIcon />
            </IconButton>
          ),
        }}
        inputProps={{
          style: placeholderStyle,
        }}
        sx={focusStyle}
      />
    </div>
  );
};
