import React, { useState, useEffect } from "react";
import {
  Checkbox,
  FormControlLabel,
  TextField,
  Select,
  MenuItem,
  FormControl,
  styled,
} from "@mui/material";

const StyledCheckbox = styled(Checkbox)(`
  color: #E08029;

  &.Mui-checked {
    color: #E08029;
  }
`);

const StyledTextField = styled(TextField)(`
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  input[type="number"] {
    margin-left: 5px;
    -moz-appearance: textfield;
  }

  & .MuiInputBase-root {
    padding: 0;
  }

  & .MuiInputBase-input {
    padding: 1px;
    height: 31px;
    width: 90px;
  }
`);

const SpendingLimit = ({ onLimitChange, spendingLimit, flag = true }) => {
  const [noLimit, setNoLimit] = useState(spendingLimit?.noLimit);
  const [period, setPeriod] = useState(spendingLimit?.period);
  const [min, setMin] = useState(spendingLimit?.min);
  const [max, setMax] = useState(spendingLimit?.max);

  const handleNoLimitChange = (event) => {
    setNoLimit(event.target.checked);
  };

  const handlePeriodChange = (event) => {
    setPeriod(event.target.value);
  };

  const handleMinChange = (event) => {
    setMin(event.target.value);
  };

  const handleMaxChange = (event) => {
    setMax(event.target.value);
  };

  useEffect(() => {
    onLimitChange({
      noLimit,
      period,
      min,
      max,
    });
  }, [noLimit, period, min, max]);

  return (
    <>
      {flag && (
        <FormControlLabel
          control={
            <StyledCheckbox checked={noLimit} onChange={handleNoLimitChange} />
          }
          label="No spending limit"
          style={{ color: "#E08029", width: "187px" }}
        />
      )}
      <FormControl disabled={noLimit}>
        <div style={{ display: "flex" }}>
          {flag && (
            <Select
              value={period}
              onChange={handlePeriodChange}
              className="normalText"
              style={{ width: "130px", height: "33px", marginRight: "20px" }}
            >
              <MenuItem
                value="daily"
                className="normalText"
                style={{ fontSize: "10px" }}
              >
                Daily
              </MenuItem>
              <MenuItem
                value="monthly"
                className="normalText"
                style={{ fontSize: "10px" }}
              >
                Monthly
              </MenuItem>
              <MenuItem
                value="quarterly"
                className="normalText"
                style={{ fontSize: "10px" }}
              >
                Quarterly
              </MenuItem>
            </Select>
          )}

          <StyledTextField
            value={min}
            onChange={handleMinChange}
            placeholder="  Min"
            type="number"
            InputProps={{
              endAdornment: (
                <div
                  style={{
                    color: noLimit ? "disabled" : "secondary",
                    padding: "4px",
                  }}
                >
                  USD
                </div>
              ),
            }}
            color="secondary"
            disabled={noLimit}
          />

          <StyledTextField
            value={max}
            onChange={handleMaxChange}
            placeholder="  Max"
            type="number"
            InputProps={{
              endAdornment: (
                <div
                  style={{
                    color: noLimit ? "disabled" : "secondary",
                    padding: "4px",
                  }}
                >
                  USD
                </div>
              ),
            }}
            color="secondary"
            disabled={noLimit}
            style={{ marginLeft: "20px" }}
          />
        </div>
      </FormControl>
    </>
  );
};

export default SpendingLimit;
