// DateTimeInput.js

import React, { useState, useEffect } from "react";
import { FormControlLabel, Checkbox } from "@mui/material";

const DateTimeInput = ({ onDateTimeChange, dateTimeData }) => {
  const [startDate, setStartDate] = useState(dateTimeData?.startDate);
  const [startTime, setStartTime] = useState(dateTimeData?.startTime);
  const [endDate, setEndDate] = useState(dateTimeData?.endDate);
  const [endTime, setEndTime] = useState(dateTimeData?.endTime);
  const [showEndDate, setShowEndDate] = useState(
    Boolean(dateTimeData.endDate || dateTimeData.endTime)
  );

  useEffect(() => {
    onDateTimeChange({ startDate, startTime, endDate, endTime });
  }, [startDate, startTime, endDate, endTime]);

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", alignItems: "center" }}>
        <div>
          <div className="normalText">Start Date</div>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="date-input"
          />
        </div>
        <div style={{ marginLeft: "20px" }}>
          <div className="normalText">Start Time</div>
          <input
            type="time"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            className="date-input"
          />
        </div>
        <div style={{ marginLeft: "40px" }}>
          <FormControlLabel
            control={
              <Checkbox
                checked={showEndDate}
                onChange={() => {
                  setEndDate("");
                  setEndTime("");
                  setShowEndDate(!showEndDate);
                }}
                color="secondary"
              />
            }
            label={<div className="normalText">Set An End Date</div>}
            style={{
              width: "187px",
              fontWeight: "400",
              textAlign: "center",
            }}
          />
        </div>
      </div>

      {showEndDate && (
        <div style={{ display: "flex", marginTop: "20px" }}>
          <div>
            <div className="normalText">End Date</div>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="date-input"
            />
          </div>
          <div style={{ marginLeft: "20px" }}>
            <div className="normalText">End Time</div>
            <input
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="date-input"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default DateTimeInput;
