import {
  CustomDirectMailIcon,
  CustomEMailIcon,
  CustomTelemarketingIcon,
  CustomSmsIcon,
  CustomSocialMediaIcon,
  CustomPaidDisplayIcon,
  CustomPaidSearchIcon,
} from "./icons";

const channelIconMapping = {
  "Direct Mail": CustomDirectMailIcon,
  Email: CustomEMailIcon,
  Telemarketing: CustomTelemarketingIcon,
  SMS: CustomSmsIcon,
  "Social Media": CustomSocialMediaIcon,
  "Paid Display": CustomPaidDisplayIcon,
  "Paid Search": CustomPaidSearchIcon,
};

export default channelIconMapping;
