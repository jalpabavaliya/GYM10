import React, { useEffect } from "react";
import { useReactiveVar } from "@apollo/client";
import AboutCampaign from "./AboutCampaign/AboutCampaign";
import DataSource from "./DataSource/DataSource";
import Segments from "./Segments/Segments";
import Offers from "./Offers/Offers";
import FinalizeConfirm from "./FinalizeConfirm/FinalizeConfirm";

import {
  campaignPageType as PageType,
  aboutCampaignData as setAboutCampaignData,
  dataSourceData as setDataSourceData,
  segmetsData as setSegmentsData,
  offersData as setOffersData,
} from "./GlobalStore/index";
import CustomStepper from "./Components/Header/CustomStepper/CustomStepper";
import "../style.css";
import { Paper } from "@mui/material";
import AllCampaigns from "../AllCampaigns/AllCampaigns";

const Campaigns = () => {
  const isPageType = useReactiveVar(PageType);
  const aboutCampaignData = useReactiveVar(setAboutCampaignData);
  const dataSourceData = useReactiveVar(setDataSourceData);
  const segmetsData = useReactiveVar(setSegmentsData);
  const offersData = useReactiveVar(setOffersData);

  let pageComponent;
  if (isPageType === 1) {
    pageComponent = <AboutCampaign />;
  } else if (isPageType === 2) {
    pageComponent = <DataSource />;
  } else if (isPageType === 3) {
    pageComponent = <Segments />;
  } else if (isPageType === 4) {
    pageComponent = <Offers />;
  } else if (isPageType === 5) {
    pageComponent = <FinalizeConfirm />;
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  useEffect(() => {}, [aboutCampaignData]);

  useEffect(() => {}, [dataSourceData]);

  useEffect(() => {}, [segmetsData]);

  useEffect(() => {
    // console.log("offersData", offersData);
  }, [offersData]);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  return (
    <Paper
      sx={{
        backgroundColor: "#ffffff",
        width: "100%",
        height: "100%",
        borderRadius: "6px",
        margin: "10px",
        padding: "10px",
      }}
    >
      <CustomStepper type={isPageType - 1} />
      {pageComponent}
      {/* <AllCampaigns /> */}
      {/* <Grid container direction="column" sx={{ backgroundColor: "#FAF8F7" }}>
        <Grid item>
          <Header />
        </Grid>
        <Grid item sx={{ mt: "10px", mb: "5px" }}>
          <SubHeader title="Campaigns" />
        </Grid>
        <Grid item>
          <Grid container spacing={2}>
            <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}>
              <SideBar />
            </Grid>
            <Grid
              item
              xs={12}
              sm={8.6}
              md={8.6}
              lg={9.6}
              sx={{
                bgcolor: "background.paper",
                m: 2,
                borderRadius: 2,
              }}
            >
              <section
                style={{
                  display: "flex",
                  flexDirection: "column",
                  rowGap: "1rem",
                }}
              >
                <CustomStepper type={isPageType - 1} />
                {pageComponent}
              </section>
            </Grid>
          </Grid>
        </Grid>
        <Grid item sx={{ paddingLeft: "35vh" }}>
          <MainFooter />
        </Grid>
      </Grid> */}
    </Paper>
  );
};

export default Campaigns;
