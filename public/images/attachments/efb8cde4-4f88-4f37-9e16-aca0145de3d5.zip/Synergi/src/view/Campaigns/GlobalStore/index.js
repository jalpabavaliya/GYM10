import { makeVar } from "@apollo/client";

export const campaignPageType = makeVar(1);

export const aboutCampaignData = makeVar({});
export const dataSourceData = makeVar({ AIData: [] });
export const segmetsData = makeVar([]);
export const offersData = makeVar([]);
