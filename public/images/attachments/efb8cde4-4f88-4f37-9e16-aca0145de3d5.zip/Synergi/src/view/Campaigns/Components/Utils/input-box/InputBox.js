import { Input } from "@mui/material";
import TextField from "@mui/material/TextField";
import React from "react";
export const InputBox = ({
  placeholder,
  inputStyle,
  placeHolderStyles,
  rows,
  isMultiLine,
  onChange,
  textFieldsStyles,
}) => {
  const [input, setInput] = React.useState("");
  return (
    <TextField
      multiline={isMultiLine}
      variant='outlined'
      placeholder={placeholder}
      InputProps={{
        style: { ...inputStyle },
      }}
      InputLabelProps={{
        style: { ...placeHolderStyles },
      }}
      onChange={(event) => {
        setInput(event.target.value);
        onChange(input);
      }}
      rows={rows}
    />
  );
};
