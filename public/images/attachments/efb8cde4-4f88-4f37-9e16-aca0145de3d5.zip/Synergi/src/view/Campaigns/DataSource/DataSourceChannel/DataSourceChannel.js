import React, { useState, useEffect } from "react";
import { useReactiveVar } from "@apollo/client";

import { Box, Typography } from "@mui/material";
import { styled } from "@mui/system";
import DataSourceAI from "./DataSourceAI/DataSourceAI";
import DataSourceManual from "./DataSourceManual/DataSourceManual";
import { dataSourceData as setDataSourceData } from "../../GlobalStore";

let manualInput = {
  statusCode: 200,
  body: [
    { channel: "direct mail", Vendors: ["Jetson", "UPSC"] },
    { channel: "email", Vendors: ["Adobe", "Hubspot", "Mailchimp"] },
    {
      channel: "paid search/ paid display",
      Vendors: ["Google Ads", "Microsoft Bing"],
    },
    { channel: "social media", Vendors: ["Facebook", "Linkedin", "Twitter"] },
    { channel: "application management", Vendors: ["Encompass"] },
    {
      channel: "behavioral triggers",
      Vendors: ["Jornaya", "DialogTech", "Invoca"],
    },
    { channel: "call tracking", Vendors: ["Invoca", "DialogTech"] },
    { channel: "chat", Vendors: ["Livechat"] },
  ],
};

const DataSourceChannel = ({ DataSourceAiAPI }) => {
  const dataSourceData = useReactiveVar(setDataSourceData);

  const [selectedChannel, setChannel] = useState(
    dataSourceData?.channelType || "Ai"
  );

  const [selectedChannelFile, setChannelFile] = useState(
    dataSourceData?.channelFile || []
  );

  const StyledBoxAI = styled(Box)(({ theme }) => ({
    marginLeft: "10px",
    width: "200px",
    cursor: "pointer",
    textAlign: "center",
    borderBottom: selectedChannel === "Ai" ? "3px solid #764F7D" : "",
  }));

  const StyledBoxManual = styled(Box)(({ theme }) => ({
    width: "200px",
    cursor: "pointer",
    textAlign: "center",
    borderBottom: selectedChannel === "manual" ? "3px solid #764F7D" : "",
  }));

  useEffect(() => {
    setChannel(dataSourceData?.channelType || "Ai");
    setChannelFile(dataSourceData?.channelFile || []);
    if (!dataSourceData?.channelType) {
      const currentDataSourceData = setDataSourceData();
      setDataSourceData({
        ...currentDataSourceData,
        channelType: "Ai",
      });
    }
  }, []);

  const handleChannelSelection = (selection) => {
    setChannel(selection);
    const currentDataSourceData = setDataSourceData();
    setDataSourceData({
      ...currentDataSourceData,
      channelType: selection,
    });
  };

  const handleFileChange = (selectedFile) => {
    setChannelFile(selectedFile.selectedFileHere);
    const currentDataSourceData = setDataSourceData();
    setDataSourceData({
      ...currentDataSourceData,
      channelFile: selectedFile.selectedFileHere,
    });
  };

  const renderComponent = () => {
    if (selectedChannel === "Ai") {
      return <DataSourceAI DataSourceAiAPI={DataSourceAiAPI} />;
    } else {
      return <DataSourceManual manualInput={manualInput} />;
    }
  };

  return (
    <>
      <Box display="flex" alignItems="center">
        <StyledBoxAI
          p={2}
          onClick={() => {
            handleChannelSelection("Ai");
          }}
        >
          <Typography
            variant="body1"
            style={{
              fontWeight: selectedChannel === "Ai" ? "700" : "400",
              color:
                selectedChannel === "Ai"
                  ? "#764F7D"
                  : "var(--text-txt-primary, #112333)",

              fontFamily: "DM Sans",
              fontSize: "16px",
              fontStyle: "normal",
              lineHeight: "15px",
            }}
          >
            AI-Predictive Allocation
          </Typography>
        </StyledBoxAI>

        <StyledBoxManual
          p={2}
          onClick={() => {
            handleChannelSelection("manual");
          }}
        >
          <Typography
            variant="body1"
            style={{
              fontWeight: selectedChannel === "manual" ? "700" : "400",
              color:
                selectedChannel === "manual"
                  ? "#764F7D"
                  : "var(--text-txt-primary, #112333)",
              fontFamily: "DM Sans",
              fontSize: "16px",
              fontStyle: "normal",
              lineHeight: "15px",
            }}
          >
            Manual Allocation
          </Typography>
        </StyledBoxManual>
      </Box>
      <div className="customHR"></div>
      <Box p={2} sx={{ overflow: "auto", display: "-webkit-box" }}>
        {renderComponent()}
      </Box>
    </>
  );
};

export default DataSourceChannel;
