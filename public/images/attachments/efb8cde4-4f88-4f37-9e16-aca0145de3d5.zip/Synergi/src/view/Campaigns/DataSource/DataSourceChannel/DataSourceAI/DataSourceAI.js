import React, { useState, useEffect } from "react";
import { useReactiveVar } from "@apollo/client";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Grid from "@mui/material/Grid";
import { Box } from "@mui/material";
import { dataSourceData as setDataSourceData } from "../../../GlobalStore";
import SouthEastIcon from "@mui/icons-material/SouthEast";
import NorthEastIcon from "@mui/icons-material/NorthEast";
import RemoveIcon from "@mui/icons-material/Remove";
import { CustomMailIcon } from "../../../../Utils/icons/icons";

const DataSourceAI = ({ DataSourceAiAPI }) => {
  const dataSourceData = useReactiveVar(setDataSourceData);
  const [checked, setChecked] = useState(() => {
    const initialCheckedState = {};
    (dataSourceData?.AIData || []).forEach((item) => {
      initialCheckedState[item.document_id] = true;
    });
    return initialCheckedState;
  });

  const handleChange = (event) => {
    const updatedChecked = {
      ...checked,
      [event.target.name]: event.target.checked,
    };
    setChecked(updatedChecked);

    const currentDataSourceData = setDataSourceData();
    if (event.target.checked) {
      setDataSourceData({
        ...currentDataSourceData,
        AIData: [
          ...currentDataSourceData.AIData.filter(
            (item) => item.document_id !== event.target.name
          ),
          {
            name: event.target.dataset.name,
            document_id: event.target.name,
          },
        ],
      });
    } else {
      setDataSourceData({
        ...currentDataSourceData,
        AIData: currentDataSourceData.AIData.filter(
          (item) => item.document_id !== event.target.name
        ),
      });
    }
  };

  useEffect(() => {
    const newCheckedState = {};
    (dataSourceData?.AIData || []).forEach((item) => {
      newCheckedState[item.document_id] = true;
    });
    setChecked(newCheckedState);
  }, [dataSourceData?.AIData]);

  return (
    <div style={{ padding: "10px" }}>
      <Grid container spacing={2} display="flex" gap={"5px"}>
        {DataSourceAiAPI &&
          DataSourceAiAPI.map((item, index) => (
            <React.Fragment key={item.pk}>
              <Grid container spacing={2} display="flex" key={item.pk}>
                <Grid item xs={8}>
                  <div>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checked[item.pk] || false}
                          onChange={handleChange}
                          name={item.pk}
                          color="secondary"
                          data-name={item.name}
                        />
                      }
                      label={
                        <Box display="flex">
                          <div style={{ marginRight: "10px" }}>
                            <CustomMailIcon />
                          </div>
                          <Box flexGrow={1}>
                            <div style={{ alignContent: "center" }}>
                              <div
                                className="headerText"
                                style={{
                                  color: "var(--col-14, #A35BB1)",
                                  display: "flex",
                                }}
                              >
                                {item.name}
                              </div>
                            </div>
                          </Box>
                        </Box>
                      }
                    />
                    <Box
                      display="flex"
                      sx={{ marginLeft: "58px", width: "75%" }}
                    >
                      <Box flexGrow={1} display="flex" flexDirection="column">
                        <div className="normalText">{item.description}</div>
                        <div
                          className="normalText"
                          style={{
                            color: "var(--col-14, #5D596C)",
                            fontSize: "10px",
                          }}
                        >
                          {item.created_datetime} By
                        </div>
                      </Box>
                    </Box>
                  </div>
                </Grid>

                <Grid item xs={4}>
                  <Box display="flex" justifyContent="flex-end">
                    <div>
                      {item.overall_status === "+" ? (
                        <div
                          className="predictivePKPI"
                          style={{ display: "flex" }}
                        >
                          Predictive KPIs{" "}
                          <NorthEastIcon
                            style={{
                              fontSize: "12px",
                              marginLeft: "5px",
                              color: "#158C6F",
                            }}
                          />
                        </div>
                      ) : item.overall_status === "-" ? (
                        <div
                          className="predictiveNKPI"
                          style={{ display: "flex" }}
                        >
                          Predictive KPIs{" "}
                          <SouthEastIcon
                            style={{
                              fontSize: "12px",
                              marginLeft: "5px",
                              color: "#8E0000",
                            }}
                          />
                        </div>
                      ) : (
                        <div
                          className="predictiveNKPI"
                          style={{ display: "flex", color: "#414446" }}
                        >
                          Predictive KPIs{" "}
                          <RemoveIcon
                            style={{
                              fontSize: "12px",
                              marginLeft: "5px",
                              color: "#414446",
                            }}
                          />
                        </div>
                      )}
                      <div
                        style={{
                          width: "233px",
                          textAlign: "left",
                          border: "1px solid #EBE8F1",
                          background: "#F6F5F8",
                          borderRadius: "5px",
                          padding: "5px",
                        }}
                      >
                        <Grid container>
                          {item.kpi &&
                            Object.entries(item.kpi).map(([key, value]) => (
                              <Grid
                                item
                                xs={12 / Object.keys(item.kpi).length}
                                key={key}
                              >
                                <Box>
                                  <div
                                    className="grid-content-key"
                                    style={{
                                      color: "var(--col-6, #5D596C)",
                                    }}
                                  >
                                    {key}
                                  </div>
                                  <br />
                                  <div
                                    className="grid-content-value"
                                    style={{
                                      color: "var(--col-6, #414446)",
                                    }}
                                  >
                                    {value}
                                  </div>
                                </Box>
                              </Grid>
                            ))}
                        </Grid>
                      </div>
                    </div>
                  </Box>
                </Grid>
              </Grid>
              {index < DataSourceAiAPI.length - 1 && (
                <div className="customHR"></div>
              )}
            </React.Fragment>
          ))}
      </Grid>
    </div>
  );
};

export default DataSourceAI;
