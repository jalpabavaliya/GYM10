import React, { useEffect, useState } from "react";
import { useReactiveVar } from "@apollo/client";
import {
  campaignPageType as PageType,
  offersData as setOffersData,
  aboutCampaignData as setAboutCampaignData,
} from "../GlobalStore";

import { Grid, Box, CircularProgress } from "@mui/material";
import CustomButton from "../../Utils/CustomButton/CustomButton";
import { CustomEditIcon } from "../../Utils/icons/icons";
import { getFinalizeAndConfirm } from "../../../services/CampaignService";
import FinalizeOfferChannel from "./FinalizeOfferChannel/FinalizeOfferChannel";

const FinalizeConfirm = () => {
  const isPageType = useReactiveVar(PageType);
  const offersData = useReactiveVar(setOffersData);
  const aboutCampaignData = useReactiveVar(setAboutCampaignData);
  const [offerData, setOfferData] = useState(offersData?.segmentData || []);

  const [dateTime, setDateTime] = useState(offersData?.dateTime);
  const [finalizeAndConfirmAPI, setFinalizeAndConfirmAPI] = useState();

  const [spendingLimit, setSpendingLimit] = useState(offersData?.spendingLimit);

  const handleNextButtonClick = () => {
    // PageType(4);
  };
  const handlePrevButtonClick = () => {
    PageType(4);
  };

  const editAboutCampaign = () => {
    PageType(1);
  };
  const editSegments = () => {
    PageType(2);
  };

  const editOffers = () => {
    PageType(4);
  };

  useEffect(() => {
    const transform = (data) => {
      const result = [];

      for (let key in data) {
        const segment = data[key];

        if (segment.selected) {
          let segment_offer = {
            segment_id: segment.segment_id,
            segment_name: segment.segment_name,
            offer_name: segment.offer_name,
            offer_start_datetime: `${segment.dateTimeData.startDate} ${segment.dateTimeData.startTime}`,
            offer_end_datetime: `${segment.dateTimeData.endDate} ${segment.dateTimeData.endTime}`,
            offer_id: segment.offer_id,
            selected_vendor_templates: [],
            offer_min_budget: segment.spendingLimit.min || 0,
            offer_max_budget: segment.spendingLimit.max || 0,
          };

          if (segment.selected_vendor_templates) {
            for (let vendor in segment.selected_vendor_templates) {
              segment_offer.selected_vendor_templates.push({
                vendor_name: vendor,
                vendor_template:
                  segment.selected_vendor_templates[vendor].vendor_template,
                vendor_tracking:
                  segment.selected_vendor_templates[vendor].vendor_tracking,
              });
            }
          }

          result.push(segment_offer);
        }
      }

      return result;
    };

    const raw = {
      campaign_id: aboutCampaignData.campaign_id,
      channel_segment_offer: [],
    };

    for (let channel in offersData.segmentData) {
      raw.channel_segment_offer.push({
        channel: channel,
        segment_offers: transform(offersData.segmentData[channel]),
      });
    }

    (async () => {
      const response = await getFinalizeAndConfirm(raw);
      setFinalizeAndConfirmAPI(response.data);
    })();
  }, []);

  return (
    <>
      {finalizeAndConfirmAPI ? (
        <div className="campaign-container">
          <div className="customHR"></div>

          <Grid container spacing={2}>
            <Grid item xs={8}>
              <div style={{ display: "grid", gap: "20px" }}>
                <div className="headerText" style={{ display: "flex" }}>
                  Review Campaign
                  <div
                    style={{ marginLeft: "30px", cursor: "pointer" }}
                    onClick={editAboutCampaign}
                  >
                    <CustomEditIcon />
                  </div>
                </div>
                <div className="normalText" style={{ width: "60%" }}>
                  Campaign Name: {finalizeAndConfirmAPI.name}
                </div>
                <div className="normalText" style={{ width: "60%" }}>
                  Campaign Description : {finalizeAndConfirmAPI.description}
                </div>
                <div className="normalText" style={{ width: "60%" }}>
                  Marketing Channel: {finalizeAndConfirmAPI.channels.join(", ")}
                </div>

                <div className="normalText" style={{ width: "60%" }}>
                  Objective: {finalizeAndConfirmAPI.objective}
                </div>
                <div className="normalText" style={{ width: "60%" }}>
                  Vendors: {finalizeAndConfirmAPI.vendors.join(", ")}
                </div>
                <div className="normalText" style={{ width: "60%" }}>
                  Data Source: {finalizeAndConfirmAPI.data_sources.join(", ")}
                </div>

                <div className="customHR"></div>

                <div className="headerText" style={{ display: "flex" }}>
                  Segments
                  <div
                    style={{ marginLeft: "30px", cursor: "pointer" }}
                    onClick={editSegments}
                  >
                    <CustomEditIcon />
                  </div>
                </div>
                <div className="normalText">
                  {finalizeAndConfirmAPI.segments.join(", ")}
                </div>

                <div className="customHR"></div>

                <div className="headerText" style={{ display: "flex" }}>
                  Offers
                  <div
                    style={{ marginLeft: "30px", cursor: "pointer" }}
                    onClick={editOffers}
                  >
                    <CustomEditIcon />
                  </div>
                </div>

                <div className="normalText" style={{ width: "60%" }}>
                  Please note: Where you don't see customized settings on a
                  channel card, date and budget parameters are shared and not
                  unique to that specific channel.
                </div>

                <div className="customHR"></div>

                <div>
                  <div className="normalText">
                    {dateTime?.startDate && dateTime?.startTime
                      ? `Start Date ${dateTime.startDate} ${dateTime.startTime} EST`
                      : "No start date"}{" "}
                    {dateTime?.endDate && dateTime?.endTime
                      ? `And End Date ${dateTime.endDate} ${dateTime.endTime} EST`
                      : "and no end date"}
                  </div>
                </div>
                <div className="normalText" style={{ color: "#E08029" }}>
                  {spendingLimit.noLimit
                    ? "No Spending Limits"
                    : `Spending limits: Period: ${spendingLimit.period}, Min: ${spendingLimit.min}, Max: ${spendingLimit.max}`}
                </div>
                {dateTime && spendingLimit && (
                  <>
                    <div className="customHR"></div>
                    <FinalizeOfferChannel
                      setOfferData={setOfferData}
                      globalDateTime={dateTime}
                      globalSpendingLimit={spendingLimit}
                    />
                  </>
                )}

                <div style={{ marginTop: "20px" }}>
                  <CustomButton
                    isDisabled={false}
                    onClick={handlePrevButtonClick}
                    buttonValue="Prev step"
                    style={{
                      color: "#852598",
                      backgroundColor: "#ffffff",
                      border: "1px solid #852598",
                    }}
                  />
                  <CustomButton
                    isDisabled={false}
                    onClick={handleNextButtonClick}
                    buttonValue="Save"
                    style={{}}
                  />
                </div>
              </div>
            </Grid>
            <Grid item xs={4}></Grid>
          </Grid>
        </div>
      ) : (
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: "32px",
          }}
        >
          <CircularProgress color="secondary" />
        </div>
      )}
    </>
  );
};

export default FinalizeConfirm;
