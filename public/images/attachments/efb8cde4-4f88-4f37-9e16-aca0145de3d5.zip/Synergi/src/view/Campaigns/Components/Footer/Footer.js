import React from "react";
import MainFooter from "../../../mainFooter/MainFooter";

const Footer = () => {
  return (
    <>
      <MainFooter />
    </>
  );
};
export default Footer;
