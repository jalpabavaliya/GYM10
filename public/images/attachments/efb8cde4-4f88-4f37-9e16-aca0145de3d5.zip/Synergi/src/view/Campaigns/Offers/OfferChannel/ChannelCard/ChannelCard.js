import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@mui/material";
import ChannelPopUp from "../ChannelPopUp/ChannelPopUp";
import { useReactiveVar } from "@apollo/client";
import channelIconMapping from "../../../../Utils/icons/channelIconMapping";
import {
  CustomizedIcon,
  SelectTemplateIcon,
} from "../../../../Utils/icons/icons";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import { offersData as setOffersData } from "../../../GlobalStore";
const ChannelCard = ({
  channelData,
  saveData,
  channel,
  globalDateTime,
  globalSpendingLimit,
}) => {
  const [open, setOpen] = useState(false);
  const offersData = useReactiveVar(setOffersData);

  const [isCustomized, setIsCustomized] = useState(false);
  const [isSaved, setIsSaved] = useState(
    offersData?.segmentData?.[channel]?.isSaved || false
  );
  const [isSegmentData, setSegmentData] = useState(
    offersData?.segmentData?.[channel] || {}
  );
  const handleClose = () => setOpen(false);
  const handleOpen = () => setOpen(true);

  const handleSave = (segmentData) => {
    setIsSaved(true);
    setSegmentData((prevState) => ({
      ...prevState,
    }));
    saveData(channelData.channel, segmentData);
    setSegmentData(segmentData);
    handleClose();
  };

  useEffect(() => {
    const areObjectsEqual = (obj1, obj2) => {
      const obj1Keys = Object.keys(obj1);
      const obj2Keys = Object.keys(obj2);

      if (obj1Keys.length !== obj2Keys.length) {
        return false;
      }

      for (const key of obj1Keys) {
        if (obj1[key] !== obj2[key]) {
          return false;
        }
      }

      return true;
    };

    let isCustomizedFlag = false;
    for (const segmentName in isSegmentData) {
      const segment = isSegmentData?.[segmentName];
      if (segment?.dateTimeData && segment?.spendingLimit) {
        if (
          !areObjectsEqual(segment?.dateTimeData, globalDateTime) ||
          !areObjectsEqual(segment?.spendingLimit, globalSpendingLimit)
        ) {
          isCustomizedFlag = true;
          break;
        }
      }
    }
    setIsCustomized(isCustomizedFlag);
  }, [globalDateTime, globalSpendingLimit, isSaved, isSegmentData]);

  return (
    <Card
      sx={{
        width: "215.12px",
        height: "133.675px",
        cursor: "pointer",
        borderRadius: "5px",
        border: "1px solid #EBE8F1",
        background: "#FFF",
        boxShadow: "0px 8px 20px 0px rgba(0, 0, 0, 0.06)",
      }}
      onClick={handleOpen}
    >
      <CardContent>
        <div
          className="headerText"
          style={{
            display: "flex",
            justifyContent: "space-between",
            fontSize: "14px",
            textTransform: "capitalize",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex" }}>
            <div style={{ marginRight: "10px" }}>
              {React.createElement(channelIconMapping[channelData.channel])}
            </div>
            {channelData.channel}
          </div>
          {isSaved && <CheckBoxIcon color="secondary" />}
        </div>

        <div className="customHR"></div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            marginBottom: "10px",
          }}
        >
          <div className="card-number" style={{ marginRight: "5px" }}>
            {channelData.total_offers}
          </div>
          <div className="normalText" style={{ marginRight: "5px" }}>
            matched offers
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center" }}>
          {isCustomized && (
            <>
              <CustomizedIcon />

              <div
                className="normalText"
                style={{
                  color: "#A35BB1",
                  marginLeft: "7px",
                  fontSize: "12px",
                }}
              >
                Customized Settings
              </div>
            </>
          )}

          {!isSaved && (
            <>
              <SelectTemplateIcon />

              <div
                className="normalText"
                style={{
                  color: "#A35BB1",
                  marginLeft: "7px",
                  fontSize: "12px",
                }}
              >
                Select Template
              </div>
            </>
          )}
        </div>
      </CardContent>
      <ChannelPopUp
        open={open}
        handleClose={handleClose}
        handleSave={handleSave}
        channelData={channelData}
        channel={channel}
        globalDateTime={globalDateTime}
        globalSpendingLimit={globalSpendingLimit}
      />
    </Card>
  );
};

export default ChannelCard;
