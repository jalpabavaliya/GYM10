import React, { useEffect, useState } from "react";
import { useReactiveVar } from "@apollo/client";
import {
  campaignPageType as PageType,
  dataSourceData as setDataSourceData,
  aboutCampaignData as setAboutCampaignData,
} from "../GlobalStore";
import { Grid, Box, CircularProgress } from "@mui/material";
import DataSourceChannel from "./DataSourceChannel/DataSourceChannel";
import CustomButton from "../../Utils/CustomButton/CustomButton";

// import InputDragNDrop from "../../Utils/InputDragNDrop/InputDragNDrop";
import SummaryBox from "../../Utils/SummaryBox/SummaryBox";
import { getDataSourceAI } from "../../../services/CampaignService";

const DataSource = () => {
  const aboutCampaignData = useReactiveVar(setAboutCampaignData);
  // const dataSourceData = useReactiveVar(setDataSourceData);

  const [getCampaignSummary, setCampaignSummary] = useState(null);
  const [DataSourceAiAPI, setDataSourceAiAPI] = useState("");

  // const [selectedChannelFile, setChannelFile] = useState(
  //   dataSourceData?.channelFile || []
  // );

  const handleNextButtonClick = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
    PageType(3);
  };
  const handlePrevButtonClick = () => {
    PageType(1);
  };

  // const handleFileChange = (selectedFile) => {
  //   setChannelFile(selectedFile.selectedFileHere);
  //   const currentDataSourceData = setDataSourceData();
  //   setDataSourceData({
  //     ...currentDataSourceData,
  //     channelFile: selectedFile.selectedFileHere,
  //   });
  // };

  const transformManualData = (data) => {
    const transformedData = [];

    Object.entries(data).forEach(([channel, vendorsObj]) => {
      const vendors = Object.entries(vendorsObj)
        .filter(([vendor, selected]) => selected)
        .map(([vendor, selected]) => vendor);
      if (vendors.length > 0) {
        transformedData.push({ channel, vendors });
      }
    });

    return transformedData;
  };

  useEffect(() => {
    let channelData = [];

    if (aboutCampaignData.channelType === "Ai") {
      channelData = aboutCampaignData.AIdata;
    } else {
      const transformedManualData = transformManualData(
        aboutCampaignData.manualData
      );
      channelData = transformedManualData;
    }

    var raw = JSON.stringify({
      name: aboutCampaignData.name,
      objective: aboutCampaignData.objective,
      selected_channel_vendors: channelData,
      description: aboutCampaignData.description,
    });
    setCampaignSummary(raw);

    (async () => {
      const response = await getDataSourceAI("document");
      setDataSourceAiAPI(response.data);
      console.log("check response datasource.js: ", response.data);
    })();
  }, []);

  return (
    <>
      {DataSourceAiAPI ? (
        <div className="campaign-container">
          <div className="customHR"></div>

          <Grid container spacing={2}>
            <Grid item xs={7}>
              <div style={{ display: "grid", gap: "20px" }}>
                <div className="headerText">
                  Choose Your Campaign Data Source
                </div>
                <div className="normalText">
                  Select 'AI-Recommended Data' for streamlined, efficient data
                  sourcing.
                </div>

                <div
                  style={{
                    borderRadius: "5px",
                    border: "1px solid #EBE8F1",
                    width: "693px",
                  }}
                >
                  {" "}
                  {DataSourceAiAPI && (
                    <DataSourceChannel DataSourceAiAPI={DataSourceAiAPI} />
                  )}
                </div>

                <div className="customHR"></div>

                <div style={{ marginTop: "20px" }}>
                  <CustomButton
                    isDisabled={false}
                    onClick={handlePrevButtonClick}
                    buttonValue="Prev step"
                    style={{
                      color: "#852598",
                      backgroundColor: "#ffffff",
                      border: "1px solid #852598",
                    }}
                  />
                  <CustomButton
                    isDisabled={!DataSourceAiAPI}
                    onClick={handleNextButtonClick}
                    buttonValue="Next"
                    style={{}}
                  />
                </div>
              </div>
            </Grid>
            <Grid item xs={5}>
              <Box display="flex" justifyContent="flex-end">
                {getCampaignSummary && (
                  <SummaryBox CampaignSummary={getCampaignSummary} which={1} />
                )}
              </Box>
            </Grid>
          </Grid>
        </div>
      ) : (
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: "32px",
          }}
        >
          <CircularProgress color="secondary" />
        </div>
      )}
    </>
  );
};

export default DataSource;
