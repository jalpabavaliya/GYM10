import React, { useState, useEffect } from "react";
import { useReactiveVar } from "@apollo/client";
import {
  campaignPageType as PageType,
  offersData as setOffersData,
  segmetsData as setSegmetsData,
  aboutCampaignData as setAboutCampaignData,
} from "../GlobalStore";
import { Grid, Box, CircularProgress } from "@mui/material";
import CustomButton from "../../Utils/CustomButton/CustomButton";

import DateTimeInput from "../../Utils/DateTimeInput/DateTimeInput";
import SpendingLimit from "../../Utils/SpendingLimit/SpendingLimit";
import OfferChannel from "./OfferChannel/OfferChannel";
import SummaryBox from "../../Utils/SummaryBox/SummaryBox";
import { getSegmentOffers } from "../../../services/CampaignService";

const Offers = () => {
  const isPageType = useReactiveVar(PageType);
  const offersData = useReactiveVar(setOffersData);
  const segmetsData = useReactiveVar(setSegmetsData);
  const aboutCampaignData = useReactiveVar(setAboutCampaignData);

  const [offerData, setOfferData] = useState(offersData?.segmentData || []);
  const [getCampaignSummary, setCampaignSummary] = useState(null);
  const [numberOfOffers, setNumberOfOffers] = useState(null);
  const [channelRows, setChannelRows] = useState();

  const currentDate = new Date();

  const formattedDate = (date) => {
    let month = "" + (date.getMonth() + 1);
    let day = "" + date.getDate();
    const year = date.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const formattedTime = (date) => {
    let hours = "" + date.getHours();
    let minutes = "" + date.getMinutes();

    if (hours.length < 2) hours = "0" + hours;
    if (minutes.length < 2) minutes = "0" + minutes;

    return [hours, minutes].join(":");
  };

  const [dateTime, setDateTime] = useState(
    offersData?.dateTime || {
      startDate: formattedDate(currentDate),
      startTime: formattedTime(currentDate),
      endDate: "",
      endTime: "",
    }
  );

  const [spendingLimit, setSpendingLimit] = useState(
    offersData?.spendingLimit || {
      noLimit: true,
      period: "daily",
      min: "",
      max: "",
    }
  );

  const handleDateTimeChange = (dateObj) => {
    setDateTime(dateObj);
  };

  const DataSize = Object.keys(offerData).length;
  let isNextEnabled = DataSize === numberOfOffers;

  const handleNextButtonClick = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
    PageType(5);
  };

  const handlePrevButtonClick = () => {
    PageType(3);
  };

  const handleLimitChange = (limitData) => {
    setSpendingLimit(limitData);
  };

  useEffect(() => {
    let channelData = segmetsData?.AIData;

    var raw = JSON.stringify({
      segments: channelData,
      campaign_id: aboutCampaignData.campaign_id,
    });

    setCampaignSummary(raw);
  }, [segmetsData]);

  useEffect(() => {
    setOffersData({
      segmentData: offerData,
      dateTime: dateTime,
      spendingLimit: spendingLimit,
    });
  }, [offerData, dateTime, spendingLimit]);

  useEffect(() => {
    (async () => {
      const response = await getSegmentOffers();
      let temp = [];
      setNumberOfOffers(response.data.response.length);
      for (let i = 0; i < response.data.response.length; i += 3) {
        temp.push(response.data.response.slice(i, i + 3));
      }
      setChannelRows(temp);
    })();
  }, []);

  return (
    <>
      {channelRows ? (
        <div className="campaign-container">
          <div className="customHR"></div>

          <Grid container spacing={2}>
            <Grid item xs={7}>
              <div style={{ display: "grid", gap: "20px" }}>
                <div className="headerText">Offers</div>
                <div className="normalText">
                  Click on a channel to select and fine-tune offers. AI has
                  auto-selected optimal offers for each channel. For details,
                  simply tap the channel name.
                </div>
                <div className="customHR"></div>

                <div className="headerText">Settings</div>
                <div
                  className="normalText"
                  style={{ textTransform: "capitalize" }}
                >
                  For a unified campaign, set date/budget below, or customize
                  individually by selecting each channel card.
                </div>

                <DateTimeInput
                  onDateTimeChange={handleDateTimeChange}
                  dateTimeData={dateTime}
                />

                <div style={{ display: "grid" }}>
                  <div className="normalText">Budget</div>
                  <SpendingLimit
                    onLimitChange={handleLimitChange}
                    spendingLimit={spendingLimit}
                  />
                </div>

                <div className="customHR"></div>
                <div className="normalText">
                  Click on each channel card to configure templates and modify
                  dates or budget for the vendors within each channel.
                </div>

                <OfferChannel
                  globalDateTime={dateTime}
                  globalSpendingLimit={spendingLimit}
                  setOfferData={setOfferData}
                  channelRows={channelRows}
                />

                <div style={{ marginTop: "20px" }}>
                  <CustomButton
                    isDisabled={false}
                    onClick={handlePrevButtonClick}
                    buttonValue="Prev step"
                    style={{
                      color: "#852598",
                      backgroundColor: "#ffffff",
                      border: "1px solid #852598",
                      marginLeft: "0",
                    }}
                  />
                  <CustomButton
                    isDisabled={false}
                    onClick={handleNextButtonClick}
                    buttonValue="Next"
                    style={{}}
                  />
                </div>
              </div>
            </Grid>
            <Grid item xs={5}>
              <Box display="flex" justifyContent="flex-end">
                {getCampaignSummary && (
                  <SummaryBox CampaignSummary={getCampaignSummary} which={3} />
                )}
              </Box>
            </Grid>
          </Grid>
        </div>
      ) : (
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: "32px",
          }}
        >
          <CircularProgress color="secondary" />
        </div>
      )}
    </>
  );
};

export default Offers;
