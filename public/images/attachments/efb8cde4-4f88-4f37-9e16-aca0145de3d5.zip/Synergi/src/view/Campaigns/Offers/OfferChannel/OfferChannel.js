import React, { useState, useEffect } from "react";
import ChannelCard from "./ChannelCard/ChannelCard";
import { getSegmentOffers } from "../../../../services/CampaignService";

const OfferChannel = ({
  globalDateTime,
  globalSpendingLimit,
  setOfferData,
  channelRows,
}) => {
  const saveData = (channel, segementData) => {
    setOfferData((prevState) => ({
      ...prevState,
      [channel]: {
        ...segementData,
        isSaved: true,
      },
    }));
  };

  return (
    <div>
      {channelRows &&
        channelRows.map((rowChannels, rowIndex) => (
          <div
            key={rowIndex}
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "10px",
            }}
          >
            {rowChannels &&
              rowChannels.map((channelData, index) => (
                <div style={{ marginLeft: index === 0 ? "0px" : "20px" }}>
                  <ChannelCard
                    key={channelData.channel}
                    channelData={channelData}
                    saveData={saveData}
                    channel={channelData.channel}
                    globalDateTime={globalDateTime}
                    globalSpendingLimit={globalSpendingLimit}
                  />
                </div>
              ))}
          </div>
        ))}
    </div>
  );
};

export default OfferChannel;
