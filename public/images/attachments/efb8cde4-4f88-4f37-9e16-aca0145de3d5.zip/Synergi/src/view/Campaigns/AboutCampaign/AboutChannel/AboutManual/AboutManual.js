import { useState, useEffect } from "react";
import { useReactiveVar } from "@apollo/client";
import { aboutCampaignData as setAboutCampaignData } from "../../../GlobalStore";

import {
  Card,
  CardHeader,
  Checkbox,
  FormControlLabel,
  FormGroup,
  CardContent,
} from "@mui/material";

const AboutManual = ({ manualInput, setChannelData }) => {
  const aboutCampaignData = useReactiveVar(setAboutCampaignData);

  const [selected, setSelected] = useState(aboutCampaignData?.manualData || {});

  useEffect(() => {
    setSelected(aboutCampaignData?.manualData || {});
  }, [aboutCampaignData?.objective]);

  useEffect(() => {
    const currentCampaignData = setAboutCampaignData();
    setAboutCampaignData({
      ...currentCampaignData,
      manualData: selected,
    });
  }, [selected]);

  const handleCheckChange = (channel, vendor) => (event) => {
    setSelected({
      ...selected,
      [channel]: { ...selected[channel], [vendor]: event.target.checked },
    });
  };

  const handleCheckAllChange = (channel, vendors) => (event) => {
    let areAllChecked;
    if (selected[channel]) {
      areAllChecked = Object.values(selected[channel]).every((val) => val);
    } else {
      areAllChecked = false;
    }

    const vendorsObj = vendors.reduce(
      (acc, cur) => ({ ...acc, [cur]: !areAllChecked }),
      {}
    );

    setSelected({
      ...selected,
      [channel]: vendorsObj,
    });
  };

  return (
    <div
      style={{
        display: "flex",
        width: "auto",
        gap: "15px",
      }}
    >
      {manualInput.map((item, index) => (
        <Card
          key={index}
          style={{
            width: "280px",
            height: "257px",
            flexShrink: "0",
            borderRadius: "5px",
            border: "1px solid #EBE8F1",
            background: "#FFF",
            boxShadow: "0px 8px 20px 0px rgba(0, 0, 0, 0.06)",
          }}
        >
          <CardHeader
            title={item.channel}
            action={
              <FormControlLabel
                control={
                  <Checkbox
                    onChange={(e) =>
                      handleCheckAllChange(item.channel, item.vendors)(e)
                    }
                    checked={
                      Object.values(selected[item.channel] || {}).length ===
                        item.vendors.length &&
                      Object.values(selected[item.channel] || {}).every(
                        (val) => val
                      )
                    }
                    color="secondary"
                    style={{ fontSize: "14px" }}
                  />
                }
                label={<div className="selectAll">Select All</div>}
              />
            }
            titleTypographyProps={{
              style: {
                color: "var(--col-8, #000)",
                fontFamily: "Roboto",
                // fontSize: "16px",
                fontStyle: "normal",
                fontWeight: "600",
                lineHeight: "151.188%",
                textTransform: "capitalize",
                width: "150px",
              },
            }}
          />
          <div className="customHR"></div>
          <CardContent>
            <FormGroup>
              {item.vendors.map((vendor) => (
                <FormControlLabel
                  key={vendor}
                  control={
                    <Checkbox
                      checked={selected[item.channel]?.[vendor] || false}
                      onChange={handleCheckChange(item.channel, vendor)}
                      color="secondary"
                      style={{ fontSize: "14px" }}
                    />
                  }
                  label={vendor}
                  sx={{
                    color: "var(--col-8, #000)",
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "400",
                    lineHeight: "222.688%",
                  }}
                />
              ))}
            </FormGroup>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default AboutManual;
