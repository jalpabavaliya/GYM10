import React, { useState, useEffect } from "react";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import { SearchBar } from "../../../Utils/Search/Search";
import { SynergyIcon } from "../../../Utils/icons/icons";

import "../../../style.css";

const HEADERGRID = {
  "Sales Pipeline": "$789M",
  "Conversion Rate": "34%",
  "Cost/Lead": "$23.56",
  "Lead Volume": "25.26K",
  ROI: "0.1812%",
};

export const Header1 = () => {
  const handleClickCreate = () => {};

  return (
    <>
      <div className="Header1Box">
        <div className="LeftSide">
          <img
            className="Headerimage"
            alt="header"
            src="https://generation-sessions.s3.amazonaws.com/c2fdc9dc1907f3591108e718a8db0a65/img/image-255@2x.png"
          />
          <Button
            type="submit"
            variant="outlined"
            onClick={handleClickCreate}
            style={{
              marginLeft: "26vh",
              color: "var(--col-12, #FFF)",
              textAlign: "center",
              fontFamily: "DM Sans",
              fontSize: "12px",
              fontWeight: "300",
              lineHeight: "normal",
              letterSpacing: "3.5px",
              width: "140px",
              height: "35px",
              borderRadius: "5px",
              background: "#3E004A",
              border: "1px solid var(--col-12, #3E004A)",
            }}
          >
            + CREATE
          </Button>
        </div>
        <div className="RightSide">
          <div className="CustomSearchBar">
            <SearchBar />
          </div>
        </div>
      </div>
    </>
  );
};

export const Header2 = () => {
  return (
    <>
      <div className="Header2Box">
        <div
          className="headerText"
          style={{ color: "var(--c-ol-1, #3E004A)", fontSize: "26px" }}
        >
          Campaigns
        </div>
        <div className="GridComp">
          <Grid container spacing={1}>
            {Object.entries(HEADERGRID).map(([key, value]) => (
              <Grid item xs={12 / Object.keys(HEADERGRID).length}>
                <Box>
                  <div
                    className="grid-content-key"
                    style={{ fontSize: "14px" }}
                    key={key}
                  >
                    {key}
                  </div>
                  <br />
                  <div className="grid-content-value" key={value}>
                    {value}
                  </div>
                </Box>
              </Grid>
            ))}
          </Grid>
        </div>
      </div>
    </>
  );
};
