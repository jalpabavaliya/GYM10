import React, { useState, useEffect } from "react";
import { useReactiveVar } from "@apollo/client";

import { InputBox } from "../../Utils/input-box/InputBox";
import Objective from "../Components/Objective/Objective";
import Channel from "./AboutChannel/AboutChannel";
import "../../style.css";
import CustomButton from "../../Utils/CustomButton/CustomButton";
import { getAboutCampaigns } from "../../../services/CampaignService";
import { getManageAllCampaign } from "../../../services/AllCampaign";

import {
  campaignPageType as PageType,
  aboutCampaignData as setAboutCampaignData,
} from "../GlobalStore";
import { CircularProgress } from "@mui/material";

export default function AboutCampaign() {
  const campaignData = useReactiveVar(setAboutCampaignData);

  const [CampaignName, setCampaignName] = useState(
    campaignData?.CampaignName || ""
  );
  const [BriefDescription, setBriefDescription] = useState(
    campaignData?.BriefDescription || ""
  );
  const [isSelectedDataCorrect, setIsSelectedDataCorrect] = useState(false);
  const [isNextEnabled, setIsNextEnabled] = useState(false);
  const [ObjectiveAPI, setObjectiveAPI] = useState(false);
  const [AIInput, setAIInput] = useState(false);
  const [manualInput, setManualInput] = useState(false);

  const updateCampaignData = (key, value) => {
    const currentCampaignData = setAboutCampaignData();
    setAboutCampaignData({
      ...currentCampaignData,
      [key]: value,
    });
  };

  useEffect(() => {
    setIsNextEnabled(
      !CampaignName || !BriefDescription || !isSelectedDataCorrect
    );
  }, [CampaignName, BriefDescription, isSelectedDataCorrect]);

  useEffect(() => {
    setCampaignName(campaignData?.name || "");
    setBriefDescription(campaignData?.description || "");
  }, [campaignData]);

  useEffect(() => {
    (async () => {
      const response = await getAboutCampaigns();
      setObjectiveAPI(response.data.objective);
      setAIInput(response.data.ai_generated_channel_allocation);
      setManualInput(response.data.channel_vendors);
    })();

    (async () => {
      const response = await getManageAllCampaign("campaign");
      console.log("ALL response", response);
    })();
  }, []);

  const handleNextButtonClick = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
    PageType(2);
  };

  return (
    <>
      {ObjectiveAPI && AIInput && manualInput ? (
        <>
          <div className="campaign-container">
            <div className="customHR"></div>
            <div className="headerText">About Campaign</div>
            <div className="normalText">
              Kickstart your campaign by defining its name and brief overview.
            </div>
            <div className="staredText">*All fields are required</div>
            <InputBox
              placeholder={"Enter Campaign Name*"}
              isMultiLine={false}
              rows={1}
              onChange={(value) => {
                setCampaignName(value);
                updateCampaignData("name", value);
              }}
              value={CampaignName}
            />
            <InputBox
              placeholder={"Brief Description*"}
              isMultiLine={true}
              rows={4}
              onChange={(value) => {
                setBriefDescription(value);
                updateCampaignData("description", value);
              }}
              value={BriefDescription}
            />
            <div className="customHR"></div>
            <div className="headerText">Objective</div>
            <div className="normalText">
              Align your campaign strategy with AI optimization by selecting an
              objective from the below list.
            </div>

            {ObjectiveAPI && <Objective ObjectiveAPI={ObjectiveAPI} />}

            <div className="customHR"></div>
            <div className="headerText">Channel & Vendor</div>
            <div className="normalText">
              Select your campaign channel and let us guide you to the suitable,
              integrated vendors.
            </div>
            <div
              style={{
                borderRadius: "5px",
                border: "1px solid #EBE8F1",
                width: "1122px",
              }}
            >
              {ObjectiveAPI && AIInput && manualInput && (
                <Channel
                  setCorrect={setIsSelectedDataCorrect}
                  ObjectiveAPI={ObjectiveAPI}
                  AIInput={AIInput}
                  manualInput={manualInput}
                />
              )}
            </div>
          </div>
          <div style={{ marginBottom: "20px" }}>
            <CustomButton
              isDisabled={isNextEnabled}
              onClick={handleNextButtonClick}
              buttonValue="Next"
              style={{
                marginLeft: "20px",
                marginTop: "20px",
              }}
            />
          </div>
        </>
      ) : (
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: "32px",
          }}
        >
          <CircularProgress color="secondary" />
        </div>
      )}
    </>
  );
}
