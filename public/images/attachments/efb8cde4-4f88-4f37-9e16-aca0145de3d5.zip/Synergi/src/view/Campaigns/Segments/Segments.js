import React, { useState, useEffect } from "react";
import { useReactiveVar } from "@apollo/client";
import {
  campaignPageType as PageType,
  dataSourceData as setDataSourceData,
  aboutCampaignData as setAboutCampaignData,
  segmetsData as setSegmentsData,
} from "../GlobalStore";
import SummaryBox from "../../Utils/SummaryBox/SummaryBox";
import { Grid, Box, CircularProgress } from "@mui/material";
import CustomButton from "../../Utils/CustomButton/CustomButton";
import SegmentsChannel from "./SegmentsChannel/SegmentsChannel";
import {
  getSegmentsAI,
  getSegmentsManual,
} from "../../../services/CampaignService";

const Segments = () => {
  const isPageType = useReactiveVar(PageType);
  const dataSourceData = useReactiveVar(setDataSourceData);
  const aboutCampaignData = useReactiveVar(setAboutCampaignData);
  const [getCampaignSummary, setCampaignSummary] = useState(null);
  const [segmentsAIAPI, setSegmentsAIAPI] = useState([]);
  const [segmentsManualAPI, setSegmentsManualAPI] = useState("");

  const handleNextButtonClick = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
    PageType(4);
  };
  const handlePrevButtonClick = () => {
    PageType(2);
  };

  useEffect(() => {
    let channelData = dataSourceData.AIData;

    var raw = JSON.stringify({
      data_sources: channelData,
      campaign_id: aboutCampaignData.campaign_id,
    });
    setCampaignSummary(raw);
  }, []);

  useEffect(() => {
    (async () => {
      const response = await getSegmentsAI("");
      setSegmentsAIAPI(response.data);
    })();

    (async () => {
      const response = await getSegmentsManual("segment");
      setSegmentsManualAPI(response.data);
    })();
  }, []);

  return (
    <>
      {segmentsAIAPI && segmentsManualAPI ? (
        <div className="campaign-container">
          <div className="customHR"></div>

          <Grid container spacing={2}>
            <Grid item xs={8}>
              <div style={{ display: "grid", gap: "20px" }}>
                <div className="headerText">
                  Choose Your Campaign Segments & Rate Sheet
                </div>
                <div className="normalText">
                  Modify segment allocation using controllers. Click 'Manual
                  Segments' to add segments manually.
                </div>
                {segmentsAIAPI && segmentsManualAPI && (
                  <SegmentsChannel
                    segmentsAIAPI={segmentsAIAPI}
                    segmentsManualAPI={segmentsManualAPI}
                  />
                )}

                <div style={{ marginTop: "20px" }}>
                  <CustomButton
                    isDisabled={false}
                    onClick={handlePrevButtonClick}
                    buttonValue="Prev step"
                    style={{
                      color: "#852598",
                      backgroundColor: "#ffffff",
                      border: "1px solid #852598",
                    }}
                  />
                  <CustomButton
                    isDisabled={!segmentsAIAPI || !segmentsManualAPI}
                    onClick={handleNextButtonClick}
                    buttonValue="Next"
                    style={{}}
                  />
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <Box display="flex" justifyContent="flex-end">
                {getCampaignSummary && (
                  <SummaryBox CampaignSummary={getCampaignSummary} which={2} />
                )}
              </Box>
            </Grid>
          </Grid>
        </div>
      ) : (
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: "32px",
          }}
        >
          <CircularProgress color="secondary" />
        </div>
      )}
    </>
  );
};

export default Segments;
