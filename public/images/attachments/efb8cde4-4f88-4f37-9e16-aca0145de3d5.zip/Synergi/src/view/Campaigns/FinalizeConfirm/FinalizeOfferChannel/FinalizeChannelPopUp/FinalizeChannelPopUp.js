import React, { useState, useEffect } from "react";
import DateTimeInput from "../../../../Utils/DateTimeInput/DateTimeInput";
import SpendingLimit from "../../../../Utils/SpendingLimit/SpendingLimit";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import { useReactiveVar } from "@apollo/client";

import {
  Dialog,
  DialogTitle,
  DialogContent,
  Checkbox,
  Collapse,
  Select,
  MenuItem,
  Grid,
  CircularProgress,
} from "@mui/material";
import CustomButton from "../../../../Utils/CustomButton/CustomButton";
import { offersData as setOffersData } from "../../../GlobalStore";

const FinalizeChannelPopUp = ({
  open,
  handleClose,
  handleSave,
  channelData,
  channel,
  globalDateTime,
  globalSpendingLimit,
}) => {
  const offersData = useReactiveVar(setOffersData);

  const [segmentData, setSegmentData] = useState(
    offersData?.segmentData?.[channel] || {}
  );

  let json_payload = {
    pk: "campaign#16929466974331234ee9c3e8939975bb61ed45f18bfc69648",
    change_records: [
      {
        channel: "Email",
        segment_offers: [
          {
            sk: "Email#segment#16921911865680889ef7c113e8c90c9408203bf4e5003731#offer#169219107406461338c4417911a533ace52116e8654ed30b1",
            offer_start_datetime: "2023-08-26 16:07:42",
            offer_end_datetime: "2023-09-31 00:00:00",
            max_budget: 200,
            min_budget: 10,
            vendor_templates: [
              {
                vendor_tracking:
                  "CALL NUMBER:- 546-764-2315 QR CODE:- SampleQRCode TRACKING_ID = AdobeID-Track9087-2023-08-21",
                vendor_name: "Adobe",
                vendor_template: "Adobe User Onboarding",
              },
              {
                vendor_tracking:
                  "CALL NUMBER:- 145-765-8798 QR CODE:- SampleQRCode TRACKING_ID = HubspotID-Track3654-2023-08-21",
                vendor_name: "Hubspot",
                vendor_template: "Hubspot CRM Notification",
              },
            ],
            active: "True",
          },
          {
            sk: "Email#segment#16921859157129579a60c69c722ebfa5af8194fe0a34d647f#offer#16922085236872883087991abab2e96719817528b2b8ce40d",
            active: "False",
          },
        ],
        active: "False",
      },
    ],
  };

  const [expandedSegments, setExpandedSegments] = useState({});
  const [loadingSegment, setLoadingSegment] = useState(null);
  const [hasSavedData, setHasSavedData] = useState(
    offersData?.segmentData?.[channel]?.isSaved || false
  );

  const stopEventPropagation = (event) => {
    event.stopPropagation();
  };

  const handleDateTimeChange = (segment_id, data) => {
    setSegmentData((prevState) => ({
      ...prevState,
      [segment_id]: {
        ...prevState[segment_id],
        dateTimeData: data,
      },
    }));
  };

  const handleLimitChange = (segment_id, limitData) => {
    setSegmentData((prevState) => ({
      ...prevState,
      [segment_id]: {
        ...prevState[segment_id],
        spendingLimit: limitData,
      },
    }));
  };

  const handleCheckboxChange = (segment_id) => {
    setSegmentData((prevState) => ({
      ...prevState,
      [segment_id]: {
        ...prevState[segment_id],
        selected: !prevState[segment_id].selected,
      },
    }));
  };

  const handleSaveClick = () => {
    handleSave(segmentData);
    setHasSavedData(true);
  };

  const handleExpandClick = (segment_id) => {
    setExpandedSegments((prevState) => ({
      [segment_id]: !prevState[segment_id],
    }));
  };

  const handleOfferChangeWithLoading = (segment_id, value) => {
    setLoadingSegment(segment_id);

    setTimeout(() => {
      setSegmentData((prevState) => ({
        ...prevState,
        [segment_id]: {
          ...prevState[segment_id],
          offer_name: value,
        },
      }));
      setLoadingSegment(null);
    }, 500);
  };
  const handleVendorTemplateChange = (
    segment_id,
    value,
    vendor,
    vendor_tracking
  ) => {
    setSegmentData((prevState) => {
      let updatedTemplates =
        prevState[segment_id]?.selected_vendor_templates || {};

      updatedTemplates[vendor] = {
        vendor_name: vendor,
        vendor_template: value,
        vendor_tracking: vendor_tracking,
      };

      const updatedState = {
        ...prevState,
        [segment_id]: {
          ...prevState[segment_id],
          selected_vendor_templates: updatedTemplates,
        },
      };
      return updatedState;
    });
  };

  const handleBatchSizeChange = (segment_id, value) => {
    setSegmentData((prevState) => {
      const updatedState = {
        ...prevState,
        [segment_id]: {
          ...prevState[segment_id],
          batch: {
            ...prevState[segment_id].batch,
            batchSize: value,
          },
        },
      };

      return updatedState;
    });
  };

  const handleBatchPeriodChange = (segment_id, value) => {
    setSegmentData((prevState) => {
      const updatedState = {
        ...prevState,
        [segment_id]: {
          ...prevState[segment_id],
          batch: {
            ...prevState[segment_id].batch,
            period: value,
          },
        },
      };
      return updatedState;
    });
  };

  useEffect(() => {
    let initialSegmentData = {};
    let initialExpandedSegments = {};

    if (
      channelData &&
      channelData.segment_offers &&
      channelData.segment_offers.length > 0
    ) {
      channelData.segment_offers.forEach((segment, index) => {
        initialSegmentData[segment.segment_id] = {
          offer_name: segment?.offer_name,
          offer_id: segment?.offer_id,
          segment_id: segment?.segment_id,
          segment_name: segment?.segment_name,

          dateTimeData: {
            startDate: globalDateTime.startDate,
            startTime: globalDateTime.startTime,
            endDate: globalDateTime.endDate,
            endTime: globalDateTime.endTime,
          },
          spendingLimit: {
            noLimit: globalSpendingLimit.noLimit,
            period: globalSpendingLimit.period,
            min: globalSpendingLimit.min,
            max: globalSpendingLimit.max,
          },
          selected: false,
        };

        initialExpandedSegments[segment.segment_id] =
          index === 0 ? true : false;
      });
    }

    if (!hasSavedData) {
      setSegmentData(initialSegmentData);
    }
    setExpandedSegments(initialExpandedSegments);
  }, [channelData, globalDateTime, globalSpendingLimit, hasSavedData]);

  useEffect(() => {
    if (!hasSavedData) {
      const updatedSegmentData = { ...segmentData };

      for (let key in updatedSegmentData) {
        updatedSegmentData[key].dateTimeData = globalDateTime;
        updatedSegmentData[key].spendingLimit = globalSpendingLimit;
      }
    }
  }, [globalDateTime, globalSpendingLimit, hasSavedData]);

  return (
    <>
      <style>
        {`
          input[type="number"]::-webkit-outer-spin-button,
          input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
          }

          input[type="number"] {
            -moz-appearance: textfield; /* for Firefox */
          }
        `}
      </style>
      <Dialog
        open={open}
        onClose={handleClose}
        onClick={stopEventPropagation}
        fullWidth
        maxWidth={false}
        sx={{
          "& .MuiDialog-paper": {
            width: "1310px",
            padding: "20px",
          },
        }}
      >
        <DialogTitle>
          <>
            <div
              className="headerText"
              style={{
                fontSize: "24px",
                fontStyle: "IBM Plex Serif;",
                fontWeight: "400",
              }}
            >
              {channelData.channel} Offers
            </div>
            <div
              className="customHR"
              style={{ marginBottom: "20px", marginTop: "20px" }}
            ></div>
            <div className="normalText">
              Explore the auto-selected offers for this channel. Modify
              selections as desired, or <br /> proceed with AI-generated
              choices.
            </div>
          </>
        </DialogTitle>
        <DialogContent>
          <div
            style={{
              width: "70%",
              borderRadius: "4px",
              border: "1px solid #D9D6E3",
              background: "#FFF",
            }}
          >
            <div
              style={{
                background: "#F0EAF1",
                height: "52px",
                display: "flex",
                alignItems: "center",
                padding: "5px",
                marginBottom: "5px",
              }}
            >
              <Grid container spacing={2} alignItems="center">
                <Grid
                  item
                  xs={1}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <div className="headerText">View</div>
                </Grid>
                <Grid
                  item
                  xs={1}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <div className="headerText">All</div>
                </Grid>
                <Grid item xs={6}>
                  <div className="headerText">Segment</div>
                </Grid>
                <Grid item xs={4}>
                  {" "}
                  <div className="headerText">Matched Offers</div>
                </Grid>
              </Grid>
            </div>
            {channelData.segment_offers &&
              channelData.segment_offers.length > 0 &&
              channelData.segment_offers.map((segment) => (
                <Grid
                  container
                  spacing={2}
                  alignItems="center"
                  key={segment.segment_id}
                  style={{ marginTop: "5px", overflow: "auto" }}
                >
                  <Grid
                    item
                    xs={1}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {expandedSegments[segment.segment_id] ? (
                      <ArrowDropUpIcon
                        onClick={() => handleExpandClick(segment.segment_id)}
                      />
                    ) : (
                      <ArrowDropDownIcon
                        onClick={() => handleExpandClick(segment.segment_id)}
                      />
                    )}
                  </Grid>

                  <Grid
                    item
                    xs={1}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Checkbox
                      checked={!!segmentData[segment.segment_id]?.selected}
                      onClick={() => handleCheckboxChange(segment.segment_id)}
                      color="secondary"
                    />
                  </Grid>

                  <Grid item xs={6} container direction="column">
                    <Grid item>
                      <div className="headerText" style={{ color: "#852598" }}>
                        {segment.segment_name}
                      </div>
                    </Grid>
                    <Grid item>
                      <div className="normalText">
                        {segment.total_target_data}
                      </div>
                    </Grid>
                  </Grid>

                  <Grid item xs={4} container>
                    <div style={{ width: "275px" }}>
                      <div
                        className="normalText"
                        style={{ marginBottom: "10px", color: "#000" }}
                      >
                        {segmentData[segment.segment_id]?.offer_name ||
                          segment?.offer_name}
                      </div>

                      {loadingSegment === segment.segment_id ? (
                        <CircularProgress />
                      ) : (
                        <Select
                          value=""
                          onChange={(event) => {
                            handleOfferChangeWithLoading(
                              segment.segment_id,
                              event.target.value
                            );
                          }}
                          displayEmpty
                          style={{
                            width: "255px",
                            height: "31px",
                            borderRadius: "6px",
                            border: "1px solid #EBE8F1",
                            background: "#FFF",
                            color: "#838383",
                          }}
                          MenuProps={{
                            MenuListProps: {
                              style: {
                                backgroundColor: "#f5f0f3",
                              },
                            },
                          }}
                        >
                          <MenuItem value="" disabled s>
                            Select New Offer
                          </MenuItem>
                          {[
                            segmentData[segment.segment_id]?.offer_name,
                            ...channelData.available_offers.map(
                              (offer) => offer.offer_name
                            ),
                            segment?.offer_name,
                          ]
                            .filter(
                              (offerName) =>
                                offerName !==
                                (segmentData[segment.segment_id]?.offer_name ||
                                  segment?.offer_name)
                            )
                            .map((offerName) => (
                              <MenuItem value={offerName}>{offerName}</MenuItem>
                            ))}
                        </Select>
                      )}
                    </div>
                  </Grid>

                  <Grid item xs={1}></Grid>
                  <Grid item xs={11}>
                    <Collapse in={expandedSegments[segment.segment_id]}>
                      <div
                        style={{
                          display: "grid",
                          gap: "20px",
                        }}
                      >
                        <div className="customHR" style={{ margin: 0 }}></div>
                        <div className="headerText">Settings</div>
                        <DateTimeInput
                          dateTimeData={
                            segmentData[segment.segment_id]?.dateTimeData ||
                            globalDateTime
                          }
                          onDateTimeChange={(data) =>
                            handleDateTimeChange(segment.segment_id, data)
                          }
                        />
                        <div className="customHR" style={{ margin: 0 }}></div>
                        <div style={{ display: "flex", alignItems: "center" }}>
                          <div className="normalText">Send in Batches</div>
                          <input
                            value={
                              segmentData[segment.segment_id]?.batch?.batchSize
                            }
                            onChange={(event) => {
                              handleBatchSizeChange(
                                segment.segment_id,
                                event.target.value
                              );
                            }}
                            placeholder=" Batch size"
                            type="number"
                            style={{
                              marginLeft: "50px",
                              padding: "1px",
                              height: "31px",
                              width: "130px",
                              border: "1px solid #ccc",
                              borderRadius: "4px",
                              appearance: "none",
                            }}
                          />
                          <Select
                            value={
                              segmentData[segment.segment_id]?.batch?.period ||
                              "daily"
                            }
                            onChange={(event) => {
                              handleBatchPeriodChange(
                                segment.segment_id,
                                event.target.value
                              );
                            }}
                            className="normalText"
                            style={{
                              width: "130px",
                              height: "35px",
                              marginLeft: "20px",
                            }}
                          >
                            <MenuItem
                              value="daily"
                              className="normalText"
                              style={{ fontSize: "10px" }}
                            >
                              Daily
                            </MenuItem>
                            <MenuItem
                              value="monthly"
                              className="normalText"
                              style={{ fontSize: "10px" }}
                            >
                              Monthly
                            </MenuItem>
                            <MenuItem
                              value="quarterly"
                              className="normalText"
                              style={{ fontSize: "10px" }}
                            >
                              Quarterly
                            </MenuItem>
                          </Select>
                        </div>
                        <div className="customHR" style={{ margin: 0 }}></div>
                        <div style={{ display: "grid" }}>
                          <div className="normalText">Budget</div>
                          <SpendingLimit
                            onLimitChange={(data) =>
                              handleLimitChange(segment.segment_id, data)
                            }
                            spendingLimit={
                              segmentData[segment.segment_id]?.spendingLimit ||
                              globalSpendingLimit
                            }
                          />
                        </div>

                        <div className="customHR" style={{ margin: 0 }}></div>
                        <div className="normalText">Design Template</div>

                        {channelData.vendor_templates &&
                          channelData.vendor_templates.length &&
                          channelData.vendor_templates.map((vendor) => (
                            <Grid container key={vendor.vendor_name}>
                              <Grid item md={3}>
                                <div className="headerText">
                                  {vendor.vendor_name}
                                </div>
                              </Grid>

                              <Grid item md={4}>
                                <Select
                                  value={
                                    segmentData[segment.segment_id]
                                      ?.selected_vendor_templates?.[
                                      vendor.vendor_name
                                    ]?.vendor_template || "temp"
                                  }
                                  onChange={(event) => {
                                    handleVendorTemplateChange(
                                      segment.segment_id,
                                      event.target.value,
                                      vendor.vendor_name,
                                      vendor.vendor_tracking
                                    );
                                  }}
                                  style={{
                                    width: "255px",
                                    height: "31px",
                                    borderRadius: "6px",
                                    border: "1px solid #EBE8F1",
                                    background: "#FFF",
                                  }}
                                  MenuProps={{
                                    MenuListProps: {
                                      style: {
                                        backgroundColor: "#f5f0f3",
                                      },
                                    },
                                  }}
                                >
                                  <MenuItem value="temp" disabled>
                                    View & Select
                                  </MenuItem>
                                  {vendor.vendor_template.map(
                                    (template, index) => (
                                      <MenuItem key={index} value={template}>
                                        {template}
                                      </MenuItem>
                                    )
                                  )}
                                </Select>
                              </Grid>
                            </Grid>
                          ))}
                      </div>
                    </Collapse>
                  </Grid>

                  <Grid item xs={12}>
                    <div className="customHR" style={{ margin: "0px" }}></div>
                  </Grid>
                </Grid>
              ))}
          </div>
          <div style={{ marginTop: "20px" }}>
            <CustomButton
              isDisabled={false}
              onClick={handleClose}
              buttonValue="Cancel"
              style={{
                color: "#852598",
                backgroundColor: "#ffffff",
                border: "1px solid #852598",
                marginLeft: "0",
              }}
            />
            <CustomButton
              isDisabled={false}
              buttonValue="Save"
              onClick={handleSaveClick}
              style={{}}
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default FinalizeChannelPopUp;
