import React, { useState, useEffect } from "react";
import { useReactiveVar } from "@apollo/client";

import {
  Card,
  CardHeader,
  Checkbox,
  FormControlLabel,
  FormGroup,
  CardContent,
} from "@mui/material";

import { dataSourceData as setDataSourceData } from "../../../GlobalStore";

const DataSourceManual = ({ manualInput }) => {
  const dataSourceData = useReactiveVar(setDataSourceData);
  const [selected, setSelected] = useState(dataSourceData?.manualData || []);

  useEffect(() => {
    const currentCampaignData = setDataSourceData();
    setDataSourceData({
      ...currentCampaignData,
      manualData: selected,
    });
  }, [selected]);

  const handleCheckChange = (channel, vendor) => (event) => {
    setSelected({
      ...selected,
      [channel]: { ...selected[channel], [vendor]: event.target.checked },
    });
  };

  const handleCheckAllChange = (channel) => (event) => {
    const vendorsObj = manualInput.body
      .find((obj) => obj.channel === channel)
      .Vendors.reduce(
        (acc, cur) => ({ ...acc, [cur]: event.target.checked }),
        {}
      );
    setSelected({
      ...selected,
      [channel]: vendorsObj,
    });
  };

  return (
    <div
      style={{
        display: "flex",
        overflow: "auto",
        gap: "15px",
      }}
    >
      {manualInput.body.map((item, index) => (
        <Card
          key={index}
          style={{
            width: "280px",
            height: "237px",
            borderRadius: "5px",
            border: "1px solid #EBE8F1",
            background: "#FFF",
            boxShadow: "0px 8px 20px 0px rgba(0, 0, 0, 0.06)",
            padding: "5px",
          }}
        >
          <CardHeader
            title={item.channel}
            action={
              <FormControlLabel
                control={
                  <Checkbox
                    onChange={handleCheckAllChange(item.channel)}
                    checked={
                      Object.values(selected[item.channel] || {}).length ===
                        item.Vendors.length &&
                      Object.values(selected[item.channel] || {}).every(
                        (val) => val
                      )
                    }
                    color="secondary"
                    style={{ fontSize: "14px" }}
                  />
                }
                label={<div className="selectAll">Select All</div>}
              />
            }
            titleTypographyProps={{
              style: {
                color: "var(--col-8, #000)",
                fontFamily: "Roboto",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: "600",
                lineHeight: "151.188%",
                textTransform: "capitalize",
                width: "150px",
              },
            }}
          />
          <div className="customHR"></div>
          <CardContent>
            <FormGroup>
              {item.Vendors.map((vendor) => (
                <FormControlLabel
                  key={vendor}
                  control={
                    <Checkbox
                      checked={selected[item.channel]?.[vendor] || false}
                      onChange={handleCheckChange(item.channel, vendor)}
                      color="secondary"
                      style={{ fontSize: "14px" }}
                    />
                  }
                  label={vendor}
                  sx={{
                    color: "var(--col-8, #000)",
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "400",
                    lineHeight: "222.688%",
                  }}
                />
              ))}
            </FormGroup>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DataSourceManual;
