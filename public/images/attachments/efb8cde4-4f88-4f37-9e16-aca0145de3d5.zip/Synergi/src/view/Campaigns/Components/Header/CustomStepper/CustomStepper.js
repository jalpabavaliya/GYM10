import React from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import Grid from "@mui/material/Grid";
import StepLabel from "@mui/material/StepLabel";
import "../../../../style.css";

import { SelectedIcon, UnselectedIcon } from "../../../../Utils/icons/icons";

const steps = [
  "About Campaign",
  "Data Source",
  "Segments",
  "Offers",
  "Finalize & Confirm",
];

export default function CustomStepper({ type }) {
  return (
    <Grid container spacing={2}>
      <Grid item xs={8} sx={{ alignItems: "center" }}>
        <div
          className="titleText"
          style={{
            color: "#414446",
            fontFamily: "IBM Plex Serif",
            marginLeft: "20px",
            marginTop: "20px",
            fontSize: "30px",
          }}
        >
          Create a new campaign
        </div>
      </Grid>
      <Grid item xs={4}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
          }}
        >
          <Stepper activeStep={type} alternativeLabel>
            {steps.map((label, index) => (
              <Step key={label}>
                <StepLabel
                  className="stepLabel"
                  StepIconComponent={() => (
                    <StepIconComponent index={index} type={type} />
                  )}
                >
                  {label}
                </StepLabel>
              </Step>
            ))}
          </Stepper>
        </Box>
      </Grid>
    </Grid>
  );
}

function StepIconComponent({ index, type }) {
  return type === index ? <SelectedIcon /> : <UnselectedIcon />;
}
