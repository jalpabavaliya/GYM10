import React, { useState, useEffect } from "react";
import FinalizeChannelCard from "./FinalizeChannelCard/FinalizeChannelCard";
import { getSegmentOffers } from "../../../../services/CampaignService";

const FinalizeOfferChannel = ({
  globalDateTime,
  globalSpendingLimit,
  setOfferData,
}) => {
  const [segmentsOffersAPI, setSegmentsOffersAPI] = useState("");
  const [channelRows, setChannelRows] = useState([]);

  const saveData = (channel, segementData) => {
    setOfferData((prevState) => ({
      ...prevState,
      [channel]: {
        ...segementData,
        isSaved: true,
      },
    }));
  };

  useEffect(() => {
    (async () => {
      const response = await getSegmentOffers();
      setSegmentsOffersAPI(response.data.response);

      let temp = [];
      for (let i = 0; i < response.data.response.length; i += 3) {
        temp.push(response.data.response.slice(i, i + 3));
      }
      setChannelRows(temp);
    })();
  }, []);


  return (
    <div>
      {channelRows.map((rowChannels, rowIndex) => (
        <div
          key={rowIndex}
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: "10px",
          }}
        >
          {rowChannels &&
            rowChannels.map((channelData, index) => (
              <div style={{ marginLeft: index === 0 ? "0px" : "20px" }}>
                <FinalizeChannelCard
                  key={channelData.channel}
                  channelData={channelData}
                  saveData={saveData}
                  channel={channelData.channel}
                  globalDateTime={globalDateTime}
                  globalSpendingLimit={globalSpendingLimit}
                />
              </div>
            ))}
        </div>
      ))}
    </div>
  );
};

export default FinalizeOfferChannel;
