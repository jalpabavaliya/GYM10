import {
  Avatar,
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Grid,
  Typography,
} from "@mui/material";
import React from "react";
import "./footerCard.css";

const FooterCard = ({ cardDetails }) => {
  const {
    backgroundColor,
    backgroundIconColor,
    title,
    subTitle1,
    subTitle2,
    subTitle3,
  } = cardDetails;

  return (
    <Card
      sx={{
        p: "1vh",
        width: "40vh",
        height: "30vh",
        backgroundColor: { backgroundColor },
      }}
    >
      <CardContent>
        <Box
          sx={{
            backgroundColor: backgroundIconColor,
            width: "7vh",
            height: "7vh",
            borderRadius: "10px",
            color: "white",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "24px",
            // font-family: "Roboto", Helvetica,
          }}
        >
          S
        </Box>

        <Typography variant="h5" sx={{ textAlign: "start", mt: "1vh" }}>
          {title}
        </Typography>
        <Typography
          component="div"
          sx={{ textAlign: "start", mt: "1vh", fontSize: "12px" }}
        >
          {subTitle1}
          <br /> {subTitle2}
          <br /> {subTitle3}
        </Typography>
      </CardContent>
      <CardActions className="footer-style">
        <Button className="footer-style" size="small" sx={{ color: "#852497" }}>
          Learn More
        </Button>
      </CardActions>
    </Card>
  );
};

export default FooterCard;
