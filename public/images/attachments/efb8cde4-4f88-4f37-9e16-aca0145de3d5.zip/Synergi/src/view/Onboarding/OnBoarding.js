import React from "react";
import { Grid, Paper } from "@mui/material";
import OnboardingSteps from "./OnboardingStep/OnboardingSteps";
import OnboardingData from "./OnboardingStep/OnboardingData";
import OnboardingAi from "./OnboardingStep/OnboardingAi";

function OnBoardingStep1() {
  return (
    <>
      <Paper
        sx={{
          backgroundColor: "#ffffff",
          width: "100%",
          // height: "100%",
          borderRadius: "6px",
          cursor: "pointer",
        }}
      >
        <OnboardingSteps />
        {/* <Demo /> */}
      </Paper>
      <Grid
        sx={{
          bgcolor: "#EFE7EF",

          borderRadius: 2,
          height: "417px",
          border: " 1px solid #D0B6D6",
        }}
      >
        <section
          style={{
            display: "flex",
            flexDirection: "column",
            rowGap: "1rem",
            margin: "27px",
            backgroundColor: "#EFE7EF",
            cursor: "pointer",
          }}
        >
          <OnboardingData />
        </section>
      </Grid>
      <Grid
        sx={{
          bgcolor: "#FAF2EC",

          borderRadius: 2,
          height: "417px",
          border: " 1px solid #D9C5B5",
        }}
      >
        <section
          style={{
            display: "flex",
            flexDirection: "column",
            rowGap: "1rem",
            margin: "27px",
            cursor: "pointer",
          }}
        >
          <OnboardingAi />
        </section>
      </Grid>
    </>
    //   {/* <Grid
    //     container
    //     direction="column"
    //     sx={{ backgroundColor: "#FAF8F7", overflow: "hidden" }}
    //   >
    //     <Grid item>
    //       <Header />
    //     </Grid>
    //     <Grid item sx={{ mt: "10px", mb: "5px" }}>
    //       <SubHeader title="Imports" />
    //     </Grid>
    //     <Grid item>
    //       <Grid container spacing={2}>
    //         <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}>
    //           <SideBar />
    //         </Grid>
    //         <Grid
    //           item
    //           xs={12}
    //           sm={8.6}
    //           md={8.6}
    //           lg={9.6}
    //           sx={{
    //             bgcolor: "background.paper",
    //             m: 2,
    //             borderRadius: 2,
    //           }}
    //         >
    //           <section
    //             style={{
    //               display: "flex",
    //               flexDirection: "column",
    //               rowGap: "1rem",
    //             }}
    //           > */}
    //             {/* <OnboardingSteps /> */}
    //             {/* <Demo/> */}
    //           {/* </section>

    //           <section
    //             style={{
    //               display: "flex",
    //               flexDirection: "column",
    //               rowGap: "1rem",
    //             }}
    //           ></section>
    //         </Grid>
    //         <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}></Grid>
    //         <Grid
    //           item
    //           xs={12}
    //           sm={8.6}
    //           md={8.6}
    //           lg={9.6}
    //           sx={{
    //             bgcolor: "#EFE7EF",
    //             m: 2,
    //             borderRadius: 2,  height:"417px",
    //             border:" 1px solid #D0B6D6",
    //           }}
    //         >
    //           <section
    //             style={{
    //               display: "flex",
    //               flexDirection: "column",
    //               rowGap: "1rem",
    //               margin: "27px",
    //               backgroundColor: "#EFE7EF",

    //             }}
    //           >
    //             <OnboardingData />
    //           </section>
    //         </Grid>
    //         <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}></Grid>
    //         <Grid
    //           item
    //           xs={12}
    //           sm={8.6}
    //           md={8.6}
    //           lg={9.6}
    //           sx={{
    //             bgcolor: "#FAF2EC",
    //             m: 2,
    //             borderRadius: 2,  height:"417px",
    //             border:" 1px solid #D9C5B5",
    //           }}
    //         >
    //           <section
    //             style={{
    //               display: "flex",
    //               flexDirection: "column",
    //               rowGap: "1rem", margin: "27px",

    //             }}
    //           >
    //             <OnboardingAi />
    //           </section>
    //         </Grid>
    //         <Grid item sx={{ paddingLeft: "35vh" }}>
    //           <MainFooter />
    //         </Grid>
    //       </Grid>
    //     </Grid>
    //   </Grid>
    // </div> */}
  );
}

export default OnBoardingStep1;
