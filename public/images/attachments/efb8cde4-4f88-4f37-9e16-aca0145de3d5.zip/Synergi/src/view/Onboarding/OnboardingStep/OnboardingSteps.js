import { Button, Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import Integration from "../../../assets/Integration.svg";

import Segments from "../../../assets/Segments.svg";
import Offers from "../../../assets/Offers.svg";
import Pageimg_First from "../../../assets/Page-1.svg";
import Pageimg_Second from "../../../assets/Page-2.svg";
import Pageimg_Third from "../../../assets/Page-3.svg";
import "./onboardingStep.css";
import { useNavigate } from "react-router-dom";
function OnboardingSteps() {
  const navigate = useNavigate();
  const [toggleState, setToggleState] = useState(1);

  const toggleStep = (index) => {
    setToggleState(index);
  };
  const subTitle = {
    fontFamily: "Roboto",
    fontSize: "12px",
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "18px",
    color: "#5D596C",
  };
  const title = {
    fontFamily: "Roboto",
    fontSize: "18px",
    fontStyle: "normal",
    fontWeight: 700,
    lineHeight: "26px",
    color: "#000000",
  };
  const intro = {
    fontFamily: "Roboto",
    fontSize: "14px",
    fontStyle: "normal",
  
  
    color: "#414446",
  };
  return (
    <div>
      <Grid container>
        <Grid xs={6} sx={{ padding: "26px 0px 0px 6px" }}>
          <div
            className={toggleState === 1 ? "step active-step" : "step"}
            onClick={() => toggleStep(1)}
          >
            <Grid container>
              <Grid xs={2}>
                <img src={Integration} alt="Group Icon" />
              </Grid>
              <Grid
                xs={10}
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  flexDirection: "column",
                }}
              >
                <Typography
                  className="theme2"
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: 400,
                  }}
                >
                  STEP 1
                </Typography>
                <Typography
                  variant="h2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "18px",
                    fontStyle: "normal",
                    fontWeight: "bold",
                    lineHeight: "26px",
                  }}
                >
                  APP & Data Integration
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "Regular",
                  }}
                >
                  The SYNERGY team will create the vendor’s smart contract.
                </Typography>
              </Grid>
            </Grid>
          </div>
          <div
            className={toggleState === 2 ? "step active-step" : "step"}
            onClick={() => toggleStep(2)}
          >
            <Grid container>
              <Grid xs={2}>
                <img src={Segments} alt="Group Icon" />{" "}
              </Grid>
              <Grid xs={10}>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  className="theme2"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: 400,
                  }}
                >
                  STEP 2
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "18px",
                    fontStyle: "normal",
                    fontWeight: "bold",
                    lineHeight: "26px",
                  }}
                >
                  Segment Creation
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "Regular",
                  }}
                >
                  Customize pre-built segments to target customers effectively
                  and increase click rates.
                </Typography>
              </Grid>
            </Grid>
          </div>
          <div
            className={toggleState === 3 ? "step active-step" : "step"}
            onClick={() => toggleStep(3)}
          >
            <Grid container>
              <Grid xs={2}>
                <img src={Offers} alt="Group Icon" />
              </Grid>
              <Grid xs={10}>
                <Typography
                  variant="body2"
                  className="theme2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: 400,
                  }}
                >
                  STEP 3
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "18px",
                    fontStyle: "normal",
                    fontWeight: "bold",
                    lineHeight: "26px",
                  }}
                >
                  Design Offers
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "Regular",
                  }}
                >
                  Utilize AI for offers that boost conversions 4x or craft your
                  own to engage customers.
                </Typography>
              </Grid>
            </Grid>
          </div>
        </Grid>
        <Grid
          xs={6}
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            textAlign: "center",
            padding: "22px 60px 72px 0px",
          }}
        >
          <div
            className={toggleState === 1 ? "contant active-contant" : "contant"}
            onClick={() => toggleStep(1)}
          >
            <img src={Pageimg_First} alt="Group img" />
            <Typography variant="body2" sx={{ padding: "52px 0px 5px 0px" }} style={subTitle}>
              APP & DATA INTEGRATION
            </Typography>
            <Typography variant="body2" style={title}>
              Transform Your Customer Data into 30X ROI
            </Typography>
            <Typography variant="body2" sx={{ padding: "15px 65px 33px 65px" }} style={intro}>
              Welcome to Synergi. Here, you can connect your existing vendors or
              upload your data directly. The result? A more efficient use of
              your customer data leading to significantly enhanced campaign
              performance. So, let's dive in and get started.
            </Typography>
            <Button
              variant="contained"
              color="secondary"
              type="submit"
              fullWidth
              sx={{ width: { lg: "190px" } }}
              onClick={() => navigate("/app-integrations")}
            >
              App Integration
            </Button>
          </div>
          <div
            className={toggleState === 2 ? "contant active-contant" : "contant"}
            onClick={() => toggleStep(2)}
          >
            <img src={Pageimg_Second} alt="" />
            <Typography variant="body2" sx={{ padding: "52px 0px 5px 0px" }} style={title}>
              To the next step - Segment
            </Typography>
            <Typography variant="body2" sx={{ padding: "15px 95px 33px 95px" }} style={intro}>
              Discover Precision Targeting: Use Synergi's segments to shape your
              audience. Pre-built or customized, they lead to up to 33% higher
              click rates*. Start creating your segments for powerful, tailored
              marketing.
            </Typography>
            <Button
              variant="contained"
              color="secondary"
              type="submit"
              fullWidth
              sx={{ width: { lg: "190px" } }}
              onClick={() => navigate("/segments")}
            >
              Create Segment
            </Button>
          </div>
          <div
            className={toggleState === 3 ? "contant active-contant" : "contant"}
            onClick={() => toggleStep(3)}
          >
            <img src={Pageimg_Third} alt="" />
            <Typography variant="body2" sx={{ paddingTop: "37px" }} style={title}>
              Final Stop Offers Crafting
            </Typography>

            <Typography variant="body2" sx={{ padding: "15px 95px 37px 95px" }} style={intro}>
              Craft Compelling Offers: Whether you're using our AI-generated
              suggestions or creating your own, well-planned offers can boost
              your conversions by 4x*.
            </Typography>
            <Button
              variant="contained"
              color="secondary"
              type="submit"
              fullWidth
              sx={{ width: { lg: "190px" } }}
              onClick={() => navigate("/offers")}
            >
              Create Offers
            </Button>
          </div>
        </Grid>
      </Grid>
    </div>
  );
}

export default OnboardingSteps;
