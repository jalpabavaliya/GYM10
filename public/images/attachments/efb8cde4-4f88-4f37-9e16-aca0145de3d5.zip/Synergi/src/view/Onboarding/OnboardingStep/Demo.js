import { Button, Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import Integration from "../../../assets/Integration.svg";
// import Integration_White from "../../../assets/Integration_White.svg";
// import Segments from "../../../assets/Segments.svg";
// import Offers from "../../../assets/Offers.svg";
// import Pageimg_First from "../../../assets/Page-1.svg";
import "./onboardingStep.css";
function OnboardingSteps() {
  const [toggleState, setToggleState] = useState(1);

  const toggleStep = (index) => {
    setToggleState(index);
  };

  const StepData = [
    {
      id: 1,
      title: " STEP 1",
      icon: <img src={Integration} alt="Group Icon" />,
      mainTitle: "APP & Data Integration",
      intro: "The SYNERGY team will create the vendor’s smart contract.",
    },
    {
      id: 2,
      title: " STEP 2",
      icon: <img src={Integration} alt="Group Icon" />,
      mainTitle: "Segment Creation",
      intro: "Customize pre-built segments to target customers effectively and increase click rates.",
    },
    {
      id: 3,
      title: " STEP 3",
      icon: <img src={Integration} alt="Group Icon" />,
      mainTitle: "Design Offers",
      intro: "Utilize AI for offers that boost conversions 4x or craft your own to engage customers.",
    },
  ];
  const stepDetail = [
    {
      id: 1,
      img: require("../../../assets/Page-1.svg"),
      subTitle: "APP & DATA INTEGRATION",
      mainTitle: "Transform Your Customer Data into 30X ROI",
      intro:"Welcome to Synergi. Here, you can connect your existing vendors or upload your data directly. The result? A more efficient use of your customer data leading to significantly enhanced campaign performance. So, let's dive in and get started."
    },
    {
      id: 2,
      img: require("../../../assets/Page-2.svg"),
  
      mainTitle: "To the next step - Segment",
      intro:"Discover Precision Targeting: Use Synergi's segments to shape your audience. Pre-built or customized, they lead to up to 33% higher click rates*. Start creating your segments for powerful, tailored marketing."
     },
    {
      id: 3,
      img: require("../../../assets/Page-2.svg"),

      mainTitle: "Final Stop Offers Crafting",
      intro:"Craft Compelling Offers: Whether you're using our AI-generated suggestions or creating your own, well-planned offers can boost your conversions by 4x*."
      },
  ];
  return (
    <div>
      <Grid container>
        <Grid xs={6}>
          {StepData && StepData.map(step => {
            return (
              <>
                <div
                  className={toggleState === (step.id) ? "step active-step" : "step"}
                  onClick={() => toggleStep(step.id)}
                >
                  <Grid container>
                    <Grid xs={2}>
                  <img src={step.icon} alt="why" />
                    </Grid>
                    <Grid
                      xs={10}
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        flexDirection: "column",
                      }}
                    >
                      <Typography
                        className="theme2"
                        variant="body2"
                        color="textSecondary"
                        style={{
                          fontFamily: "Roboto",
                          fontSize: "14px",
                          fontStyle: "normal",
                          fontWeight: 400,
                        }}
                      >
                        {step.title}
                      </Typography>
                      <Typography
                        variant="h2"
                        color="textSecondary"
                        style={{
                          fontFamily: "Roboto",
                          fontSize: "18px",
                          fontStyle: "normal",
                          fontWeight: "bold",
                          lineHeight: "26px",
                        }}
                      >
                        {step.mainTitle}
                      </Typography>
                      <Typography
                        variant="body2"
                        color="textSecondary"
                        style={{
                          fontFamily: "Roboto",
                          fontSize: "14px",
                          fontStyle: "normal",
                          fontWeight: "Regular",
                        }}
                      >
                        {step.intro}
                      </Typography>
                    </Grid>
                  </Grid>
                </div>
              </>
            );
          })}

          {/* <div
            className={toggleState === 2 ? "step active-step" : "step"}
            onClick={() => toggleStep(2)}
          >
            <Grid container>
              <Grid xs={2}>
                <img src={Segments} alt="Group Icon" />{" "}
              </Grid>
              <Grid xs={10}>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  className="theme2"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: 400,
                  }}
                >
                  STEP 2
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "18px",
                    fontStyle: "normal",
                    fontWeight: "bold",
                    lineHeight: "26px",
                  }}
                >
                  Segment Creation
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "Regular",
                  }}
                >
                  Customize pre-built segments to target customers effectively
                  and increase click rates.{" "}
                </Typography>
              </Grid>
            </Grid>
          </div>
          <div
            className={toggleState === 3 ? "step active-step" : "step"}
            onClick={() => toggleStep(3)}
          >
            <Grid container>
              <Grid xs={2}>
                <img src={Offers} alt="Group Icon" />
              </Grid>
              <Grid xs={10}>
                <Typography
                  variant="body2"
                  className="theme2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: 400,
                  }}
                >
                  STEP 3
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "18px",
                    fontStyle: "normal",
                    fontWeight: "bold",
                    lineHeight: "26px",
                  }}
                >
                  Design Offers
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "Regular",
                  }}
                >
                  Utilize AI for offers that boost conversions 4x or craft your
                  own to engage customers.
                </Typography>
              </Grid>
            </Grid>
          </div> */}
        </Grid>
        <Grid xs={6}>
          {stepDetail.map((sDetail) => {
          return(
            <>
            <div
              className={
                toggleState === (sDetail.id) ? "contant active-contant" : "contant"
              }
              onClick={() => toggleStep(sDetail.id)}
            >
             <img src={sDetail.img} alt="why" />
              <p>{sDetail.subTitle}</p>
              <p>{sDetail.mainTitle}</p>
              <p>{sDetail.intro}</p>
            </div>
            </>
          )
          })}

        
        </Grid>
      </Grid>
    </div>
  );
}

export default OnboardingSteps;
