import { Button ,  Grid, Typography } from "@mui/material";
import React from "react";
import Group2 from "../../../assets/Group 2.svg";
function OnboardingAi() {
  const subTitle = {
    fontFamily: "Roboto",
    fontSize: "12px",
    fontStyle: "normal",
    fontWeight: 700,
    lineHeight: "18px",
    color: "#5D596C",
  };
  const title = {
    fontFamily: "'IBM Plex Serif",
    fontSize: "24px",
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "37px",
    color: "#414446",
    padding: "5px 0px 20px 0px",
  };
  const intro = {
    fontFamily: "Roboto",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "18px",
    color: "#414446",
    paddingBottom: "49px",
  };
  return (
    <div>
      <Grid container>
        <Grid xs={6}>
          <Typography
            className="theme2"
            variant="body2"
            color="textSecondary"
            style={subTitle}
          >
            AI MODELING PLATFORM 
          </Typography>
          <Typography
            className="theme2"
            variant="body2"
            color="textSecondary"
            style={title}
          >
         Smart Insights, Smarter Decisions - Unleash the Power of AI
          </Typography>
          <Typography
            className="theme2"
            variant="body2"
            color="textSecondary"
            style={intro}
          >
           Introducing your pocket data scientist! Harness AI to extract valuable insights from your data. Predict behaviors, segment effectively, and personalize on a large scale. Elevate your marketing strategies with our smart, time-saving platform.
          </Typography>
          <Button
            variant="contained"
            color="secondary"
            type="submit"
            fullWidth
            sx={{ width: { lg: "241px",fontSize:"16px",textTransform:"capitalize"  } }}
          >
         Activate AI Modeling
          </Button>
        </Grid>
        <Grid xs={6} sx={{textAlign:"center"}}>
          <img src={Group2} alt="" />
        </Grid>
      </Grid>
     
    </div>
  )
}

export default OnboardingAi