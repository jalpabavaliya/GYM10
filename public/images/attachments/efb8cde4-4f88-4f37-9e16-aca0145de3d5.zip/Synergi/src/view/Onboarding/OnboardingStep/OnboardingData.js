import { Button, Grid, Typography } from "@mui/material";
import React from "react";
import Group from "../../../assets/Group.svg";
import { useNavigate } from "react-router-dom";

const Onboardingmain = () => {
  const navigate = useNavigate();
  const handleRedirect = () => {
    navigate("/CustmerDataintelligence");
  };

  const subTitle = {
    fontFamily: "Roboto",
    fontSize: "12px",
    fontStyle: "normal",
    fontWeight: 700,
    lineHeight: "18px",
    color: "#5D596C",
  };
  const title = {
    fontFamily: "'IBM Plex Serif",
    fontSize: "24px",
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "37px",
    color: "#414446",
    padding: "5px 0px 20px 0px",
  };
  const intro = {
    fontFamily: "Roboto",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: "18px",
    color: "#414446",
    paddingBottom: "49px",
  };
  return (
    <div>
      <Grid container>
        <Grid xs={6}>
          <Typography
            className="theme2"
            variant="body2"
            color="textSecondary"
            style={subTitle}
          >
            CUSTOMER DATA INTELLIGENCE
          </Typography>
          <Typography
            className="theme2"
            variant="body2"
            color="textSecondary"
            style={title}
          >
            Your KPIs up by 80% - Your Data Goldmine Awaits, Start Setup Now
          </Typography>
          <Typography
            className="theme2"
            variant="body2"
            color="textSecondary"
            style={intro}
          >
            Introducing your central hub for customer data. Every touchpoint,
            every interaction across your digital assets, captured and ready for
            action. This platform simplifies data management, accelerating your
            path to personalized marketing. Leverage insights you never knew you
            had, and make every interaction count.
          </Typography>
          <Button
            variant="contained"
            color="secondary"
            type="submit"
            fullWidth
            sx={{
              width: { lg: "313px" },
              fontSize: "16px",
              textTransform: "capitalize",
              marginBottom: "27px",
            }}
            onClick={handleRedirect}
          >
            Activate customer Data Intelligence
          </Button>
        </Grid>
        <Grid xs={6} sx={{ textAlign: "center" }}>
          <img src={Group} alt="" />
        </Grid>
      </Grid>
    </div>
  );
};

export default Onboardingmain;
