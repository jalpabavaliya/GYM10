import { useState, useEffect } from "react";
import {
  Card,
  CardHeader,
  Checkbox,
  FormControlLabel,
  FormGroup,
  CardContent,
  Typography,
  CardActions,
  Button,
  Backdrop,
  CircularProgress,
} from "@mui/material";
import {
  createAICraftedForSegment,
  getHistoricalEventData,
} from "../../../../../services/SegmentService";
import TruncatedDescription from "../../../../../ui-components/truncateTooltip/TruncateTooltip";
import { segmentsActions } from "../../../../../store/slices/segments";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";

const { setAICraftedClickedItems, setSegmentList } = segmentsActions;

const AiCreatedSegments = ({ aiInput, setChannelData }) => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const { aICraftedClickedItems } = useSelector((state) => state.segments);

  const handleCreateAICrafted = async (event_id) => {
    setIsLoading(true);
    const payload = { event_id };
    const responseData = await createAICraftedForSegment(payload);
    if (responseData.status === 200) {
      window.alert("AI Crafted created successfully!");
      // Mark the item as clicked
      dispatch(setAICraftedClickedItems({ [event_id]: true }));
      setTimeout(async () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
        const response = await getHistoricalEventData("Recent");
        if (response.status === 200) {
          dispatch(setSegmentList({ segmentList: response.data }));
        } else {
          window.alert("error while fetching By Time Frame");
        }
      }, 100);
    } else {
      window.alert("error while creating AI Crafted");
    }
    setIsLoading(false);
  };

  return (
    <div
      style={{
        display: "flex",
        width: "auto",
        gap: "15px",
      }}
    >
      {Array.isArray(aiInput) &&
        aiInput.length > 0 &&
        aiInput.map((item, index) => (
          <Card
            key={index}
            style={{
              width: "280px",
              height: "257px",
              flexShrink: "0",
              borderRadius: "5px",
              border: "1px solid #EBE8F1",
              background: "#FFF",
              boxShadow: "0px 8px 20px 0px rgba(0, 0, 0, 0.06)",
              padding: "10px",
            }}
          >
            <CardHeader
              title={item.title}
              sx={{
                color: "var(--Col-8, #000)",
                fontFamily: "Roboto",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 600,
                lineHeight: "151.188%",
                textTransform: "capitalize",
              }}
            />
            <div className="customHR" style={{ margin: 0, padding: 0 }}></div>
            <CardContent style={{ paddingTop: "0px" }}>
              <TruncatedDescription description={item.descritption} />
            </CardContent>
            <CardActions>
              <Button
                sx={{
                  color: "var(--col-14, #A35BB1)",
                  fontFamily: "Roboto",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "600",
                  textTransform: "capitalize",
                }}
                disabled={aICraftedClickedItems[item.sk]}
                onClick={() => handleCreateAICrafted(item.sk)}
              >
                Create
              </Button>
            </CardActions>
          </Card>
        ))}
      <Backdrop open={isLoading} sx={{ zIndex: 999999 }}>
        <CircularProgress color="inherit" />
      </Backdrop>
    </div>
  );
};

export default AiCreatedSegments;
