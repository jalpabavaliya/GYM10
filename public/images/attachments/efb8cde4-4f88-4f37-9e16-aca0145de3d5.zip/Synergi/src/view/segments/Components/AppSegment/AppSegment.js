import {
  Backdrop,
  Box,
  Button,
  CircularProgress,
  Grid,
  IconButton,
  Input,
  Paper,
  Table,
  TableBody,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import IntegratedApp from "./IntegratedApp";
import FilterAndSearch from "./FilterAndSearch";
import SouthRoundedIcon from "@mui/icons-material/SouthRounded";
import MoreVertOutlinedIcon from "@mui/icons-material/MoreVertOutlined";
import { useSelector } from "react-redux";
import { useRef } from "react";

const TOTAL_DISPLAY_ROW = 5;

const AppSegment = () => {
  const [allData, setAllData] = useState();
  const [page, setPage] = React.useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [displatDataList, setDisplayDataList] = useState([]);
  const { segmentList } = useSelector((state) => state.segments);

  const viewMoreRef = useRef(null);

  useEffect(() => {
    if (Array.isArray(segmentList) && segmentList.length > 0) {
      setAllData(segmentList);
      const data = segmentList.slice(
        page * TOTAL_DISPLAY_ROW,
        page * TOTAL_DISPLAY_ROW + TOTAL_DISPLAY_ROW
      );
      console.log("data = ", data);
      setDisplayDataList(data);
    }
  }, [segmentList]);

  const handleViewMore = () => {
    setPage(page + 1);
    const data = allData.slice(
      (page + 1) * TOTAL_DISPLAY_ROW,
      (page + 1) * TOTAL_DISPLAY_ROW + TOTAL_DISPLAY_ROW
    );
    setDisplayDataList([...displatDataList, ...data]);
  };

  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "1rem",
          borderBottom: "1px solid #ebe8f1",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            color: "#414446",
            lineHeight: "1.5",
          }}
        >
          <Typography
            sx={{
              fontFamily: "IBM Plex Serif",
              fontSize: "1.5rem",
            }}
          >
            Manage Segments
          </Typography>
        </Box>
        {/* TODO: To add Auto Scroll - onClick - connect apps */}
        <span>
          <Button
            type="submit"
            variant="contained"
            sx={{
              color: "#ffffff",
              fontFamily: "Roboto",
              fontSize: "1rem",
              fontWeight: "Bold",
              textAlign: "center",
              textTransform: "capitalize",
              width: "17rem",
              height: "48px",
              borderRadius: "6px",
              backgroundColor: "#852598",
              ":hover": {
                backgroundColor: "#852598",
              },
            }}
            onClick={() =>
              viewMoreRef.current.scrollIntoView({ behavior: "smooth" })
            }
          >
            Create Segment
          </Button>
          <IconButton sx={{ mt: -5, mr: -3 }}>
            <MoreVertOutlinedIcon />
          </IconButton>
        </span>
      </div>
      <section>
        <Box padding="1rem" sx={!!displatDataList.length && { height: "80vh", overflowY: "auto" }}>
          <FilterAndSearch setDisplayDataList={setDisplayDataList}/>
          {!!displatDataList.length ? (
            <Table>
              <TableBody>
                {Array.isArray(displatDataList) &&
                  displatDataList.length > 0 &&
                  displatDataList.map((segmentData) => (
                    <IntegratedApp segmentData={segmentData} setIsLoading={setIsLoading}/>
                  ))}
              </TableBody>
            </Table>
          ) : (
            <Grid container justifyContent="center" alignItems="center" sx={{ height: "10vh" }}>
              <Typography
                sx={{
                  fontFamily: "Roboto",
                  fontWeight: "Normal",
                  textTransform: "capitalize",
                }}
              >
                No Segment Available
              </Typography>
            </Grid>
          )}
          <Backdrop
            open={isLoading}
            sx={{ zIndex: 999999, position: "inherit" }}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Box>
        {displatDataList.length >= 5 && (
          <Button
            id="segmentViewMore"
            style={{
              width: "100%",
              height: "4rem",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              padding: "1rem",
              color: "#A35BB1",
            }}
            ref={viewMoreRef}
            onClick={handleViewMore}
          >
            <Typography
              sx={{
                fontFamily: "Roboto",
                fontWeight: "Medium",
                fontSize: "0.7rem",
                textTransform: "capitalize",
              }}
            >
              View More
            </Typography>
            <SouthRoundedIcon />
          </Button>
        )}
      </section>
    </>
  );
};

export default AppSegment;
