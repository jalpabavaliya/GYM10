import {
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  IconButton,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";
import ViewIcon from "../../assets/View.svg";
import DownloadIcon from "../../assets/Download.svg";
import ReviewRuleTable from "./ReviewRuleTable";
import { useSelector } from "react-redux";
import moment from "moment-timezone";
import SegmentCreateSuccessFullyDialog from "./SegmentCreateSuccessFullyDialog";

const ReviewSegmentDialog = ({ open, handleClose, nextDailogue }) => {
  const { segmentInfo } = useSelector((state) => state.segments);

  const handleSegmentEdit = () => {
    handleClose();
  };

  const handleSaveSegmentInfo = () => {
    handleClose(false);
    nextDailogue(true);
  };

  const parsedDate = moment.tz(
    segmentInfo?.created_datetime,
    "YYYY-MM-DD HH:mm:ss",
    "America/New_York"
  );
  const formattedDate = parsedDate.format("MM/DD/YY [at] hh:mma");
  return (
    <>
      <Dialog
        fullWidth
        maxWidth="xl"
        open={open}
        onClose={handleClose}
        sx={{
          "& .MuiDialog-paper": {
            minHeight: "550px",
          },
        }}
      >
        <DialogTitle>
          <Grid container justifyContent="space-between">
            <Grid item>
              <Typography
                sx={{
                  color: "#414446",
                  fontFamily: "IBM Plex Serif",
                  fontSize: "24px",
                  fontStyle: "normal",
                  fontWeight: 400,
                  lineHeight: "40px",
                }}
              >
                Review your Segment
              </Typography>
            </Grid>
            <Grid item>
              <IconButton onClick={handleClose}>
                <CloseOutlinedIcon />
              </IconButton>
            </Grid>
          </Grid>
        </DialogTitle>
        <DialogContent>
          <Grid container direction="column">
            <Grid item>
              <Typography
                sx={{
                  color: "var(--col-8, #000)",
                  fontFamily: "Roboto",
                  fontSize: "18px",
                  fontStyle: "normal",
                  fontWeight: 600,
                  lineHeight: "normal",
                  textTransform: "capitalize",
                }}
              >
                Term Reduction
              </Typography>
            </Grid>
            <Grid item sx={{ mt: 2 }}>
              <Typography
                sx={{
                  color: "#414446",
                  fontFamily: "IBM Plex Serif",
                  fontSize: "24px",
                  fontStyle: "normal",
                  fontWeight: 400,
                  lineHeight: "normal",
                  textTransform: "capitalize",
                }}
              >
                {segmentInfo?.total_records}
              </Typography>
            </Grid>
            <Grid item sx={{ mt: 1 }}>
              <Typography
                sx={{
                  color: "var(--col-12, #414446)",
                  fontFamily: "Roboto",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: 400,
                  lineHeight: "173.7%",
                }}
              >
                Contacts found in this seggment as of {formattedDate}
              </Typography>
            </Grid>
            <Grid item>
              <IconButton>
                <img src={ViewIcon} alt="add" />
              </IconButton>
              <IconButton>
                <img src={DownloadIcon} alt="add" />
              </IconButton>
            </Grid>
            <Grid item sx={{ py: 3 }}>
              <Divider />
            </Grid>
            <Grid item>
              <Typography
                sx={{
                  color: "var(--col-12, #414446)",
                  fontFamily: "Roboto",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: 700,
                  lineHeight: "173.7%",
                }}
              >
                Contacts who match all of the following criteria;
              </Typography>
            </Grid>
            <Grid item sx={{ mt: 2 }}>
              <div id="expression-logic-review" />
              <ReviewRuleTable expression={segmentInfo?.where_condition} />
            </Grid>
            <Grid item sx={{ py: 3 }}>
              <Divider />
            </Grid>
          </Grid>
          <Grid container justifyContent="flex-start" spacing={2}>
            <Grid item>
              <Button
                type="submit"
                variant="outlined"
                sx={{
                  textAlign: "center",
                  fontFamily: "Roboto",
                  fontSize: "16px",
                  fontWeight: "600",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  width: "10rem",
                  height: "48px",
                  borderRadius: "6px",
                  marginTop: "2vh",
                }}
                onClick={handleSegmentEdit}
              >
                Edit
              </Button>
            </Grid>
            <Grid item>
              <Button
                type="submit"
                variant="contained"
                style={{
                  color: "#FFF",
                  textAlign: "center",
                  fontFamily: "Roboto",
                  fontSize: "16px",
                  fontStyle: "normal",
                  fontWeight: 600,
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  width: "10rem",
                  height: "48px",
                  borderRadius: "6px",
                  background: "#852598",
                  marginTop: "2vh",
                }}
                onClick={handleSaveSegmentInfo}
              >
                Save Segment
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ReviewSegmentDialog;
