import store from "../../../../store";

const TEXT_OPERATOR_LIST = ['equal', 'not_equal', 'like', 'not_like', 'starts_with', 'ends_with'];
const NUMBER_OPERATOR_LIST = ['less', 'less_or_equal', 'greater', 'greater_or_equal', 'between', 'not_between'];
const DATE_OPERATOR_LIST = ['equal', 'not_equal', 'less', 'less_or_equal', 'greater', 'greater_or_equal', 'between', 'not_between'];

const getFieldType = (dataType, field) => {
    let type = 'text';
    const fieldVal = dataType[field].toLowerCase();
    if (fieldVal === 'number') {
        type = 'number';
    }
    if (fieldVal === 'date') {
        type = 'date';
    }
    return type;
};

const getFieldOperators = (dataType, field) => {
    let operators = TEXT_OPERATOR_LIST;
    const fieldVal = dataType[field].toLowerCase();
    if (fieldVal === 'number') {
        operators = NUMBER_OPERATOR_LIST;
    }
    if (fieldVal === 'date') {
        operators = DATE_OPERATOR_LIST;
    }
    return operators;
};

const getUserFields = () => {
    const { dataType } = store.getState().segments;

    let fields = [];
    if (dataType) {
        fields = Object.keys(dataType).map((field) => {
            return {
                field,
                label: field,
                type: getFieldType(dataType, field),
                operators: getFieldOperators(dataType, field),
                valueSources: ['value']
            };
        });
    }
    return fields;
};

export { getUserFields };
