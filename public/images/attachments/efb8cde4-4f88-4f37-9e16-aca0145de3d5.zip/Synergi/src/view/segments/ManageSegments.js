import React, { useState, useEffect } from "react";
import AppSegment from "./Components/AppSegment/AppSegment";
import SubHeader from "../../ui-components/pageHeaders/SubHeader";
import Channel from "./Components/SegmentsChannel/SegmentChannel";
import { Paper } from "@mui/material";

const ManageSegments = () => {
  const [selectedChannel, setChannel] = useState("Ai");
  const [selectedChannelData, setChannelData] = useState([]);
  const [isSelectedDataCorrect, setCorrect] = useState("Ai");
  return (
    <>
      <Paper
        sx={{
          backgroundColor: "#ffffff",
          width: "100%",
          height: "100%",
          borderRadius: "6px",
        }}
      >
        <AppSegment />
      </Paper>
      <Paper
        sx={{
          backgroundColor: "#ffffff",
          width: "100%",
          height: "100%",
          borderRadius: "6px",
          mb: 1,
        }}
      >
        <Channel
          setChannel={setChannel}
          setChannelData={setChannelData}
          setCorrect={setCorrect}
        />
      </Paper>
    </>
  );
};

export default ManageSegments;
