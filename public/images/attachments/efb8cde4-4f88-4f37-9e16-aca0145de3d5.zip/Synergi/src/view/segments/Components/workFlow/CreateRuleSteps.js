import React, { useState } from "react";
import { Alert, Grid, Snackbar, Step, StepLabel, Stepper } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import PropTypes from "prop-types";
import Step2_SetRule from "./Step2_SetRule";
import { useEffect } from "react";
import { Utils as QbUtils } from "@react-awesome-query-builder/mui";
import moment from "moment-timezone";
import { segmentRuleActions } from "../../../../store/slices/segmentRule";
import { addNewAutomation } from "../../../../store/actions/segmentRuleAction";

const { resetWaWizardInfo, resetActiveTriggerId, updateAutomation } =
segmentRuleActions;

const CreateWorkflowAutomation = ({ handleClose }) => {
  const dispatch = useDispatch();
  const waStepsInfo = useSelector(
    (state) => state.segmentRules.waStepsInfo
  );
  const automations = useSelector(
    (state) => state.segmentRules.automations
  );

  useEffect(() => {
    dispatch(addNewAutomation());
  }, []);

  const automationLength = Array.isArray(automations) && automations.length;
  const { config, tree } = waStepsInfo;
  // const sqlExpression = QbUtils.sqlFormat(tree, config);
  const date = moment().format("YYYY-MM-DD HH:mm");

  return (
    <Grid alignItems="center" justifyContent="center" container spacing={3}>
      <Grid item xs={12} sm={11} md={11}>
        <Step2_SetRule />
        <br />
      </Grid>
    </Grid>
  );
};

CreateWorkflowAutomation.propTypes = {
  handleClose: PropTypes.func,
};

export default CreateWorkflowAutomation;
