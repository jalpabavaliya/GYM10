import { Button, Card, CardContent, Grid, Typography } from "@mui/material";
import {
  Builder,
  Query,
  Utils as QbUtils,
} from "@react-awesome-query-builder/mui";
import "@react-awesome-query-builder/mui/css/styles.css";
import React, { useCallback, useEffect } from "react";
import $ from "jquery";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { useTheme } from "@mui/material/styles";
import "./rules.css";
import ReadableExpression from "./ReadableExpression";
import { updateWAConfigTree } from "../../../../store/actions/segmentRuleAction";

export const getFieldList = (treeData, fieldSet) => {
  if (treeData && treeData.children1) {
    const children = treeData.children1;
    const keys = Object.keys(treeData.children1);
    // eslint-disable-next-line no-restricted-syntax
    for (const key of keys) {
      if (children[key]) {
        if (children[key].type === "group") {
          return getFieldList(children[key].properties, fieldSet);
        }
        if (children[key].properties.field) {
          fieldSet.add(children[key].properties.field);
        }
      }
    }
  }
  return fieldSet;
};

const Step2_SetRule = () => {
  const { waStepsInfo } = useSelector((state) => state.segmentRules);
  const { expression, config, tree } = waStepsInfo;
  const theme = useTheme();
  const dispatch = useDispatch();

  useEffect(() => {
    const rules = document.getElementsByClassName("group--children");
    Object.keys(rules)
      .filter((index) => index !== "0") // skip root group
      .forEach((index) => {
        const ruleOperatorClass =
          rules[index].getElementsByClassName("rule--operator");
      });
  }, [$(".rule--operator")]);

  const cardStyle = {
    background:
      theme.palette.mode === "dark"
        ? theme.palette.dark.main
        : theme.palette.grey[50],
    border: "1px solid",
    borderColor:
      theme.palette.mode === "dark"
        ? theme.palette.dark.main
        : theme.palette.grey[100],
  };

  const onChange = useCallback((immutableTree, cnfig) => {
    const expression = QbUtils.spelFormat(immutableTree, cnfig);
    const fieldTree = QbUtils.getTree(immutableTree, true, false);
    const fields = getFieldList(fieldTree, new Set());
    dispatch(updateWAConfigTree(expression, cnfig, immutableTree, [...fields]));
  }, []);

  const renderBuilder = useCallback(
    (props) => (
      <div className="query-builder-container" style={{ padding: "10px" }}>
        <div className="query-builder">
          <Builder {...props} />
        </div>
      </div>
    ),
    []
  );

  const readableExp = QbUtils.queryString(tree, config, true);
  return (
    <Grid alignItems="center" justifyContent="center" container spacing="3">
      <Grid item xs={12} sm={11} md={11}>
        <Card sx={cardStyle}>
          <CardContent>
            <Grid container>
              <Grid item xs={12} sm={12} lg={12}>
                <Query
                  disabled
                  {...config}
                  value={tree}
                  onChange={onChange}
                  renderBuilder={renderBuilder}
                />
                {readableExp && (
                  <>
                    <Grid item xs={1} sx={{ mt: "5px", mb: "15px" }}>
                      <Typography variant="h5">Rules</Typography>
                    </Grid>
                    <div
                      id="expression-logic-creation"
                      style={{ borderLeft: "5px solid #d5ceb4" }}
                    />
                    <ReadableExpression
                      position="creation"
                      automation={{
                        expression,
                      }}
                    />
                  </>
                )}
              </Grid>
            </Grid>
          </CardContent>
        </Card>
        <Grid item xs={12} sm={11} md={11}>
          <br />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default Step2_SetRule;
