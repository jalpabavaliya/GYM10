import React, { useEffect } from "react";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import PropTypes from "prop-types";
import CreateWorkflowAutomation from "./CreateRuleSteps";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { Backdrop, Button, CircularProgress, DialogActions, Grid } from "@mui/material";
import { useState } from "react";
import { addSegmentCondition } from "../../../../services/SegmentService";
import { segmentsActions } from "../../../../store/slices/segments";
import { addNewAutomation } from "../../../../store/actions/segmentRuleAction";

const { addSegmentConditionDetails } = segmentsActions;

const NewRuleCreateDialog = ({ open, handleClose, nextDailogue }) => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const activeTriggerId = useSelector(
    (state) => state.segmentRules.activeTriggerId
  );
  const { waStepsInfo } = useSelector((state) => state.segmentRules);
  const { segmentInfo } = useSelector((state) => state.segments);

  useEffect(() => {
    if (!activeTriggerId) {
      dispatch(addNewAutomation());
    }
  }, [activeTriggerId]);

  const handleSaveRules = async () => {
    setIsLoading(true);
    const segmentAddConditionInfo = {
      'segment_id': segmentInfo?.segment_id,
      'segment_name': segmentInfo?.segment_name,
      'segment_description': segmentInfo?.segment_description,
      "where_condition": waStepsInfo?.expression, 
    }

    const response = await addSegmentCondition(segmentAddConditionInfo);
    if (response.status === 200) {
      handleClose(false);
      nextDailogue(true);
        dispatch(addSegmentConditionDetails({ response: response.data.response }))
    } else {
      window.alert("error while add Segment condition");
    }
    setIsLoading(false);
  };

  return (
    <>
      <Dialog
        fullWidth
        maxWidth="lg"
        open={open}
        onClose={handleClose}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle id="new-workflow-automation-dialog">
          {activeTriggerId ? "Edit Segment" : "Add New Segment"}
        </DialogTitle>
        <CreateWorkflowAutomation handleClose={handleClose} />
        <DialogActions>
          <Grid container justifyContent="center" alignItems="center">
            <Button
              type="submit"
              variant="contained"
              style={{
                color: "#FFFFFF",
                textAlign: "center",
                fontFamily: "Roboto",
                fontSize: "16px",
                fontStyle: "normal",
                fontWeight: 600,
                lineHeight: "normal",
                textTransform: "capitalize",
                width: "10rem",
                height: "48px",
                borderRadius: "6px",
                background: "#852598",
              }}
              onClick={handleSaveRules}
            >
              Save
            </Button>
          </Grid>
        </DialogActions>
      </Dialog>
      <Backdrop open={isLoading} sx={{ zIndex: 999999 }}>
        <CircularProgress color="inherit" />
      </Backdrop>
    </>
  );
};

NewRuleCreateDialog.propTypes = {
  handleClose: PropTypes.func,
};

export default NewRuleCreateDialog;
