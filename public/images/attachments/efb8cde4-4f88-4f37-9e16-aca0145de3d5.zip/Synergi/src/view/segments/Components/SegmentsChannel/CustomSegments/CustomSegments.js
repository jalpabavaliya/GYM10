import {
  Backdrop,
  Button,
  CircularProgress,
  Grid,
  TextField,
  Typography,
} from "@mui/material";
import React from "react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import NewRuleCreateDialog from "../../workFlow/NewRuleCreateDialog";
import { addNewAutomation } from "../../../../../store/actions/rulesAction";
import {
  createSegment,
  getHistoricalEventData,
  getSegmentConditionColumn,
} from "../../../../../services/SegmentService";
import { segmentsActions } from "../../../../../store/slices/segments";
import ReviewSegmentDialog from "../../AddCondition/ReviewSegmentDialog";
import SegmentCreateSuccessFullyDialog from "../../AddCondition/SegmentCreateSuccessFullyDialog";

const { setCreateSegmentDetails, setDataType, setSegmentList } = segmentsActions;

const CustomSegments = () => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [isNewRuleCreateOpen, setIsNewRuleCreateOpen] = useState(false);
  const [isReviewSegmentOpen, setIsReviewSegmentOpen] = useState(false);
  const [isSegmentCreateSucessOpen, setIsSegmentCreateSuccessOpen] =
    useState(false);
  const [segmentName, setSegmentName] = useState("");
  const [description, setDescription] = useState("");

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleSegmentNameChange = (event) => {
    setSegmentName(event.target.value);
  };

  const handleAddConditionDialog = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    const segmentInfo = {
      segment_name: segmentName,
      segment_description: description,
      event_type: "segment",
    };

    const responseData = await getSegmentConditionColumn();
    if (responseData.status === 200) {
      dispatch(setDataType({ dataType: responseData.data }));
    } else {
      window.alert("error while geting dataType");
    }

    const response = await createSegment(segmentInfo);
    if (response.status === 200) {
      setIsNewRuleCreateOpen(true);
      dispatch(addNewAutomation());
      dispatch(setCreateSegmentDetails({ response: response.data.response }));
    } else {
      window.alert("error while creating segment");
    }
    setIsLoading(false);
  };

  return (
    <>
      <NewRuleCreateDialog
        open={isNewRuleCreateOpen}
        handleClose={(value) => setIsNewRuleCreateOpen(value)}
        nextDailogue={(value) => setIsReviewSegmentOpen(value)}
      />

      <ReviewSegmentDialog
        open={isReviewSegmentOpen}
        handleClose={(value) => setIsReviewSegmentOpen(value)}
        nextDailogue={(value) => setIsSegmentCreateSuccessOpen(value)}
      />

      <SegmentCreateSuccessFullyDialog
        open={isSegmentCreateSucessOpen}
        handleClose={(value) => setIsSegmentCreateSuccessOpen(value)}
      />

      <Grid container justifyContent="flex-start" spacing={2}>
        <Grid item xs={12} md={12} sm={12} lg={12}>
          <Typography>All fields are required</Typography>
        </Grid>
        <Grid item xs={12} md={7} sm={7} lg={7}>
          <form>
            <Grid container spacing={3}>
              <Grid item xs={12} md={7} sm={7} lg={7}>
                <TextField
                  id="segmentName"
                  type="text"
                  fullWidth
                  size="medium"
                  value={segmentName}
                  placeholder="Enter Segment name"
                  onChange={handleSegmentNameChange}
                />
              </Grid>

              <Grid item xs={12} md={7} sm={7} lg={7}>
                <TextField
                  id="description"
                  type="text"
                  fullWidth
                  size="medium"
                  multiline
                  rows={4}
                  value={description}
                  placeholder="Breif description"
                  onChange={handleDescriptionChange}
                />
              </Grid>

              <Grid item xs={12} md={7} sm={7} lg={7}>
                <Typography>
                  Find contacts that match Any of the following:
                </Typography>
              </Grid>
              <Grid item xs={12} md={7} sm={7} lg={7}>
                <Button
                  type="submit"
                  variant="outlined"
                  color="secondary"
                  style={{
                    textAlign: "center",
                    fontFamily: "Roboto",
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 600,
                    lineHeight: "normal",
                    textTransform: "capitalize",
                    width: "10rem",
                    height: "48px",
                    borderRadius: "6px",
                  }}
                  onClick={(event) => handleAddConditionDialog(event)}
                >
                  Add Condition
                </Button>
              </Grid>
            </Grid>
          </form>
        </Grid>
        <Backdrop open={isLoading} sx={{ zIndex: 999999 }}>
          <CircularProgress color="inherit" />
        </Backdrop>
      </Grid>
    </>
  );
};

export default CustomSegments;
