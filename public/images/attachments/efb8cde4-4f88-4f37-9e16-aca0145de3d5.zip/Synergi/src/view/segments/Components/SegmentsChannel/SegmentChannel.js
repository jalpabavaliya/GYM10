import React, { useEffect, useState } from "react";
import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Divider,
  Grid,
  IconButton,
  Typography,
} from "@mui/material";
import { styled } from "@mui/system";
import MoreVertOutlinedIcon from "@mui/icons-material/MoreVertOutlined";
import AiCreatedSegments from "./AiCreatedSegments/AiCreatedSegments";
import CustomSegments from "./CustomSegments/CustomSegments";
import { useDispatch } from "react-redux";
import { getAICraftedListForSegment } from "../../../../services/SegmentService";
import { segmentsActions } from "../../../../store/slices/segments";
import { useSelector } from "react-redux";
// You can replace these with your actual components
const { setAICraftedList } = segmentsActions;

const StyledBox = styled(Box)(({ theme }) => ({
  width: "200px",
  cursor: "pointer",
  textAlign: "center",
}));

const Channel = ({ setChannel, setChannelData, setCorrect }) => {
  const dispatch = useDispatch();
  const [selected, setSelected] = useState("Ai");

  const { segmentAICrafetdList } = useSelector((state) => state.segments);

  const getAICraftedList = async () => {
    const responseData = await getAICraftedListForSegment();
    if (responseData.status === 200) {
      dispatch(setAICraftedList({ segmentAICrafetdList: responseData.data?.data }));
    } else {
      window.alert("error while geting AI Crafted data");
    }
  };

  useEffect(() => {
    getAICraftedList();
  }, []);

  const handleSelection = (selection) => {
    setSelected(selection);
    setChannel(selection);
  };

  const renderComponent = () => {
    if (selected === "Ai") {
      setCorrect(true);
      return (
        <AiCreatedSegments aiInput={segmentAICrafetdList} setChannelData={setChannelData} />
      );
    } else {
      setCorrect(true);
      return <CustomSegments />;
    }
  };

  return (
    <>
      <Grid container sx={{ p: 2 }} spacing={2}>
        <Grid item xs={12} md={12} sm={12} lg={12}>
          <Grid container justifyContent="space-between">
            <Grid item>
              <Typography
                sx={{
                  color: "#414446",
                  fontFamily: "IBM Plex Serif",
                  fontSize: "24px",
                  fontStyle: "normal",
                  fontWeight: 400,
                  lineHeight: "40px",
                }}
              >
                Create New Segment
              </Typography>
            </Grid>
            <Grid item>
              <IconButton>
                <MoreVertOutlinedIcon />
              </IconButton>
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12} md={7} sm={7} lg={6}>
          <Typography
            sx={{
              color: "var(--col-12, #414446)",
              fontFamily: "Roboto",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: 400,
              lineHeight: "173.7%",
            }}
          >
            Use Synergi AI to generate a new segment tailored to current market
            conditions and your data performance, or manually create a new
            segment to meet your unique needs.
          </Typography>
        </Grid>
      </Grid>
      <Grid container>
        <Grid item xs={12} sm={12} md={12}>
          <Card sx={{ mb: 3, mr: 2, maxWidth: "165vh" }}>
            <Box display="flex" alignItems="center" sx={{ pt: 3, pl: 2 }}>
              <StyledBox onClick={() => handleSelection("Ai")}>
                <Typography
                  variant="body1"
                  style={{
                    fontWeight: selected === "Ai" ? "700" : "400",
                    color:
                      selected === "Ai"
                        ? "#764F7D"
                        : "var(--text-txt-primary, #112333)",
                    borderBottom: selected === "Ai" ? "3px solid #764F7D" : "",
                    fontFamily: "DM Sans",
                    fontSize: "18px",
                    fontStyle: "normal",
                    lineHeight: "24px",
                  }}
                >
                  AI-Crafted Segments
                </Typography>
              </StyledBox>

              <StyledBox onClick={() => handleSelection("custome")}>
                <Typography
                  variant="body1"
                  style={{
                    fontWeight: selected === "custome" ? "700" : "400",
                    color:
                      selected === "custome"
                        ? "#764F7D"
                        : "var(--text-txt-primary, #112333)",
                    borderBottom:
                      selected === "custome" ? "3px solid #764F7D" : "",
                    fontFamily: "DM Sans",
                    fontSize: "18px",
                    fontStyle: "normal",
                    lineHeight: "24px",
                  }}
                >
                  Custom Segments
                </Typography>
              </StyledBox>
            </Box>
            <Divider />
            <CardContent>
              <Box p={2} sx={{ overflow: "auto" }}>
                {renderComponent()}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </>
  );
};

export default Channel;
