import React, { useEffect, useState } from 'react';
import { Utils as QbUtils } from '@react-awesome-query-builder/mui';
import PropTypes from 'prop-types';
import '@react-awesome-query-builder/mui/css/styles.css';
import { getUserConfigWithSettings } from '../../../../store/actions/segmentRuleAction';

export const workflowOperatorMapping = {
    equal: 'equal',
    not_equal: 'not equal',
    like: 'like',
    not_like: 'not like',
    starts_with: 'starts with',
    ends_with: 'ends with',
    less: 'less',
    less_or_equal: 'less or equal',
    greater: 'greater',
    greater_or_equal: 'greater or equal',
    between: 'between',
    not_between: 'not between'
};

export const ruleInfoUtils = (rule, config) => {
    const { properties } = rule;
    let op = properties?.operator; // operator
    let ruleValue = properties?.value[0] && properties?.value[0];
    return {
        field: rule.properties.field,
        operator: op,
        value: ruleValue,
        fieldConfig: QbUtils.ConfigUtils.getFieldConfig(config, rule.properties.field)
    };
};

const getChipHtml = (field, title) => `<span class="workflow-logic-chip-${title}">${field}</span>`;

const renderLogic = (expression, config, element, isLast = false) => {
    if (expression?.type === 'group') {
        const rules = expression.children1;
        rules.forEach((childRule, index) => {
            const isLastRule = index === rules.length - 1;
            if (childRule?.type === 'group') {
                const innerElement = document.createElement('div');
                innerElement.style.borderLeftStyle = 'solid';
                innerElement.style.marginLeft = '5px';
                element.appendChild(innerElement);
                renderLogic(childRule, config, innerElement, isLastRule);
            } else {
                renderLogic(childRule, config, element, isLastRule);
            }
            const last = rules.length - 1;
            if (index !== last) {
                const ruleOperator = expression.properties.conjunction;
                element.innerHTML = `${element.innerHTML}${getChipHtml(ruleOperator, 'operator')}<br />`;
            }
        });
    } else {
        const ruleInfo = ruleInfoUtils(expression, config);
        const { field, fieldConfig, operator, value } = ruleInfo;
        const readableOperator = workflowOperatorMapping[operator];
        if (Array.isArray(value)) {
            element.innerHTML = `${element.innerHTML}${getChipHtml(fieldConfig.label, 'label')} ${getChipHtml(
                readableOperator,
                'operator'
            )}  ${value.map((val) => getChipHtml(val, 'value')).join('')}`;
        } else {
            element.innerHTML = `${element.innerHTML} ${getChipHtml(fieldConfig.label, 'label')} ${getChipHtml(
                readableOperator,
                'operator'
            )} ${value ? getChipHtml(value, 'value') : ''}`;
        }
        if (!isLast) {
            element.innerHTML += '<br />';
        }
    }
};

export const Logic = ({ expression, currConfig, position }) => {
    const expressionLogicContainer = document.getElementById(`expression-logic-${position}`);
    expressionLogicContainer.innerText = '';
    renderLogic(expression, currConfig, expressionLogicContainer, false);
    return null;
};

Logic.propTypes = {
    expression: PropTypes.object,
    currConfig: PropTypes.object,
    position: PropTypes.string
};

const ReadableExpression = ({ automation, position }) => {
    const [logic, setLogic] = useState(null);
    const [currConfig, setCurrConfig] = useState(null);

    useEffect(() => {
        const newConfig = getUserConfigWithSettings();
        const [immutableTree, ignoredPart] = QbUtils.loadFromSpel(automation.expression, newConfig);
        const JSON = QbUtils.getTree(immutableTree, newConfig);
        setLogic(JSON);
        setCurrConfig(newConfig);
    }, [automation]);
    if (!logic) {
        return null;
    }
    return <Logic position={`${position}`} expression={logic} currConfig={currConfig} />;
};

ReadableExpression.propTypes = {
    automation: PropTypes.object,
    position: PropTypes.string
};

export default ReadableExpression;
