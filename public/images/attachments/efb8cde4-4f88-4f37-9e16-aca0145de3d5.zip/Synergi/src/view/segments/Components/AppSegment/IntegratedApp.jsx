import {
  Button,
  Divider,
  IconButton,
  TableCell,
  TableRow,
  Tooltip,
  Zoom,
} from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import "./IntegrateApp.css";
import ViewIcon from "../../assets/View.svg";
import CopyIcon from "../../assets/Copy.svg";
import DeleteIcon from "../../assets/Delete.svg";
import EditIcon from "../../assets/Edit.svg";
import ViewSegmentDialog from "./ViewSegmentDialog";
import moment from "moment-timezone";
import Data from "./Data";
import { deleteSegment } from "../../../../services/SegmentService";
import { segmentsActions } from "../../../../store/slices/segments";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";

const { setSegmentList, setAICraftedClickedItems } = segmentsActions;

const ToolTipSelector = (type, dateTime, children) => {
  switch (type) {
    case "success":
      return (
        <Tooltip
          arrow
          placement="right"
          TransitionComponent={Zoom}
          followCursor={true}
          style={{
            backgroundColor: "#158C6F",
            borderColor: "2px solid #158C6F",
          }}
          title={
            <>
              <div>Integration Successful</div>
              <div>
                Connected To App Since {dateTime}. All Systems Functions
                Normally
              </div>
            </>
          }
        >
          {children}
        </Tooltip>
      );

    default:
  }
};

const AppNameCategoryConnection = ({
  created,
  segmentData,
  popoverRef,
  popover,
  handlePopoverOpen,
  handlePopoverClose,
  setIsLoading,
}) => {
  const dispatch = useDispatch();
  const { segmentList } = useSelector((state) => state.segments);

  const handleDeleteSegment = async () => {
    setIsLoading(true);
    const payload = { event_id: segmentData.sk };
    const responseData = await deleteSegment(payload);
    if (responseData.status === 200) {
      const newSegmentList =
        segmentList.length > 0 &&
        segmentList.filter((segment) => segment.sk !== segmentData.sk);
      dispatch(setSegmentList({ segmentList: newSegmentList }));
      dispatch(setAICraftedClickedItems({ [segmentData.sk]: false }));
    } else {
      window.alert("error while delete the offer");
    }
    setIsLoading(false);
  };

  const isButttonHidden = segmentData?.total_run_campaigns === 0;
  return (
    <>
      <ViewSegmentDialog
        popoverRef={popoverRef}
        popover={popover}
        handlePopoverClose={handlePopoverClose}
      />
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          fontFamily: "Roboto",
          lineHeight: 1.5,
          width: "100%",
        }}
      >
        {/* <ToolTipSelector type='success' dateTime=''> */}
        <span
          style={{
            color: "#852598",
            fontFamily: "Roboto",
            fontSize: "16px",
            fontStyle: "normal",
            fontWeight: 600,
            lineHeight: "normal",
          }}
        >
          {segmentData?.name}
        </span>
        <span
          style={{
            color: "var(--col-8, #112333)",
            fontFamily: "Roboto",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 400,
            lineHeight: "149.453%",
            marginTop: "10px",
          }}
        >
          {segmentData?.description}
        </span>
        <span
          style={{
            color: "var(--col-12, #414446)",
            fontFamily: "Roboto",
            fontSize: "12px",
            fontStyle: "normal",
            fontWeight: 400,
            lineHeight: "173.7%",
          }}
        >
          {created}
        </span>
      </div>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          fontFamily: "Roboto",
          lineHeight: 1.5,
          width: "100%",
        }}
      >
        <IconButton
          title="View Segment"
          onClick={(event) => handlePopoverOpen(event, segmentData)}
        >
          <img src={ViewIcon} alt="add" />
        </IconButton>
        <IconButton title="Copy Segment">
          <img src={CopyIcon} alt="add" />
        </IconButton>
        {isButttonHidden && (
          <>
            <Divider
              orientation="vertical"
              flexItem
              sx={{ mx: 1, my: 0.5, width: "10px" }}
            />
            <IconButton title="Delete Segment" onClick={handleDeleteSegment}>
              <img src={DeleteIcon} alt="add" />
            </IconButton>
            <IconButton title="Edit Segment">
              <img src={EditIcon} alt="add" />
            </IconButton>
          </>
        )}
      </div>
    </>
  );
};

const UsesCampaign = ({ totalCompaigns }) => (
  <div
    style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "flex",
      fontFamily: "Roboto",
      width: "100%",
    }}
  >
    <span style={{ color: "#5D596C" }}>Uses</span>
    <div
      style={{
        display: "flex",
        color: "#A35BB1",
        alignItems: "center",
        gap: "0.5rem",
      }}
    >
      <span style={{ fontFamily: "IBM Plex Serif", fontSize: "24px" }}>
        {totalCompaigns}
      </span>
      <span style={{ fontSize: "12px", fontWeight: "medium" }}>Campaigns</span>
    </div>
  </div>
);

const ConnectedAnalytics = ({ analytics }) => (
  <div
    style={{
      width: "100%",
      display: "flex",
      border: "2px solid #EBE8F1",
      backgroundColor: "#F6F5F8",
      gap: "1rem",
      padding: "0.5rem",
      borderRadius: "5px",
    }}
  >
    <div className="AnalyticsProperty">
      <span className="heading">Conversion</span>
      <span className="value">{analytics?.Engagement}</span>
    </div>
    <div className="AnalyticsProperty">
      <span className="heading">CPL</span>
      <span className="value">{analytics?.CAC}</span>
    </div>
    <div className="AnalyticsProperty">
      <span className="heading">CAC</span>
      <span className="value">{analytics?.CAC}</span>
    </div>
    <div className="AnalyticsProperty">
      <span className="heading">ROI</span>
      <span className="value">{analytics?.ROI}</span>
    </div>
  </div>
);

const IntegratedApp = ({ segmentData, setIsLoading }) => {
  const [popover, setPopover] = useState({
    open: false,
    anchorEl: null,
    content: "",
  });

  const popoverRef = useRef();

  useEffect(() => {
    function handleClickOutside(event) {
      if (popoverRef.current && !popoverRef.current.contains(event.target)) {
        setPopover({ open: false, anchorEl: null, content: "" });
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [popover]);

  const handlePopoverOpen = (event, content) => {
    event.stopPropagation();
    event.preventDefault();
    setPopover({ open: true, anchorEl: event.currentTarget, content });
  };

  const handlePopoverClose = () => {
    setPopover({ open: false, anchorEl: null, content: "" });
  };

  const parsedDate = moment.tz(
    segmentData?.created_datetime,
    "YYYY-MM-DD HH:mm:ss",
    "America/New_York"
  );
  const formattedDate = parsedDate.format("MM/DD/YY [at] hh:mma");
  const created = `Created by Synergi At ${formattedDate}`;
  return (
    <TableRow sx={{ height: "100%" }}>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem 0",
          width: "70%",
        }}
      >
        <AppNameCategoryConnection
          created={created}
          segmentData={segmentData}
          popoverRef={popoverRef}
          popover={popover}
          handlePopoverOpen={handlePopoverOpen}
          handlePopoverClose={handlePopoverClose}
          setIsLoading={setIsLoading}
        />
      </TableCell>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem 0",
          width: "8rem",
        }}
      >
        <UsesCampaign totalCompaigns={segmentData?.total_run_campaigns} />
      </TableCell>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem 0",
          width: "8rem",
        }}
      >
        <Data value={segmentData?.total_records} />
      </TableCell>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem",
          width: "16rem",
        }}
      >
        <ConnectedAnalytics analytics={segmentData?.kpi} />
      </TableCell>
    </TableRow>
  );
};

export default IntegratedApp;
