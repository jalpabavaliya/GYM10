import {
  AppBar,
  Box,
  Container,
  Grid,
  Toolbar,
  Typography,
  useTheme,
} from "@mui/material";
import MainHeader from "./mainHeader/MainHeader";

import MainBody from "./mainBody/MainBody";
import Login from "./login/Login";
import Registration from "./register/Registration";
import { useState } from "react";
import RegistrationStep1 from "./register/RegistrationStep1";
import RegistrationStep2 from "./register/RegistrationStep2";
import { useNavigate } from "react-router-dom";
import LoginCard from "../ui-components/cards/LoginCard";
import MainFooter from "./mainFooter/MainFooter";

const RegistrationStepContent = ({ activeStep, handleBack, handleNext }) => {
  const theme=useTheme();
  switch (activeStep) {
    case 0:
      return (
        <Grid container direction="row">
          <Grid
            item
            xs={12}
            sm={12}
            md={9}
            lg={7}
            sx={{
              marginRight: "175px",
              marginLeft: "0px",
              [theme.breakpoints.down("lg")]: {
                marginRight: "75px",
                marginLeft: "0px",
              },
              [theme.breakpoints.down("md")]: {
                marginRight: "55px",
                marginLeft: "55px",
              },
              [theme.breakpoints.down("sm")]: {
                marginRight: "25px",
                marginLeft: "25px",
              },
            
            }}
          >
            <LoginCard>
              <Registration handleNext={handleNext} />
            </LoginCard>
          </Grid>
        </Grid>
      );
    case 1:
      return (
        <Grid container direction="row" >
          <Grid item  xs={12}
            sm={12}
            md={9}
            lg={7}
            sx={{
              marginRight: "175px",
              marginLeft: "0px",
              [theme.breakpoints.down("lg")]: {
                marginRight: "75px",
                marginLeft: "0px",
              },
              [theme.breakpoints.down("md")]: {
                marginRight: "55px",
                marginLeft: "55px",
              },
              [theme.breakpoints.down("sm")]: {
                marginRight: "35px",
                marginLeft: "35px",
                
              },
            }}>
            <LoginCard>
              <RegistrationStep1 handleNext={handleNext} />
            </LoginCard>
          </Grid>
        </Grid>
      );
    case 2:
      return (
        <Grid container direction="row">
          <Grid item  xs={12}
            sm={12}
            md={9}
            lg={7}
            sx={{
              marginRight: "175px",
              marginLeft: "0px",
              [theme.breakpoints.down("lg")]: {
                marginRight: "75px",
                marginLeft: "0px",
              },
              [theme.breakpoints.down("md")]: {
                marginRight: "55px",
                marginLeft: "55px",
              },
              [theme.breakpoints.down("sm")]: {
                marginRight: "35px",
                marginLeft: "35px",
              
              },
            }}>
            <LoginCard>
              <RegistrationStep2 handleNext={handleNext} />
            </LoginCard>
          </Grid>
        </Grid>
      );
    default:
      throw new Error("Unknown step");
  }
};

const Synergi = () => {
  const navigate = useNavigate();
  const [registerActivePage, setRegisterActivePage] = useState(0);

  const handleBack = () => {
    setRegisterActivePage(registerActivePage - 1);
  };

  const handleNext = () => {
    if (registerActivePage === 2) {
      navigate("/login");
    }
    setRegisterActivePage(registerActivePage + 1);
  };

  const pathname = window.location.pathname;
  return (
    <Grid container direction="row">
      <Grid item xs={12}>
        <MainHeader />
      </Grid>
      <Grid
        item
        xs={12}
        sx={{
          backgroundColor: "#2B0433",
          backgroundImage: `
              url("https://generation-sessions.s3.amazonaws.com/c2fdc9dc1907f3591108e718a8db0a65/img/group-1000005273.png")`,
          backgroundSize: "85vh 86vh",
          backgroundRepeat: "no-repeat",
          paddingRight: { xs: "4%", sm: "10%", md: "10%",lg:"10%" },
       
          backgroundPosition: "calc(100% - 25%) center", // This ensures the image is positioned on the right side
        }}
      >
        {(pathname === "/login" || pathname === "/") && <Login />}

        {pathname === "/registration" && (
          <RegistrationStepContent
            activeStep={registerActivePage}
            handleBack={handleBack}
            handleNext={handleNext}
          />
        )}
      </Grid>
      <Grid item xs={12}>
        <MainFooter />
      </Grid>
    </Grid>
    // <Box
    //   display="flex"
    //   flexDirection="column"
    //   minHeight="100vh" // ensures full viewport height coverage
    // >
    //   <MainHeader />
    //   <Grid sx={{ backgroundColor: "#2B0433" }}>
    //   {/* <Container flex={1} sx={{ backgroundColor: "#2B0433" }}> */}
    //    {(pathname === "/login" || pathname === "/") && <Login />}
    //     {pathname === "/registration" && (
    //       <RegistrationStepContent
    //         activeStep={registerActivePage}
    //         handleBack={handleBack}
    //         handleNext={handleNext}
    //       />
    //     )}
    //     {/* </Container> */}
    //   </Grid>

    //   <footer>
    //     <Container>
    //       <MainFooter />
    //     </Container>
    //   </footer>
    // </Box>
  );
};

export default Synergi;
