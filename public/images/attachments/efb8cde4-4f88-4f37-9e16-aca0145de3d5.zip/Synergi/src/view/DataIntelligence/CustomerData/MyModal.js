import { Card, Grid, Typography } from "@mui/material";
import "./customerdata.css";
import CloseIcon from "@mui/icons-material/Close";
import CustomerdataPr from "../../../assets/customerdatapr.png";

const MyModal = ({ closeModal }) => {
  return (
    <>
      <div className="wrapper"></div>
      <Card sx={{ my: 5, borderRadius: 6, padding: "6px" }} className="modal">
        <Grid container>
          <Grid xs={12} onClick={closeModal} sx={{display:"flex",justifyContent:"flex-end"}}>
            <CloseIcon />
          </Grid>
         <Grid container sx={{padding:"102px 160px 0px 160px "}}> 
         <Grid xs={7}>
            <Typography
              style={{
                fontFamily: "IBM Plex",
                fontSize: "24px",
              
                color: "#414446",
              }}
            >
              Assessing Your Customer Data Requirements
            </Typography>
            <Typography  variant="h6"
             style={{
              paddingTop:"18px",
                fontSize: "14px",
                color: "#414446",
              }}>
            Matching optimal data strategies... Just a moment.
            </Typography>
          </Grid>
          <Grid xs={5} sx={{paddingLeft:"20px"}}>
          <img src={CustomerdataPr} alt="Group Icon" />
          </Grid>
         </Grid>
        </Grid>
       
      </Card>
    </>
  );
};
export default MyModal;
