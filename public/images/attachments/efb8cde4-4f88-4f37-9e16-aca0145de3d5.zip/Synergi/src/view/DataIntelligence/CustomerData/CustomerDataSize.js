import { Grid, TextField, Typography } from '@mui/material'
import React from 'react'

function CustomerDataSize() {
  return (
    <div>
        <Grid container spacing={1} sx={{ padding: "25px"}}>
        <Grid item xs={12} style={{paddingTop:"0px"}}>
          <Typography
            variant="h5"
            style={{
              fontFamily: "Roboto",
              fontSize: "18px",
              fontStyle: "normal",
              fontWeight: 600,
             
            }}
          >
           Size of  Customer Database
          </Typography>
        </Grid>
       
        <Grid item xs={12} style={{paddingTop:"20px"}}>
          <TextField
            type="text"
            fullWidth
            size="medium"
            placeholder="Aproximate GB"
          />
        </Grid>
      
      </Grid>
    </div>
  )
}

export default CustomerDataSize