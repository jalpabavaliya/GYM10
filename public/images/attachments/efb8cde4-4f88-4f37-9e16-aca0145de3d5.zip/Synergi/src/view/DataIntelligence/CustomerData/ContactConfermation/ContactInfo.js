import {
    Checkbox,
    FormControlLabel,
    Grid,
    TextField,
    Typography,
  } from "@mui/material";
  import React from "react";
  import { useState } from "react";
  import "../customerdata.css";
  
  function ContactInfo() {
   
  
  
    return (
      <div>
        <Grid container spacing={1} sx={{ padding: "25px" }}>
          <Grid item xs={12} style={{paddingTop:"0px"}}>
            <Typography
              variant="h5"
              style={{
                fontFamily: "Roboto",
                fontSize: "18px",
                fontStyle: "normal",
                fontWeight: 600,
                paddingBottom: "8px",
              }}
            >
           Just Confirming Your Contact Information
            </Typography>
          </Grid>
     
          <Grid item xs={6} >
            <TextField
              type="text"
              fullWidth
              size="medium"
              placeholder="Auto-filled from registration"
            />
          </Grid>
         
          <Grid item xs={6} >
            <TextField
              type="text"
              fullWidth
              size="medium"
              placeholder="Auto-filled from registration"
            />
          </Grid>
         
          <Grid item xs={12} style={{paddingTop:"16px"}}>
            <TextField
              type="text"
              fullWidth
              size="medium"
              placeholder="Auto-filled from registration"
            />
          </Grid>
         
          <Grid item xs={12} style={{paddingTop:"16px"}}>
            <TextField
              type="text"
              fullWidth
              size="medium"
              placeholder="Auto-filled from registration"
            />
          </Grid>
         
        </Grid>
      </div>
    );
  }
  
  export default ContactInfo;
  
