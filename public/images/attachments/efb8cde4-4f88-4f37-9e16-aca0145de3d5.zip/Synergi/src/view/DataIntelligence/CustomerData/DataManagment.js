import {
  Checkbox,
  FormControlLabel,
  Grid,
  TextField,
  Typography,
} from "@mui/material";
import React from "react";
import { useState } from "react";
import "./customerdata.css";

function DataManagment() {
  const DATA_MANAGMENT_LIST = [
    "Web Analytics & Engagement Data",
    "Campaign Reporting Data",
    "Call Center Data",
    "Chat Data",
    "Lead Management & Performance Data",
    "Application Pipeline Data",
    "Servicing Loan Data Snapshots",
    "Third Party Lead Data",
    "Pricing Engine Data",
    "Internal Customer Data from Other Lines of Businesses",
    "Customer Engagement Data History",
  ];

  const [checkedItems, setCheckedItems] = useState({});

  const handleCheckboxChange = (event) => {
    setCheckedItems({
      ...checkedItems,
      [event.target.name]: event.target.checked,
    });
  };

  return (
    <div>
      <Grid container spacing={1} sx={{ padding: "25px" }}>
        <Grid item xs={12}>
          <Typography
            variant="h5"
            style={{
              fontFamily: "Roboto",
              fontSize: "18px",
              fontStyle: "normal",
              fontWeight: 600,
              paddingBottom: "25px",
            }}
          >
            Current Data Management Solution
          </Typography>
        </Grid>
        {DATA_MANAGMENT_LIST.map((dataText, index) => (
          <Grid item xs={4} key={index} style={{
            paddingTop:"3px"
          }}>
            <div style={{ display: "flex" }}>
              <FormControlLabel
                control={
                  <Checkbox
                    size="small"
                    checked={checkedItems[dataText] || false}
                    onChange={handleCheckboxChange}
                    name={dataText}
                    style={{
                      color: checkedItems[dataText] ? "#4CAF50" : "inherit",
                    }}
                  />
                }
                label={<Typography  style={{  fontSize: "12px" }}>{dataText}</Typography>}
                style={{
                 
                  marginRight: "5px",
                  color: checkedItems[dataText] ? "#4CAF50" : "inherit",
                }}
              />
              {/* <label style={{  fontSize: "12px" }}>{dataText}</label> */}
            </div>
          </Grid>
        ))}
        <Grid item xs={12} style={{paddingTop:"51px"}}>
          <TextField
            type="text"
            fullWidth
            size="medium"
            placeholder="Other Customer Data"
          />
        </Grid>
       
      </Grid>
    </div>
  );
}

export default DataManagment;
