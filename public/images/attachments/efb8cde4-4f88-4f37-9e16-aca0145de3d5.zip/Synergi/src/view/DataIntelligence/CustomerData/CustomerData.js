import React,{useState} from "react";
import DataManagment from "./DataManagment";
import { Button, Grid, Typography } from "@mui/material";
import CustomerdataIntelligence from "./CustomerdataIntelligence";
import CustomerDataSize from "./CustomerDataSize";
import MyModal from "./MyModal"
function CustomerData() {

  const [showModal , setShowModal]=useState(false);

  const closeModal = () => setShowModal(false);
 

  return (
    <div>
      <Grid container>
     
        <Grid item xs={7}>
        <section style={{
           padding:"0px 22px"
        }}>
        <Typography
            variant="h5"
            style={{
              fontFamily: "Roboto",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: 600,
             padding:"20px 0px",color:"#414446"
            }}
          >
          Share your customer data details, and our Synergi team will tailor a plan just for you. Let's get started!
          </Typography>
          <Typography
            variant="h5"
            style={{
              fontFamily: "Roboto",
              fontSize: "12px",
              fontStyle: "normal",
              fontWeight: 400,
              color:"#5D596C",
             paddingBottom:"15px"
            }}
          >
       <span style={{color:"#8E0000",
       }}>*</span>All fields are required'
          </Typography>
        </section>
          <section
            style={{
              display: "flex",
              flexDirection: "column",
              rowGap: "1rem",
              border: "1px solid #EBE8F1",
              borderRadius: "5px",
              height: "371px",
              width: "679px",
              marginLeft: "22px",
            }}
          >
            <DataManagment />
          </section>
          <section
            style={{
              display: "flex",
              flexDirection: "column",
              rowGap: "1rem",
              border: "1px solid #EBE8F1",
              borderRadius: "5px",
              height: "137px",
              width: "679px",
              marginLeft: "22px",
              marginTop: "18px",
            }}
          >
            <CustomerDataSize />
          </section>

          <Button
            variant="contained"
            color="secondary"
            type="submit"
            fullWidth
            sx={{ width: { lg: "179px" }, margin :"51px 22px 29px 20px" }}
            onClick={()=>setShowModal(true)}
          >
           Explore Options
          </Button>
          {showModal && <MyModal closeModal={closeModal}/>}
        </Grid>
        <Grid item xs={5}>
          <CustomerdataIntelligence />
        </Grid>
      </Grid>
    </div>
  );
}

export default CustomerData;
