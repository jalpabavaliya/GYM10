import { Button, Card, Grid, Typography } from "@mui/material";
import "../customerdata.css";
import CloseIcon from "@mui/icons-material/Close";
import ProcessDashboard from "../../../../assets/process_dashboard.svg";
const Modal = ({ closeModal }) => {
  return (
    <>
      <div className="wrapper"></div>
      <Card sx={{ my: 5, borderRadius: 6, padding: "6px" }} className="modal">
        <Grid container>
          <Grid xs={12} onClick={closeModal} sx={{display:"flex",justifyContent:"flex-end"}}>
            <CloseIcon />
          </Grid>
         <Grid container sx={{padding:"76px 66px 0px 80px "}}> 
         <Grid xs={7} sx={{paddingRight:"80px"}}>
            <Typography
              style={{
                fontFamily: "IBM Plex",
                fontSize: "24px",
              
                color: "#414446",
              }}
            >
             Great job!
            </Typography>
            <Typography  variant="h6"
             style={{
              paddingTop:"18px",
                fontSize: "14px",
                color: "#414446",
              }}>
          A member of the Synergi team will reach out to you within the next 24-48 hours to finalize your custom data solution. In the meantime, you can explore more features on your dashboard.
            </Typography>
            <Button
            variant="contained"
            color="secondary"
            type="submit"
            fullWidth
            sx={{ width: { lg: "253px" }, margin :"53px 0px 29px 0px" }}
         
          >
        Proceed to Dashboard
          </Button>
          </Grid>
          <Grid xs={5} sx={{paddingLeft:"20px"}}>
          <img src={ProcessDashboard} alt="Group Icon" />
          </Grid>
         </Grid>
        </Grid>
       
      </Card>
    </>
  );
};
export default Modal;
