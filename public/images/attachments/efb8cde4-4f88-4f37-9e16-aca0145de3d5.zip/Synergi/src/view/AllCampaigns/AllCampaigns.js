import React, { useEffect, useState } from "react";
import { CircularProgress, Button } from "@mui/material";
import {
  getManageAllCampaign,
  postManageAllCampaign,
} from "../../services/AllCampaign";
import channelIconMapping from "../Utils/icons/channelIconMapping";
import { CustomTempIcon, CustomFiltersIcon } from "../Utils/icons/icons";
import Search from "./Search/Search";
import CampaignPopUp from "./CampaignPopUp/CampaignPopUp";
import CustomButton2 from "../Utils/CustomButton2/CustomButton2";
import CustomButton from "../Utils/CustomButton/CustomButton";
import { CustomPaidSearchIcon } from "../Utils/icons/icons";
import "../style.css";

const AllCampaigns = () => {
  const [allCampaignsData, setAllCampaignsData] = useState();
  const [currentPage, setCurrentPage] = useState(1);
  const [filteredData, setFilteredData] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState(null);

  const itemsPerPage = 5;

  const ordinalSuffix = (num) => {
    const j = num % 10,
      k = num % 100;
    if (j === 1 && k !== 11) return num + "st";
    if (j === 2 && k !== 12) return num + "nd";
    if (j === 3 && k !== 13) return num + "rd";
    return num + "th";
  };

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    return `${months[date.getMonth()]} ${ordinalSuffix(date.getDate())}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Running":
        return "#158C6F";
      case "Paused":
        return "#E08029";
      case "Error":
        return "#8E0000";
      case "Archived":
        return "#414446";
      default:
        return "#414446"; // default color
    }
  };

  const totalPages = Math.ceil(filteredData?.length / itemsPerPage);
  const currentData = filteredData?.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (pageNumber) => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
    setCurrentPage(pageNumber);
  };

  const handleDialogOpen = (item, name, pk) => {
    setSelectedCampaign({ popup: item, name: name, pk: pk });
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setSelectedCampaign(null);
    setOpenDialog(false);
  };

  useEffect(() => {
    (async () => {
      const response = await getManageAllCampaign("campaign");
      console.log("ALL response", response);
      setAllCampaignsData(response.data);
      setFilteredData(response.data);
    })();
  }, []);

  return (
    <div style={{ padding: "10px" }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div className="manageAllCampaignText">Manage All Campaigns</div>
        <CustomButton
          buttonValue={"create new campaign"}
          style={{
            width: "237px",
            height: "44px",
            marginLeft: "0px",
            marginRight: "20px",
          }}
          onClick={null}
          isDisabled={false}
        />
      </div>
      <hr style={{ marginTop: "15px", marginBottom: "15px" }} />
      <div style={{ display: "flex", alignItems: "center" }}>
        <CustomButton2
          buttonValue={"by Top Performing"}
          CustomIcon={<CustomFiltersIcon />}
          onClick={null}
        />
        <CustomButton2
          buttonValue={"Recent"}
          style={{ marginLeft: "10px" }}
          CustomIcon={<CustomFiltersIcon />}
          onClick={null}
        />
        <Search
          data={allCampaignsData}
          onSearchResult={(results) => {
            setFilteredData(results);
            setCurrentPage(1);
          }}
          style={{ marginLeft: "10px" }}
          CustomIcon={<CustomPaidSearchIcon />}
        />
      </div>

      <hr style={{ marginTop: "15px", marginBottom: "15px" }} />

      <div>
        {currentData && currentData.length > 0 ? (
          currentData.map((item, index) => (
            <div>
              <div key={index} style={{ display: "flex", width: "100%" }}>
                <div
                  style={{
                    flex: "0 0 5%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <CustomTempIcon />
                  <div
                    style={{
                      width: "10px",
                      height: "10px",
                      borderRadius: "50%",
                      marginTop: "9px",
                      backgroundColor: getStatusColor(item.status),
                      marginRight: "10px",
                      marginLeft: "10px",
                    }}
                  ></div>
                </div>
                <div style={{ flex: "0 0 45%" }}>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <h2
                      style={{
                        color: getStatusColor(item.status),
                        cursor: "pointer",
                      }}
                      onClick={() =>
                        handleDialogOpen(item.popup, item.name, item.pk)
                      }
                    >
                      {item.name}
                    </h2>
                    <h4 style={{ marginLeft: "10px" }}>({item.status})</h4>
                  </div>
                  <h3>
                    <div>{item.description}</div>
                    <div style={{ marginTop: "-2px" }}>
                      Campaign Duration:{" "}
                      {formatDate(item.campaign_start_datetime)}{" "}
                      {new Date(item.campaign_start_datetime).getFullYear()} to{" "}
                      {formatDate(item.campaign_end_datetime)},{" "}
                      {new Date(item.campaign_end_datetime).getFullYear()}
                    </div>
                    <h3>
                      Created by {item?.created_by || "Alex"} on{" "}
                      {formatDate(item.created_datetime)},{" "}
                      {new Date(item.created_datetime).getFullYear()}
                    </h3>{" "}
                    <div style={{ width: "60%", marginTop: "10px" }}>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "row",
                          justifyContent: "space-between",
                        }}
                      >
                        {Object.keys(item.channel_2_offers).map(
                          (key, value) => {
                            const IconComponent = channelIconMapping[key];
                            return (
                              <div key={key}>
                                <div
                                  style={{
                                    width: "20px",
                                    height: "20px",
                                    borderRadius: "50%",
                                    border: "1px solid #EBE8F1",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    marginBottom: "5px",
                                  }}
                                >
                                  <div
                                    style={{
                                      transform: "scale(0.75)",
                                      display: "inline-flex",
                                      justifyContent: "center",
                                      alignItems: "center",
                                    }}
                                  >
                                    {IconComponent ? <IconComponent /> : key}
                                  </div>
                                </div>
                                <div
                                  style={{
                                    textAlign: "center",
                                  }}
                                >
                                  {value}
                                </div>
                              </div>
                            );
                          }
                        )}
                      </div>
                    </div>
                  </h3>
                </div>
                <div style={{ flex: "0 0 20%" }}>
                  <h3>Objective</h3>
                  <h1 style={{ fontWeight: "400" }}>{item.objective}</h1>
                </div>
                <div style={{ flex: "0 0 30%" }}>
                  <div
                    style={{
                      width: "233px",
                      textAlign: "left",
                      border: "1px solid #EBE8F1",
                      background: "#F6F5F8",
                      borderRadius: "5px",
                      padding: "5px",
                      display: "flex",
                      flexDirection: "column",
                      height: "53px",
                      justifyContent: "center",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        marginBottom: "10px",
                      }}
                    >
                      {Object.entries(item.kpi).map(([key]) => (
                        <div
                          className="grid-content-key"
                          style={{
                            flex: `1 1 ${100 / Object.keys(item.kpi).length}%`,
                            color: "var(--col-6, #5D596C)",
                            textAlign: "center",
                          }}
                          key={key}
                        >
                          {key}
                        </div>
                      ))}
                    </div>

                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        marginTop: "10px",
                      }}
                    >
                      {Object.entries(item.kpi).map(([key, value]) => (
                        <div
                          className="grid-content-value"
                          style={{
                            flex: `1 1 ${100 / Object.keys(item.kpi).length}%`,
                            color: "var(--col-6, #414446)",
                            textAlign: "center",
                          }}
                          key={key}
                        >
                          {value}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <hr style={{ marginTop: "15px", marginBottom: "15px" }} />
            </div>
          ))
        ) : filteredData && filteredData.length === 0 ? (
          <>
            <h1 style={{ marginTop: "20px", color: "#8E0000" }}>
              No results found,
            </h1>
            <h2
              style={{ marginTop: "20px", color: "#8E0000", fontWeight: "400" }}
            >
              Please check the search input value.
            </h2>
          </>
        ) : (
          <div
            style={{
              width: "100%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100%",
              fontSize: "32px",
            }}
          >
            <CircularProgress color="secondary" />
          </div>
        )}
      </div>
      <div
        style={{ display: "flex", justifyContent: "center", margin: "20px 0" }}
      >
        {Array.from({ length: totalPages }).map((_, index) => (
          <button
            key={index}
            onClick={() => handlePageChange(index + 1)}
            style={{
              padding: "10px 20px",
              margin: "0 5px",
              cursor: "pointer",
              background: index + 1 === currentPage ? "#A35BB1" : "#f4f4f4",
              color: index + 1 === currentPage ? "#f4f4f4" : "#171a1c",
              border: "none",
              borderRadius: "4px",
            }}
          >
            {index + 1}
          </button>
        ))}
      </div>
      <CampaignPopUp
        open={openDialog}
        handleClose={handleDialogClose}
        data={selectedCampaign}
      />
    </div>
  );
};

export default AllCampaigns;
