/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from "react";
import Fuse from "fuse.js";

const Search = ({ data, onSearchResult, style, CustomIcon }) => {
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    handleSearch(searchTerm);
  }, [searchTerm]);

  const handleSearch = (term) => {
    if (!term.trim()) {
      onSearchResult(data);
      return;
    }

    const options = {
      keys: ["name"],
      includeScore: true,
      threshold: 0.3,
    };
    console.log("data = ", data);
    const fuse = new Fuse(data, options);
    const result = fuse.search(term);
    console.log("result = ", result);
    onSearchResult(result.map((res) => res.item));
  };

  return (
    <div
      style={{
        position: "relative",
        width: "232px",
        ...style,
      }}
    >
      <input
        type='text'
        value={searchTerm}
        style={{
          width: "100%",
          height: "31px",
          borderRadius: "4px",
          border: "1px solid #D7D2E0",
          paddingLeft: "10px",
          paddingRight: "10px",
        }}
        placeholder='Search files'
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <div
        style={{
          position: "absolute",
          right: "0px",
          top: "50%",
          transform: "translateY(-50%)",
        }}
      >
        {CustomIcon}
      </div>
    </div>
  );
};

export default Search;
