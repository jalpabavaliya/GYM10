import React, { useState } from "react";
import {
  Button,
  CircularProgress,
  TextField,
  Typography,
  IconButton,
} from "@mui/material";
import "../../style.css";
import { Close as CloseIcon } from "@mui/icons-material";
import { uploadCSVpage as setPageType } from "../../GlobalStore/index";

const FirstPage = ({ onDataSelected }) => {
  const [csvFile, setCsvFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [importName, setImportName] = useState("");
  const [description, setDescription] = useState("");
  const [showWarning, setShowWarning] = useState(true);

  const handleFileDrop = (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    setCsvFile(file);
  };

  const handleFileBrowse = () => {
    const fileInput = document.getElementById("csvFileInput");
    fileInput.click();
  };

  const handleFileInputChange = (event) => {
    const file = event.target.files[0];
    setUploading(true);
    setTimeout(() => {
      setUploading(false);
    }, 1000);
    setCsvFile(file);
  };

  const handleImportNameChange = (event) => {
    setImportName(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    const inputData = {
      csvFile: csvFile,
      importName: importName,
      description: description,
    };
    onDataSelected(inputData);
    setPageType(2);
  };

  const shouldEnableButton = () => {
    return (
      importName.trim() !== "" && description.trim() !== "" && csvFile !== null
    );
  };

  return (
    <>
      <form onSubmit={handleFormSubmit} style={{ height: "auto" }}>
        <div>
          <div className="text-headings">
            <h3>Choose what to import</h3>
          </div>
          <div className="text-subheadings">
            Upload your CSV, match your data, and choose your channels
          </div>
          <div
            onDrop={handleFileDrop}
            onDragOver={(e) => e.preventDefault()}
            onClick={handleFileBrowse}
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              flexShrink: 0,
              borderRadius: "5px",
              height: "8vh",
              border: "2px dashed #B9B4C3",
              background: "#F6F5F8",
              cursor: "pointer",
              padding: "20px",
              width: "56vh",
            }}
          >
            <input
              type="file"
              id="csvFileInput"
              style={{ display: "none" }}
              onChange={handleFileInputChange}
            />
            <Typography
              variant="body2"
              color="textSecondary"
              style={{
                textAlign: "center",
                color: "#B9B4C3",
                fontFamily: "Noto Sans",
                fontSize: "14px",
                fontWeight: 500,
              }}
            >
              {csvFile || uploading
                ? ""
                : "Drag and drop your files here or browse"}
            </Typography>
            {uploading ? (
              <div style={{ textAlign: "center", marginTop: "20px" }}>
                <CircularProgress />
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    marginTop: "10px",
                    fontFamily: "Noto Sans",
                    fontSize: "12px",
                    fontWeight: 500,
                  }}
                >
                  Uploading...
                </Typography>
              </div>
            ) : (
              csvFile && (
                <Typography
                  variant="body2"
                  color="textSecondary"
                  style={{
                    marginTop: "20px",
                    fontFamily: "Noto Sans",
                    fontSize: "12px",
                    fontWeight: 500,
                    textAlign: "center",
                  }}
                >
                  {csvFile.name}
                </Typography>
              )
            )}
          </div>
        </div>

        {showWarning && (
          <div className="warning-section">
            <IconButton onClick={() => setShowWarning(false)}>
              <CloseIcon
                style={{
                  height: "80%",
                  width: "80%",
                  position: "absolute",
                  borderRadius: "100%",
                  border: "1px solid",
                }}
              />
            </IconButton>
            <Typography
              variant="body2"
              className="warning-text"
              style={{
                color: "#000",
                fontFamily: "Noto Sans",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: "500",
                lineHeight: "normal",
                marginLeft: "1vh",
              }}
            >
              Your file contains no valid contacts. Please ensure that each
              contact has an address, <br />
              country code, and a name or company name.
            </Typography>
          </div>
        )}

        <div className="text-headings">Import Name</div>
        <div>
          <TextField
            value={importName}
            onChange={handleImportNameChange}
            placeholder="File name will appear here"
            style={{
              width: "60vh",
              borderRadius: "6px",
              border: "1px solid #EBE8F1",
              background: "#FFF",
            }}
          />
        </div>
        <div className="text-headings">Description</div>
        <div>
          <TextField
            value={description}
            onChange={handleDescriptionChange}
            placeholder="Add an optional description for your import"
            multiline
            rows={4}
            style={{
              width: "60vh",
              borderRadius: "6px",
              border: "1px solid #EBE8F1",
              background: "#FFF",
            }}
          />
        </div>
        <div>
          <div
            className="text-subheadings"
            style={{ marginBottom: "4.5vh", marginTop: "2vh" }}
          >
            By proceeding, you confirm that you legally own this data and adhere
            to all applicable industry standards and <br /> regulations for its
            use.
          </div>
        </div>
        <div>
          <Button
            type="submit"
            disabled={!shouldEnableButton() || uploading}
            style={{
              color: "#FFF",
              textAlign: "center",
              fontFamily: "Noto Sans",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: 600,
              lineHeight: "normal",
              textTransform: "capitalize",
              width: "20vh",
              height: "48px",
              borderRadius: "6px",
              background: !shouldEnableButton() ? "#d3abdb" : "#852598",
            }}
          >
            Agree And Upload
          </Button>
        </div>
      </form>
    </>
  );
};

export default FirstPage;
