import React from "react";
import { Grid, Box } from "@mui/material";
import CustomButton from "../../Component/CustomButton/CustomButton";
import "./style.css";
import {
  uploadCSVpage as setPageType,
  open as setOpen,
} from "../../GlobalStore/index";

//Dummy Data

const First = {
  "Invalid Data Format": "2312",
  "Mismatched Data": "666",
  "Incompatible Characters": "56",
  "Removed from Import": "236",
};
const Second = {
  "UPB  >$20k": "28",
  "Under 60 Months": "56",
  "No AVM": "36",
  "Not Priced": "4,290",
  "Selected Dataset": "51,864",
};

const areAllFieldsSelected = () => {
  return true;
};

const CSV_NAME = "EG CSV Name";
const DESC =
  "Data related to New York Zip code 10026 of people earning over $450k and own home";

const ThirdPage = ({ onDataSelected, onClose}) => {
  const handleClickNext = () => {
    const checkboxes = document.getElementsByName("checkbox");
    const selectedValues = [];
    checkboxes.forEach((checkbox) => {
      if (checkbox.checked) {
        selectedValues.push(checkbox.value);
      }
    });
    setOpen(false);
    setPageType(1);
    onDataSelected(selectedValues);
    onClose();
  };

  const handleClickBack = () => {
    setPageType(2);
  };

  return (
    <div className="main-screen">
      <div className="text-headings" style={{ fontSize: "22px" }}>
        Finalize Data Import & Review
      </div>
      <div className="grid-content">
        <Grid
          container
          spacing={1}
          className="content"
          style={{
            marginTop: "2vh",
          }}
        >
          {Object.entries(First).map(([key, value]) => (
            <Grid item xs={12 / Object.keys(First).length}>
              <Box>
                <div className="grid-content-key" key={key}>
                  {key}
                </div>
                <br />
                <div className="grid-content-value" key={value}>
                  {value}
                </div>
              </Box>
            </Grid>
          ))}
        </Grid>
      </div>
      <div className="text-subheading">*All error data be not be imported</div>
      <hr
        style={{
          backgroundColor: "#d3abdb",
          border: "none",
          height: "1px",
          marginBottom: "2vh",
          marginTop: "2vh",
        }}
      />
      <div className="text-headings" style={{ fontSize: "22px" }}>
        Summary of Data
      </div>
      <div
        className="text-headings"
        style={{ fontSize: "18px", fontWeight: 550 }}
      >
        CSV Name
      </div>
      <div className="text-subheadings" style={{ fontSize: "14px" }}>
        {CSV_NAME}
      </div>
      <div
        className="text-headings"
        style={{ fontSize: "18px", fontWeight: 550 }}
      >
        Description
      </div>
      <div className="text-subheadings" style={{ fontSize: "14px" }}>
        {DESC}
      </div>
      <div
        className="text-headings"
        style={{ fontSize: "18px", fontWeight: 550 }}
      >
        Actionable Data Matrix
      </div>
      <div className="grid-content">
        <Grid container spacing={1} className="content">
          {Object.entries(Second).map(([key, value]) => (
            <Grid item xs={12 / Object.keys(Second).length}>
              <Box>
                <div className="grid-content-key">{key}</div>
                <br />
                <div className="grid-content-value">{value}</div>
              </Box>
            </Grid>
          ))}
        </Grid>
      </div>
      <hr
        style={{
          backgroundColor: "#d3abdb",
          border: "none",
          height: "1px",
          marginTop: "2vh",
          marginBottom: "2vh",
        }}
      />
      <div className="text-headings" style={{ fontSize: "22px" }}>
        Select Channels
      </div>
      <div
        className="text-subheadings"
        style={{ fontSize: "14px", marginTop: "1vh" }}
      >
        Select the channels compatible with your imported data type for optimum
        results
      </div>
      <div className="checkbox-container">
        <label>
          <input type="checkbox" name="checkbox" value="Direct-Mail"></input>
          <span className="checkbox-label">Direct Mail</span>
        </label>
        <label>
          <input type="checkbox" name="checkbox" value="E-mail"></input>
          <span className="checkbox-label">E-mail</span>
        </label>
        <label>
          <input type="checkbox" name="checkbox" value="Call"></input>
          <span className="checkbox-label">Call</span>
        </label>
        <label>
          <input type="checkbox" name="checkbox" value="Digital"></input>
          <span className="checkbox-label">Digital</span>
        </label>
        <label>
          <input type="checkbox" name="checkbox" value="Social Media"></input>
          <span className="checkbox-label">Social Media</span>
        </label>
      </div>
      <CustomButton
        handleClickBack={handleClickBack}
        areAllFieldsSelected={areAllFieldsSelected}
        handleClickNext={handleClickNext}
      />{" "}
    </div>
  );
};

export default ThirdPage;
