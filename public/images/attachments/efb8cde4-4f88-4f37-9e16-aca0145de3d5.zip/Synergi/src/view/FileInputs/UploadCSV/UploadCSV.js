import React, { useState } from "react";
import { useReactiveVar } from "@apollo/client";

import { Button, Dialog, DialogContent } from "@mui/material";
import "./style.css";
import Header from "./Component/CustomHeader/CustomHeader";
import FirstPage from "./Page/FirstPage/FirstPage";
import SecondPage from "./Page/SecondPage/SecondPage";
import ThirdPage from "./Page/ThirdPage/ThirdPage";
import {
  uploadCSVpage as setPageType,
  open as setOpen,
} from "./GlobalStore/index";

const PopupWindow = ({onDataSelected, onClose, value}) => {
  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);

    const CSVData = {
      firstPageData: selectedFirstPageData,
      secondPageData: selectedSecondPageData,
      thirdPageData: selectedThirdPageData,
    };
    onDataSelected(CSVData);
    onClose();
  };

  const isPageType = useReactiveVar(setPageType);
  const open = useReactiveVar(setOpen);
  const [selectedFirstPageData, setSelectedFirstPageData] = useState([]);
  const [selectedSecondPageData, setSelectedSecondPageData] = useState([]);
  const [selectedThirdPageData, setSelectedThirdPageData] = useState([]);

  const handleFirstPageDataSelected = (data) => {
    setSelectedFirstPageData(data);
  };

  const handleSecondPageDataSelected = (data) => {
    setSelectedSecondPageData(data);
  };

  const handleThirdPageDataSelected = (data) => {
    setSelectedThirdPageData(data);
  };

  let pageComponent;
  if (isPageType === 1) {
    pageComponent = <FirstPage onDataSelected={handleFirstPageDataSelected} />;
  } else if (isPageType === 2) {
    pageComponent = <SecondPage onDataSelected={handleSecondPageDataSelected}/>;
  } else if (isPageType === 3) {
    pageComponent = <ThirdPage onDataSelected={handleThirdPageDataSelected} onClose={handleClose}/>;
  }

  return (
    <>
      <Button onClick={handleOpen}>{value}</Button>
      <Dialog open={open} onClose={handleClose} maxWidth="lg">
        <DialogContent
          style={{
            display: "flex",
            flexDirection: "column",
            marginBottom: "5vh",
            marginLeft: "2vh",
            width: "90vh",
            height: "90vh",
          }}
        >
          <Header type={isPageType - 1} />
          {pageComponent}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default PopupWindow;
