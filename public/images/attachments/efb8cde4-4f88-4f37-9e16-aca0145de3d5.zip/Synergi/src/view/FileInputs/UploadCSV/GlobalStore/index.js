import { makeVar } from '@apollo/client';

export const uploadCSVpage = makeVar(1);
export const open = makeVar(false);

