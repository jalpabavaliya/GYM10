import React from "react";
import Button from "@mui/material/Button";

export default function CustomButton(props) {
  return (
    <div style={{ marginTop: "1vh" }}>
      <Button
        type="submit"
        variant="outlined"
        onClick={props.handleClickBack}
        style={{
          color: "var(--col-12, #852598)",
          textAlign: "center",
          fontFamily: "Noto Sans",
          fontSize: "16px",
          fontStyle: "normal",
          fontWeight: 600,
          lineHeight: "normal",
          textTransform: "capitalize",
          width: "20vh",
          height: "48px",
          borderRadius: "6px",
          background: "#fff",
          border: "1px solid var(--col-12, #852598)",
        }}
      >
        Back
      </Button>

      <Button
        type="submit"
        variant="contained"
        disabled={!props.areAllFieldsSelected()}
        onClick={props.handleClickNext}
        style={{
          color: "#FFF",
          textAlign: "center",
          fontFamily: "Noto Sans",
          fontSize: "16px",
          fontStyle: "normal",
          fontWeight: 600,
          lineHeight: "normal",
          textTransform: "capitalize",
          width: "20vh",
          height: "48px",
          borderRadius: "6px",
          marginLeft: "1vh",
          background: !props.areAllFieldsSelected() ? "#d3abdb" : "#852598",
        }}
      >
        Next
      </Button>
    </div>
  );
}
