import React, { useState, useEffect } from "react";
import PopupWindow from "./UploadCSV/UploadCSV";
import { Grid } from "@mui/material";

const fields = [
  "LOAN",
  "RATE SHEET",
  "PRICING",
  "LEADS",
  "APPLICATIONS",
  "EMAIL",
  "CREDIT TRIGGER",
  "PRESCREEN",
  "THIRD PARTY",
];

const FileInputs = ({ onDataSelected }) => {
  const [isPopupOpen, setPopupOpen] = useState(false);
  const [popupData, setPopupData] = useState(null);

  const handlePopupDataSelected = (data) => {
    setPopupData(data);
  };

  const handlePopupClose = () => {
    setPopupOpen(false);
  };

  return (
    <>
      {/* <Grid container spacing={2}>
        {fields.map((field) => (
          <Grid item xs={4}> */}
      <PopupWindow
        //   value={field}
        value="Upload file"
        onDataSelected={handlePopupDataSelected}
        onClose={handlePopupClose}
      />
      {/* </Grid>
        ))}
      </Grid> */}
    </>
  );
};
export default FileInputs;
