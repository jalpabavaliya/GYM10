import { Drawer, IconButton, List, ListItemButton, ListItemIcon, ListItemText } from '@mui/material'
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
import React,{useState} from 'react'
import "./mainHeader.css";
const DrawerComponent = ({links}) => {
    const [open ,setOpen]=useState(false)
  return (
    <div>
        <Drawer  open={open}  onClose={()=>setOpen(false)} > <List>
            <ListItemButton>
                <ListItemIcon>
                    <ListItemText>product</ListItemText>
                </ListItemIcon>
            </ListItemButton>
        </List>
        </Drawer>
       
        <IconButton sx={{color:"red"}} onClick={()=>setOpen(!open)}>
          <MenuRoundedIcon/>
        </IconButton>
    </div>
  )
}

export default DrawerComponent