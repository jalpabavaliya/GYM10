import {
  Box,
  Button,
  Grid,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import React from "react";
import "./mainHeader.css";
import DrawerComponent from "./DrawerComponent";
// import { useTheme } from "@emotion/react";

const MainHeader = ({ links }) => {
  const theme = useTheme();
  const isMatch = useMediaQuery(theme.breakpoints.down("sm"));
  return (
    <>
      {isMatch ? (
        <>
          <Grid container direction="row" alignItems="center">
            <Grid item xs={2}>
              <img
                // className="Headerimage"
                alt="header"
                style={{
                  marginLeft: "1.7vh",
                  height: "4.43vh",
                  width: "17.60vh",
                }}
                src="https://generation-sessions.s3.amazonaws.com/c2fdc9dc1907f3591108e718a8db0a65/img/image-255@2x.png"
              />
            </Grid>
            <Grid item xs={2} marginLeft="auto" textAlign="right">
              {" "}
              <DrawerComponent />
            </Grid>
          </Grid>
        </>
      ) : (
        <Grid
          container
          direction="row"
          className="mainHeader"
          justifyContent="flex-start"
          alignItems="center"
        >
          <Grid item xs={2}>
            <img
              // className="Headerimage"
              alt="header"
              style={{
                marginLeft: "1.7vh",
                height: "4.43vh",
                width: "17.60vh",
              }}
              src="https://generation-sessions.s3.amazonaws.com/c2fdc9dc1907f3591108e718a8db0a65/img/image-255@2x.png"
            />
          </Grid>

          <Grid item container xs={8}>
            <Grid item sx={{ px: "20px" }}>
              <Typography variant="body">The Platform</Typography>
            </Grid>
            <Grid item sx={{ px: "20px" }}>
              <Typography variant="body">Transformative Results</Typography>
            </Grid>
            <Grid item sx={{ px: "20px" }}>
              <Typography variant="body">Who We Empower</Typography>
            </Grid>
            <Grid item sx={{ px: "20px" }}>
              <Typography variant="body">About</Typography>
            </Grid>
          </Grid>
          <Grid item xs={2}>
            <Button variant="contained" color="secondary" size="small">
              Request a Demo
            </Button>
          </Grid>
        </Grid>
      )}
    </>
  );
};

export default MainHeader;
