import React, { useState, useEffect } from "react";
import {
  CognitoUser,
  CognitoUserPool,
  AuthenticationDetails,
} from "amazon-cognito-identity-js";
import * as Yup from "yup";
import { useFormik } from "formik";
import {
  Button,
  Grid,
  TextField,
  Typography,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import { useNavigate } from "react-router-dom";
import Registration from "../register/Registration";

const validationSchema = Yup.object({
  email: Yup.string()
    .required("Email is required!")
    .matches(
      /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
      "Invalid email address"
    ),
  password: Yup.string().required("Password is required!"), // add this line
});

const poolData = {
  UserPoolId: "us-east-1_lSBztqHit", // Your user pool id here
  ClientId: "3bcfutrtvoh4fn838l4a6qfl6v", // Your client id here
};

const userPool = new CognitoUserPool(poolData);

const Login = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    enableReinitialize: true,
    validationSchema,
    onSubmit: (values, { setSubmitting }) => {
      const authenticationDetails = new AuthenticationDetails({
        Username: values.email,
        Password: values.password,
      });

      const cognitoUser = new CognitoUser({
        Username: values.email,
        Pool: userPool,
      });

      cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result) {
          // navigate to another page, if needed
          // window.alert("Login successfully...");
          const accessToken = result.getAccessToken().getJwtToken();
          localStorage.setItem("accessToken", accessToken);

          navigate("/OnBoarding");
        },
        onFailure: function (err) {
          console.error(err);
          alert("Login failed. Please check your username and password.");
        },
      });

      setSubmitting(false);
    },
  });

  const handleForgetPassword = () => {
    navigate("/password-recovery");
  };

  const handleChange = () => {
    navigate("/registration");
  };

  return (
    <>
      {showRegister && (
        <Registration open={showRegister} close={setShowRegister(false)} />
      )}
      <Grid
        container
        spacing={2}
        sx={{
          pt: { xs: "10%", sm: "4%", md: "4%" },
          pl: "10%",
          pb: "3%",
        }}
      >
        <Card>
          <CardContent>
            <Grid
              container
              direction="column"
              spacing={2}
              justifyContent="flex-start"
              alignItems="center"
              sx={{
                pr: { lg: 10, md: 8, sm: 6, xs: 4 },
                pl: { lg: 10, md: 8, sm: 6, xs: 4 },
              }}
            >
              <Grid item xs={12} sx={{ mt: "10%" }}>
                <Typography
                  variant="h5"
                  color="secondary"
                  sx={{ fontSize: { lg: 18, sm: 15, xs: 14 } }}
                >
                  Welcome Back!
                </Typography>
              </Grid>
              <Grid 
              item 
              xs={12}
                sx={{ mb: "5%" }}
                style={{ paddingTop: "5px" }}>
                <Typography
                  variant="h4"
                  sx={{
                    fontSize: { lg: 30, md: 25, sm: 20, xs: 18 },
                    fontFamily: "IBM Plex Serif",
                    fontStyle: "normal",
                    fontWeight: "400",
                    lineHeight: "normal",
                    textTransform: "capitalize",
                    color: "#132529",
                  }}
                >
                  Enter Your Account
                </Typography>
                <Typography
                  align="center"
                  variant="h4"
                 sx={{
                    fontSize: { lg: 30, md: 25, sm: 20, xs: 18 },
                    fontFamily: "IBM Plex Serif",
                    fontStyle: "normal",
                    fontWeight: "400",
                    lineHeight: "normal",
                    textTransform: "capitalize",
                    color: "#132529",
                  }}
                >
                  Details To Start.
                </Typography>
              </Grid>

              <form onSubmit={formik.handleSubmit}>
                <Grid
                  container
                  direction="column"
                  justifyContent="flex-start"
                  alignItems="center"
                >
                  <Grid item xs={12} sx={{ m: "3%" }}>
                    <TextField
                      id="email"
                      type="text"
                      fullWidth
                      size="medium"
                      sx={{
                        paddingRight: { xs: "30px", md: "0px" },
                        width: {
                          xs: "100%",
                          sm: "100%",
                          md: "45vh",
                          lg: "45vh",
                        }, // Adjust width for md and lg
                      }}
                      placeholder="Email"
                      {...formik.getFieldProps("email")}
                      error={
                        formik.touched.email && Boolean(formik.errors.email)
                      }
                      helperText={formik.touched.email && formik.errors.email}
                    />
                  </Grid>
                  <Grid item xs={12} sx={{ m: "3%" }}>
                    <TextField
                      id="password"
                      type={showPassword ? "text" : "password"}
                      fullWidth
                      size="medium"
                      sx={{
                        width: {
                          xs: "100%",
                          sm: "100%",
                          md: "45vh",
                          lg: "45vh",
                        }, // Adjust width for md and lg
                      }}
                      placeholder="Password"
                      {...formik.getFieldProps("password")}
                      error={
                        formik.touched.password &&
                        Boolean(formik.errors.password)
                      }
                      helperText={
                        formik.touched.password && formik.errors.password
                      }
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              aria-label="toggle password visibility"
                              onClick={handleClickShowPassword}
                              edge="end"
                            >
                              {showPassword ? (
                                <VisibilityIcon />
                              ) : (
                                <VisibilityOffIcon />
                              )}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  <Grid
                    item
                    xs={12}
                    sx={{ fontSize: { xs: 12, sm: 14, md: 14, lg: 16 } }}
                  >
                    <a
                      href=""
                      onClick={handleForgetPassword}
                      sx={{ fontSize: { xs: 12, sm: 14, md: 14, lg: 14 } }}
                    >
                      Forgot Password?
                    </a>
                  </Grid>
                  <Grid item sx={{ mt: { xs: "2%", sm: "3%", lg: "4%" } }}>
                    <Button
                      variant="contained"
                      color="secondary"
                      type="submit"
                      fullWidth
                      sx={{ width: { lg: "45vh", md: "25vh" } }}
                    >
                      LOGIN
                    </Button>
                  </Grid>
                  <Grid item xs={12} sx={{ mt: "3%", mb: "117px" }}>
                    <Typography
                      sx={{ fontSize: { xs: 12, sm: 14, md: 14, lg: 14 } }}
                    >
                      Don't have an account?&nbsp;
                      <a href="" onClick={handleChange}>
                        Register
                      </a>
                    </Typography>
                  </Grid>
                </Grid>
              </form>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
    </>
  );
};

export default Login; 