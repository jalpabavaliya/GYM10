import React, { useEffect } from "react";
import { Button, Grid, TextField, Typography, useTheme } from "@mui/material";
import * as Yup from "yup";
import { useFormik } from "formik";
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';
import { CognitoUser, CognitoUserPool } from "amazon-cognito-identity-js";
import { forgetEmail } from "../../store/actions/login-actions";
import { useDispatch } from "react-redux";


const poolData = {
  UserPoolId: "us-east-1_lSBztqHit", // Your user pool id here
  ClientId: "3bcfutrtvoh4fn838l4a6qfl6v", // Your client id here
};

const userPool = new CognitoUserPool(poolData);

const validationSchema = Yup.object({
  email: Yup.string()
    .required("Email is required!")
    .matches(
      /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
      "Invalid email address"
    ),
});

const PasswordRecoveryStep1 = ({ handleNext, handleBack }) => {
  const dispatch = useDispatch();

  useEffect(
    // setting initial state
    () => () => {
      formik.resetForm({
        email: "",
      });
    },
    []
  );

  const handleBackToLogin = () => {
    handleBack();
  }

  const formik = useFormik({
    initialValues: {
      email: "",
    },
    enableReinitialize: true,
    validationSchema,
    onSubmit: (values) => {
      var userData = {
        Username: values.email,
        Pool: userPool,
      };
      var cognitoUser = new CognitoUser(userData);
      cognitoUser.forgotPassword({
        onSuccess: function (result) {
          dispatch(forgetEmail(values.email));
          handleNext();
        },
        onFailure: function (err) {
          console.log(err);
        },
      });
    },
  });
  
  return (
    <Grid container justifyContent="center" textAlign="center" spacing={1}>
      <Button sx={{ mr: "90%" }}>
        <ChevronLeftRoundedIcon onClick={handleBackToLogin}/>
      </Button>
      <Grid item xs={12}>
        <Typography color="secondary" variant="h6">
          Password recovery.
        </Typography>
      </Grid>
      <Grid item xs={12} >
        <Typography variant="h4" sx={{ fontSize: { lg: 30, md: 20, sm: 20, xs: 20 } }}>Enter your email to</Typography>
        <Typography variant="h4" sx={{ fontSize: { lg: 30, md: 20, sm: 20, xs: 20 } }}>recover your password.</Typography>
      </Grid>
      <Grid item xs={12}>
        <Typography variant="body2">
          Recovery instructions will be sent to your registered email.
        </Typography>
      </Grid>
      <form onSubmit={formik.handleSubmit}>
        <Grid item xs={12} sx={{ mt: 5 }}>
          <TextField
            id="email"
            required
            label="Email"
            type="text"
            size="medium"
           
            sx={{
                        paddingRight:{xs:"30px",md:"0px"},
                        width: { xs: "100%" ,sm:"100%", md: "350px", lg: "350px" }, // Adjust width for md and lg
                      }}
            {...formik.getFieldProps("email")}
            onChange={formik.handleChange}
            error={formik.touched.email && Boolean(formik.errors.email)}
            helperText={formik.touched.email && formik.errors.email}
          />
        </Grid>
        <Grid item sx={{ mt: 3, mb: 25 }}>
          <Button
            variant="contained"
            onClick={formik.handleSubmit}
            size="medium"
            fullWidth
            color="secondary"
          >
            Send
          </Button>
        </Grid>
      </form>
    </Grid>
  );
};

export default PasswordRecoveryStep1;
