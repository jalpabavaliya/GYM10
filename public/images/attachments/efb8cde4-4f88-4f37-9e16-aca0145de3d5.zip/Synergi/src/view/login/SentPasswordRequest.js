import React from "react";
import { Button, Divider, Grid, TextField, Typography } from "@mui/material";
import RequestSent from '../../assets/RequestSent.jpg'
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';

const SentPasswordRequest = ({ handleNext, handleBack }) => {
  return (
    <Grid container justifyContent="center" alignItems="center" spacing={1}>
      <Grid item xs={12} sx={{ mt: 10 }}>
        <CheckCircleOutlineIcon sx={{ width: "25%", height: "25%" }}/>
      </Grid>
      <Grid item xs={12}>
        <Typography variant="h4">Your request has been sent to</Typography>
        <Typography variant="h4">useremail@dummy.com</Typography>
      </Grid>
      <Grid item xs={12}></Grid>
      <Grid item sx={{ mt: "20px", mb: 10 }}>
        <Button
          variant="contained"
          size="medium"
          fullWidth
          onClick={() => handleNext()}
        >
          TRY SIGNING IN AGAIN
        </Button>
      </Grid>
    </Grid>
  );
};

export default SentPasswordRequest;
