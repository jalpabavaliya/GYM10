// import React, { useEffect, useState } from "react";
// import { Button, Divider, Grid, IconButton, InputAdornment, TextField, Typography } from "@mui/material";
// import * as Yup from "yup";
// import { useFormik } from "formik";
// import VisibilityIcon from "@mui/icons-material/Visibility";
// import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";

// const validationSchema = Yup.object({
//   password: Yup.string().required("Password is required!"),
//   confirmPassword: Yup.string().required("Confirm Password is required!")
// });

// const CreateNewPasswordForm = ({ handleNext, handleBack }) => {
//   const [showPassword, setShowPassword] = useState(false);
//   const [showConfirmPassword, setShowConfirmPassword] = useState(false);

//   useEffect(
//     // setting initial state
//     () => () => {
//       // eslint-disable-next-line no-use-before-define
//       formik.resetForm({
//         password: "",
//         confirmPassword: "",
//       });
//     },
//     []
//   );

//   const formik = useFormik({
//     initialValues: {
//       password: "",
//       confirmPassword: "",
//     },
//     enableReinitialize: true,
//     validationSchema,
//     onSubmit: async (values) => {
//       handleNext();
//     },
//   });

//   const handleClickShowPassword = () => setShowPassword((show) => !show);
//   const handleClickShowConfirmPassword = () => setShowConfirmPassword((show) => !show);

//   return (
//     <Grid container justifyContent="center" alignItems="center" spacing={1}>
//       <Grid item xs={12}>
//         <Typography variant="h4">Create a new password</Typography>
//         <Typography variant="h4">to login to SYNERGI</Typography>
//       </Grid>
//       <form onSubmit={formik.handleSubmit}>
//         <Grid item xs={12} sx={{ mt: 5 }}>
//           <TextField
//             id="enter-new-password"
//             required
//             label="Enter New Password"
//             type={showPassword ? "text" : "password"}
//             size="medium"
//             sx={{ width: "350px" }}
//             InputProps={{
//               endAdornment: (
//                 <InputAdornment position="end">
//                   <IconButton
//                     aria-label="toggle password visibility"
//                     onClick={handleClickShowPassword}
//                     edge="end"
//                   >
//                     {showPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
//                   </IconButton>
//                 </InputAdornment>
//               ),
//             }}
//             {...formik.getFieldProps("password")}
//             onChange={formik.handleChange}
//             error={formik.touched.password && Boolean(formik.errors.password)}
//             helperText={formik.touched.password && formik.errors.password}
//           />
//         </Grid>
//         <Grid item xs={12} sx={{ mt: 2 }}>
//           <TextField
//             id="confiem-new-password"
//             required
//             label="Confirm New Password"
//             type={showConfirmPassword ? "text" : "password"}
//             size="medium"
//             sx={{ width: "350px" }}
//             InputProps={{
//               endAdornment: (
//                 <InputAdornment position="end">
//                   <IconButton
//                     aria-label="toggle confirm password visibility"
//                     onClick={handleClickShowConfirmPassword}
//                     edge="end"
//                   >
//                     {showConfirmPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
//                   </IconButton>
//                 </InputAdornment>
//               ),
//             }}
//             {...formik.getFieldProps("confirmPassword")}
//             onChange={formik.handleChange}
//             error={formik.touched.confirmPassword && Boolean(formik.errors.confirmPassword)}
//             helperText={formik.touched.confirmPassword && formik.errors.confirmPassword}
//           />
//         </Grid>
//         <Grid item sx={{ mt: 5, mb: 20 }}>
//           <Button
//             variant="contained"
//             onClick={formik.handleSubmit}
//             size="medium"
//             fullWidth
//           >
//             UPDATE PASSWORD
//           </Button>
//         </Grid>
//       </form>
//     </Grid>
//   );
// };

// export default CreateNewPasswordForm;
