import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  Typography,
} from "@mui/material";
import React from "react";
import "../../setting.css";
function Security() {
  return (
    <div>
      <Typography
        style={{
          color: "#414446",
          fontFamily: "IBM Plex Serif",
          fontSize: "24px",
          fontStyle: "normal",
          fontWeight: "400",
          lineHeight: "normal",
          textTransform: "capitalize",
          paddingBottom:"12px",
          marginTop:"25px",
        }}
      >
        Account Security
      </Typography>
      <Box
        component="div"
        style={{
          borderRadius: "5px",
          border: "1px solid #EBE8F1",
          background: "#FFFFFF",
          padding: "20px 26px",
          width: "679px",
          marginBottom: "20px",
        }}
      >
        <Typography
          variant="h3"
          style={{
            color: "#000",
            fontFamily: "Roboto,sans-serif",
            fontSize: "18px",
            fontStyle: "normal",
            fontWeight: "600",
            lineHeight: "normal",
            textTransform: "capitalize",
          }}
        >
          Set up 2-Factor Authentication
        </Typography>
        <Typography
          variant="body1"
          style={{
            width: "544px",
            color: "#414446",
            fontFamily: "Roboto,sans-serif",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: "400",
            lineHeight: "21.166px",
            textTransform: "capitalize",
            padding: "18px 0px 21px 0px",
          }}
        >
          Enable 2-factor authentication as a second layer of security for your
          account. If an account owner or admin enables 2-factor authentication,
          all users will be reqired to set it up using their preferred method.
          Once enabled, it cannot be disabled.
        </Typography>
        <FormControl>
          <RadioGroup
            name="radio-buttons-group"
            defaultValue="Authenticator app (Recommended)"
            style={{ display: "flex" }}
          >
            <FormControlLabel
              control={<Radio />}
              label="Authenticator app (Recommended)"
              value="Authenticator app (Recommended)"
              style={{ fontSize: "14px" }}
            />
            <Typography sx={{ paddingLeft: "30px", fontSize: "12px" }}>
              Examples: Google Authenticator, IOS authenticator, etc.
            </Typography>

            <FormControlLabel
              control={<Radio />}
              label="SMS"
              value="SMS"
              style={{ marginTop: "20px" }}
            />
            <Typography sx={{ paddingLeft: "30px", fontSize: "12px" }}>
              Examples: Google Authenticator, IOS authenticator, etc.
            </Typography>
          </RadioGroup>
        </FormControl>
        <Button
          variant="contained"
          color="secondary"
          type="submit"
          fullWidth
          sx={{
            width: {
              lg: "146px",
              fontSize: "16px",
              textTransform: "capitalize",
              marginTop: "45px",
              marginBottom: "30px",
              display: "block",
            },
          }}
        >
          Next
        </Button>
      </Box>

      <Box
        component="div"
        style={{
          borderRadius: "5px",
          border: "1px solid #EBE8F1",
          background: "#F6F5F8",
          padding: "20px 26px",
          width: "679px",
        }}
      >
        <Typography
          variant="h3"
          style={{
            color: "#000",
            fontFamily: "Roboto,sans-serif",
            fontSize: "18px",
            fontStyle: "normal",
            fontWeight: "600",
            lineHeight: "normal",
            textTransform: "capitalize",
          }}
        >
          Account Verification
        </Typography>
        <Typography
          variant="body1"
          style={{
            color: "#414446",
            fontFamily: "Roboto,sans-serif",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: "400",
            lineHeight: "21.166px",
            textTransform: "capitalize",
            padding: "24px 0px 21px 0px",
          }}
        >
          We’ll use this to confirm your identity if we spot any unusal activity
          on your account.
        </Typography>

        <Typography
          variant="body2"
          style={{
            color: "#414446",
            fontFamily: "Roboto,sans-serif",
            fontSize: "16px",
            fontStyle: "normal",
            fontWeight: "400",
            textTransform: "capitalize",
          }}
        >
          You’re verified with phone number{" "}
          <span style={{ color: "#000000", fontWeight: "700" }}>
            917-805-6232.
          </span>
        </Typography>
      </Box>
    </div>
  );
}

export default Security;
