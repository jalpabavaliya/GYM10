import { Typography } from "@mui/material";
import React from "react";
import BillingInfo from "./BillingInfo";
import AccountContact from "./AccountContact";
function CompanyDetail() {
  return (
    <div>
    <section>
    <Typography
        style={{
          color: "#414446",
          fontFamily: "IBM Plex Serif",
          fontSize: "24px",
          fontStyle: "normal",
          fontWeight: "400",
          lineHeight: "normal",
          textTransform: "capitalize",
          paddingBottom: "12px",
          marginTop: "25px",
        }}
      >
        Primary Account Contact
      </Typography>
      <Typography
        sx={{
          color: "#414446",
          fontFamily: "Roboto",
          fontSize: "14px",
          fontStyle: "normal",
          fontWeight: "400",
          lineHeight: "normal",
          marginBottom:"25px"
        }}
      >
        Information about this account, such as campaign send notifications,
        will be sent to the email address listed here.
      </Typography>
     <AccountContact />
    </section>
    <section>
    <Typography
        style={{
          color: "#414446",
          fontFamily: "IBM Plex Serif",
          fontSize: "24px",
          fontStyle: "normal",
          fontWeight: "400",
          lineHeight: "normal",
          textTransform: "capitalize",
          paddingBottom: "12px",
          marginTop: "25px",
        }}
      >
      Billing Info
      </Typography>
      <Typography
        sx={{
          color: "#414446",
          fontFamily: "Roboto",
          fontSize: "14px",
          fontStyle: "normal",
          fontWeight: "400",
          lineHeight: "normal",
          marginBottom:"25px"
        }}
      >
        This is the information we have associated with your payment method.
      </Typography>
     <BillingInfo/>
    </section>
    </div>
  );
}

export default CompanyDetail;
