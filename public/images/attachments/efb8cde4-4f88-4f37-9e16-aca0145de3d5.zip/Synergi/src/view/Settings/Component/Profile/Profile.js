import { Box, Button, Grid, TextField, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import admin from "./asset/admin.png";
import axios from "axios";
import { useParams } from "react-router-dom";

function Profile() {
  const { id } = useParams();
  let accessToken = localStorage.getItem("accessToken");

  const inputRef = useRef(null);
  const [image, setImage] = useState("");

  const handleImageClick = () => {
    inputRef.current.click();
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    console.log(file);
    setImage(event.target.files[0]);
  };

  const [value, setValue] = useState({
    id: id,
    company_name: "",
    mobile: "",
    first_name: "",
    last_name: "",
    email: "",
    designation: "",
  });

  useEffect(() => {
    const headers = { Authorization: `Bearer ${accessToken}` };
    axios
      .get(
        "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/settings_basic_profile",
        { headers }
      )
      .then((res) => {
        setValue({
          ...value,
          email: res.data.email,
          designation: res.data.designation,
          first_name: res.data.first_name,
          last_name: res.data.last_name,
          mobile: res.data.mobile,
          company_name: res.data.company_name,
        });
        console.log(res);
      });
  },  []);


  const handleUpdatedDataSubmit = (e) => {
    const headers = { Authorization: `Bearer ${accessToken}` };
    e.preventDefault();
    axios
      .post(
        "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/setting_profile_post_setting_information",
        value,
        { headers }
      )
      .then((response) => {
       
        console.log(response);
      });
  };

  return (
    <div>
      <Typography
        style={{
          color: "#414446",
          fontFamily: "IBM Plex Serif",
          fontSize: "24px",
          fontStyle: "normal",
          fontWeight: "400",
          lineHeight: "normal",
          textTransform: "capitalize",
          paddingBottom: "12px",
          marginTop: "25px",
        }}
      >
        Profile Photo
      </Typography>
      <Grid container>
        <Grid item sx={2}>
          <Box>
            {image ? (
              <img
                src={URL.createObjectURL(image)}
                alt=""
                style={{
                  borderRadius: "50%",
                  width: "107px",
                  height: "107px",
                  objectFit: "cover",
                }}
              />
            ) : (
              <img src={admin} alt="" style={{ borderRadius: "50%" }} />
            )}
            <input
              type="file"
              ref={inputRef}
              style={{ display: "none" }}
              onChange={handleImageChange}
            />
          </Box>
        </Grid>
        <Grid item sx={10} style={{paddingLeft:'24px',display:"flex",flexDirection:"column",justifyContent:"center"}}>
          <Typography style={{paddingBottom:'10px'}}>Upload your photo...</Typography>
          <Typography style={{paddingBottom:'10px'}}>Photo should be at least 300px x 300px</Typography>
          <Button
            variant="contained"
            color="secondary"
            type="submit"
            fullWidth
            sx={{
              width: {
                lg: "146px",
                fontSize: "16px",
                textTransform: "capitalize",
              },
            }}
            onClick={handleImageClick}
          >
            Upload Photo
          </Button>
        </Grid>
      </Grid>

      <Grid container>
        <Grid item xs={12}>
          <Typography
            style={{
              color: "#414446",
              fontFamily: "IBM Plex Serif",
              fontSize: "24px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              paddingBottom: "12px",
              marginTop: "25px",
            }}
          >
            Basic Information
          </Typography>
        </Grid>
        <Grid xs={10} item>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
          >
            Username
          </Typography>
          <TextField
            id="email"
     
            fullWidth
            size="medium"
            placeholder="Email"
            value={value.email}
            // onChange={(e) => setValue({ ...value, email: e.target.value })}
          />
        </Grid>
        <Grid xs={10} item>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
          >
            First name
          </Typography>
         

          <TextField
            type="text"
            fullWidth
            size="medium"
            placeholder="First name"
            value={value.first_name}
            onChange={(e) => setValue({ ...value, first_name: e.target.value })}
          />
        </Grid>
        <Grid xs={10} item>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
           
          >
            Last name
          </Typography>
          
          <TextField
            type="text"
            fullWidth
            size="medium"
            placeholder="   Last name"
            value={value.last_name}
            onChange={(e) => setValue({ ...value, last_name: e.target.value })}
          />
        </Grid>{" "}
        <Grid xs={10} item>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
           
          >
            Email address
          </Typography>
          
          <TextField type="email" fullWidth size="medium" placeholder="Email"  value={value.email}  
          //  onChange={(e) => setValue({ ...value, email: e.target.value })}

           />
        </Grid>
        <Grid xs={10} item>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
           
          >
            Company name
          </Typography>
          <TextField
            type="text"
            fullWidth
            size="medium"
            placeholder="Company name"
            value={value.company_name}
            //  onChange={(e) =>
            //   setValue({ ...value, company_name: e.target.value })
            // }
          />
          
        </Grid>{" "}
        <Grid xs={10} item>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}

          >
            Designation
          </Typography>
          
          <TextField
            type="text"
            fullWidth
            size="medium"
            placeholder="Designation"
            value={value.designation}
            onChange={(e) =>
              setValue({ ...value, designation: e.target.value })
            }
          />
        </Grid>{" "}
        <Grid xs={10} item>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
           
          >
            Mobile
          </Typography>
       
          <TextField type="text" fullWidth size="medium" placeholder="Mobile"  value={value.mobile}   onChange={(e) => setValue({ ...value, mobile: e.target.value })}/>
        </Grid>
        <Grid xs={12} item style={{ paddingTop: "25px" }}>
            
              <Button
                type="submit"
                variant="contained"
                onClick={handleUpdatedDataSubmit}
                color="secondary"
                fullWidth
                sx={{
                  width: {
                    lg: "118px",
                    fontSize: "16px",
                    textTransform: "capitalize",
                  },
                }}
              >
                update
              </Button>
            </Grid>
      </Grid>
    </div>
  );
}

export default Profile;
