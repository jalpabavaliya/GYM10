import React, { useEffect, useState } from "react";
import {
  Table,
  CircularProgress,
  TableCell,
  TableContainer,
  TableRow,
  Typography,
  TableBody,
  Button,
} from "@mui/material";
import axios from "axios";
import Modal from "./Component/BillingModal";

function BillingInfo() {
  let accessToken = localStorage.getItem("accessToken");

  const [data, setdata] = useState(null);
  const [showModal , setShowModal]=useState(false);

  const closeModal = () => setShowModal(false);
 
  useEffect(() => {
    const headers = { Authorization: `Bearer ${accessToken}` };
    axios
      .get(
        " https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/settings_get_company_details",
        { headers }
      )
      .then((response) => {
        console.log(response);
        console.log("Access Token", JSON.stringify(accessToken));
        setdata(response.data);
      });
  }, []);

  return (
    <div>
      {data ? (
        <TableContainer>
          <Table sx={{ width: "650px",marginBottom:"25px" }} size="small">
            <TableBody sx={{ borderTop: "1px solid rgba(224, 224, 224, 1)" }}>
              <TableRow>
                <TableCell>Contact name</TableCell>
                <TableCell>
                  {data.billing_info.first_name} {data.billing_info.last_name}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Company / Organization</TableCell>
                <TableCell>
                  <Typography>{data.billing_info.company}</Typography>
                  <Typography>{data.billing_info.website_url}</Typography>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Address</TableCell>
                <TableCell>
                  <Typography>{data.billing_info.contact_address}</Typography>
                  <Typography>
                    {data.billing_info.contact_city},
                    {data.billing_info.contact_zip_code}
                  </Typography>
                  <Typography>{data.billing_info.contact_country}</Typography>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Phone</TableCell>
                <TableCell>
                  <Typography>{data.billing_info.office_phone}</Typography>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Email</TableCell>
                <TableCell>
                  <Typography>{data.billing_info.email_id_at_work}</Typography>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
          <Button
            type="submit"
            fullWidth
            onClick={()=>setShowModal(true)}
            sx={{
              width: "204px",
              fontSize: "14px",
              textTransform: "capitalize",
              marginRight: "22px",
              backgroundColor: "transparent",
              border: "1px solid #9C27B5",
              color: "#9C27B5",
            }}
          >
            Edit Billing Information
          </Button>  
          {showModal && <Modal closeModal={closeModal}/>}
        </TableContainer>
      ) : (
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: "32px",
          }}
        >
          <CircularProgress color="secondary" />
        </div>
      )}
    </div>
  );
}

export default BillingInfo;
