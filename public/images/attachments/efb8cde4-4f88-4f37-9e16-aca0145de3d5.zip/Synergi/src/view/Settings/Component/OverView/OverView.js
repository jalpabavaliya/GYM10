import {
  Box,
  Button,
  FormControl,
  Grid,
  MenuItem,
  Select,
  Typography,
} from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";

function OverView() {
  const [selectedIndustry, setSelectedIndustry] = useState("");
  const [selectedOrganizationAge, setSelectedOrganizationAge] = useState("");
  const [selectedTotalPeople, setSelectedTotalPeople] = useState("");
  const [responseData, setResponseData] = useState(null);
  
  let accessToken = localStorage.getItem("accessToken");

  useEffect(() => {
    const headers = { Authorization: `Bearer ${accessToken}` };
    axios
      .get(
        "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/settings_overview",
        { headers }
      )
      .then((response) => {
        const settings = response.data.settings_overview;
        setSelectedIndustry(settings.your_industry);
        setSelectedOrganizationAge(settings.organization_age);
        setSelectedTotalPeople(settings.total_people);
      })
      .catch((error) => {
        console.error("Error fetching options: " + error);
      });
  }, []);

  const handleIndustryChange = (event) => {
    setSelectedIndustry(event.target.value);
  };

  const handleOrganizationAgeChange = (event) => {
    setSelectedOrganizationAge(event.target.value);
  };

  const handleTotalPeopleChange = (event) => {
    setSelectedTotalPeople(event.target.value);
  };

  const handlePostRequest = () => {
    const headers = { Authorization: `Bearer ${accessToken}` };
    const apiUrl =
      "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/settings_overview";
    const jsonPayload = {
      pk: "settings",
      sk: "overview",
      your_industry: selectedIndustry,
      organization_age: selectedOrganizationAge,
      total_people: selectedTotalPeople,
    };

    axios
      .post(apiUrl, jsonPayload, { headers })
      .then((response) => {
        setResponseData(response.data);
      })
      .catch((error) => {
        console.error("Error posting data: " + error);
      });
  };
  return (
    <div>
      <Box
        component="div"
        style={{
          borderRadius: "5px",
          border: "1px solid #EBE8F1",
          background: "#F6F5F8",
          padding: "30px 26px",
          width: "679px",
        }}
      >
        <Typography
          variant="h3"
          style={{
            color: "#000",
            fontFamily: "Roboto,sans-serif",
            fontSize: "18px",
            fontStyle: "normal",
            fontWeight: "600",
            lineHeight: "normal",
            textTransform: "capitalize",
          }}
        >
          Enterprise Plan
        </Typography>
        <Typography
          variant="body1"
          style={{
            color: "#414446",
            fontFamily: "Roboto,sans-serif",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: "400",
            lineHeight: "21.166px",
            textTransform: "capitalize",
            padding: "18px 0px 29px 0px",
          }}
        >
          The Enterprise Plan is designed to meet the complex needs of larger
          organizations, offering unparalleled control, customization, and
          insights.
        </Typography>
        <Typography
          variant="h5"
          style={{
            color: "#414446",
            fontFamily: "Roboto,sans-serif",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: "700",
            lineHeight: "21.166px",
            textTransform: "capitalize",
          }}
        >
          About your company
        </Typography>
        <Typography
          variant="body2"
          style={{
            color: "#414446",
            fontFamily: "Roboto,sans-serif",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: "400",
            lineHeight: "21.166px",
            textTransform: "capitalize",
          }}
        >
          UMortgage
          <br />
          100 N 18th St STE 1400, Philadelphia, PA 19103
          <br />
          Primary Contact: Joe Mathew
        </Typography>
      </Box>
      <Grid container style={{ marginLeft: "24px" }}>
        <Typography
          variant="h3"
          style={{
            color: "#000",
            fontFamily: "Roboto,sans-serif",
            fontSize: "18px",
            fontStyle: "normal",
            fontWeight: "600",
            lineHeight: "normal",
            textTransform: "capitalize",
            marginTop: "38px",
          }}
        >
          Help us improve your stats
        </Typography>

        <Grid item sx={12} lg={12}>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
          >
            Your Industry :
          </Typography>
          <FormControl sx={{ minWidth: 318 }}>
            <Select value={selectedIndustry} onChange={handleIndustryChange}>
              <MenuItem value="0-1 years">0-1 years</MenuItem>
              <MenuItem value="1-2 years">1-2 years</MenuItem>
              <MenuItem value="3-5 years">3-5 years</MenuItem>
              <MenuItem value="6-10 years">6-10 years</MenuItem>
              <MenuItem value="11+ years">11+ years</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item sx={12} lg={12}>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
          >
            How many people are in your organization ?
          </Typography>
          <FormControl sx={{ minWidth: 318 }}>
            <Select
              value={selectedTotalPeople}
              onChange={handleTotalPeopleChange}
            >
              
              <MenuItem value="0-50">0-50</MenuItem>
              <MenuItem value="51-100">51-100</MenuItem>
              <MenuItem value="101-200">101-200</MenuItem>
              <MenuItem value="201+">201+</MenuItem>
            </Select>
          </FormControl>

        </Grid>
        <Grid item sx={12} lg={12}>
          <Typography
            variant="h3"
            style={{
              color: "#000",
              fontFamily: "Roboto,sans-serif",
              fontSize: "14px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
              textTransform: "capitalize",
              marginTop: "22px",
              marginBottom: "9px",
            }}
          >
            How old is your organization ?
          </Typography>
          <FormControl sx={{ minWidth: 318 }}>
            <Select
              value={selectedOrganizationAge}
              onChange={handleOrganizationAgeChange}
            >
              <MenuItem value="0-1 years">0-1 years</MenuItem>
              <MenuItem value="1-2 years">1-2 years</MenuItem>
              <MenuItem value="3-5 years">3-5 years</MenuItem>
              <MenuItem value="6-10 years">6-10 years</MenuItem>
              <MenuItem value="11+ years">11+ years</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Button
          variant="contained"
          color="secondary"
          type="submit"
          onClick={handlePostRequest}
          fullWidth
          sx={{
            width: {
              lg: "146px",
              fontSize: "16px",
              textTransform: "capitalize",
              marginTop: "45px",
              marginBottom: "30px",
            },
          }}
        >
          Save
        </Button>
      </Grid>
    </div>
  );
}

export default OverView;
