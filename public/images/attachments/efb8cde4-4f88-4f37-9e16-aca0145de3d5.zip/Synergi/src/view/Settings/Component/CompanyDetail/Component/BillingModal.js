import { Button, Card, Checkbox, FormControlLabel, Grid, TextField, Typography, styled } from "@mui/material";
import React, { useState } from "react";
import CloseIcon from "@mui/icons-material/Close";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const BillingModal = ({ closeModal }) => {
  const StyledCheckbox = styled(Checkbox)(`
  color: #A35BB1;

  &.Mui-checked {
    color: #A35BB1;
  }
`);
  const data = {
    first_name: "",
    last_name: "",
    company: "",
    website_url: "",
    office_phone: "",
    contact_address: "",
    contact_address_2: "",
    email_id_at_work: "",
    contact_country: "",
    contact_city: "",
    contact_zip_code: "",
    contact_state: "",
  };
  const navigate = useNavigate();
  const [inputData, setInputData] = useState(data);
  let accessToken = localStorage.getItem("accessToken");

  const handleData = (e) => {
    setInputData({ ...inputData, [e.target.name]: e.target.value });
  };

  const handleDataSubmit = (e) => {
    const headers = { Authorization: `Bearer ${accessToken}` };
    e.preventDefault();
    axios
      .post(
        "https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/settings_post_billing_information",
        inputData,
        { headers }
      )
      .then((response) => {
        navigate("/Setting");
        console.log(response);
      });
  };
  return (
    <>
      <div className="wrapper"></div>
      <Card
        sx={{ my: 5, borderRadius: 2, padding: "6px" }}
        style={{
          width: "834px",
          position: "absolute",
          left: "299px",
          top: "10px",
          zIndex: "99",
          padding: "14px 34px 69px 49px",
        }}
      >
        <Grid container>
          <Grid
            xs={12}
            onClick={closeModal}
            sx={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "18px",
              borderBottom: "1px solid #D9D6E3",
            }}
          >
            <Typography
              style={{
                color: "#414446",
                fontFamily: "IBM Plex Serif",
                fontSize: "24px",
                fontStyle: "normal",
                fontWeight: "400",
                lineHeight: "normal",
                textTransform: "capitalize",
                paddingBottom: "12px",
              }}
            >
              Billing Information
            </Typography>
            <CloseIcon />
          </Grid>
          <Grid container spacing={2}>
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                First name
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="first_name"
                value={inputData.first_name}
                onChange={handleData}
              />
            </Grid>
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Last name
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="Last Name"
                name="last_name"
                value={inputData.last_name}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Email ID (at work)*
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="Email"
                name="email_id_at_work"
                value={inputData.email_id_at_work}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Company / Organization
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="company"
                value={inputData.company}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Website URL
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="website_url"
                value={inputData.website_url}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Office Phone*
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="office_phone"
                value={inputData.office_phone}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Contact Address*
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="Contact Address*"
                name="contact_address"
                value={inputData.contact_address}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Contact Address 2
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="Contact Address 2"
                name="contact_address_2"
                value={inputData.contact_address_2}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Contact Country*
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="contact_country"
                value={inputData.contact_country}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Contact City*
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="contact_city"
                value={inputData.contact_city}
                onChange={handleData}
              />
            </Grid>{" "}
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Contact zip code*
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="contact_zip_code"
                value={inputData.contact_zip_code}
                onChange={handleData}
              />
            </Grid>
            <Grid xs={6} item style={{ paddingTop: "25px" }}>
              <Typography
                variant="h3"
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                Contact State*
              </Typography>

              <TextField
                type="text"
                fullWidth
                size="medium"
                placeholder="First name"
                name="contact_state"
                value={inputData.contact_state}
                onChange={handleData}
              />
            </Grid>
            <Grid xs={12} item style={{ paddingTop: "25px" }}>
              <Typography
                style={{
                  color: "#000",
                  fontFamily: "Roboto,sans-serif",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                  textTransform: "capitalize",
                  paddingBottom: "6px",
                }}
              >
                * All fields are required'
              </Typography>
            </Grid>
            <Grid xs={12} item style={{ paddingTop: "25px" }}>
              {" "}
              <FormControlLabel
                control={
                  <StyledCheckbox
                   
                 
                  />
                }
                label="Same billing information"
                style={{ color: "#000" }}
              />
            </Grid>
            <Grid xs={12} item style={{ paddingTop: "25px" }}>
              <Button
                onClick={handleDataSubmit}
                variant="contained"
                color="secondary"
                type="submit"
                fullWidth
                sx={{
                  width: {
                    lg: "118px",
                    fontSize: "16px",
                    textTransform: "capitalize",
                  },
                }}
              >
                Submit
              </Button>
              <Button
                type="submit"
                onClick={closeModal}
                fullWidth
                sx={{
                  width: "118px",
                  fontSize: "14px",
                  textTransform: "capitalize",
                  marginRight: "22px",
                  backgroundColor: "transparent",
                  border: "1px solid #9C27B5",
                  color: "#9C27B5",
                  marginLeft: "29px",
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Card>
    </>
  );
};
export default BillingModal;
