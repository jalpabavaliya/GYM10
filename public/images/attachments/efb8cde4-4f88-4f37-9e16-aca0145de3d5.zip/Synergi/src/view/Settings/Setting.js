import React from 'react'
import SettingFront from './SettingFront'
import { Grid } from '@mui/material'

function Setting() {
  return (
    <div>
         <Grid
        sx={{
          bgcolor: "#FFFFFF",
       
          borderRadius: 2,
         
          border: " 1px solid #EBE8F1",
        }}
      >
        <section
          style={{
            display: "flex",
            flexDirection: "column",
            rowGap: "1rem",
         
           
          }}
        >
          <SettingFront />
        </section>
      </Grid>
    </div>
  )
}

export default Setting