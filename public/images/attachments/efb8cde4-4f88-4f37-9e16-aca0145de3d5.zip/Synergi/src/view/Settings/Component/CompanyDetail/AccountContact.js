import React, { useEffect, useState } from "react";

import {
  Table,
  CircularProgress,
  TableCell,
  TableContainer,
  TableRow,
  Typography,
  TableBody,
  TableHead,
  Button,
} from "@mui/material";
import axios from "axios";
import Modal from "./Component/AccountContactModal";
function AccountContact() {
  let accessToken = localStorage.getItem("accessToken");
  

  const [data, setdata] = useState(null);
  const [showModal , setShowModal]=useState(false);

  const closeModal = () => setShowModal(false);

  useEffect(() => {
    const headers = { Authorization: `Bearer ${accessToken}` };
    axios
      .get(
        " https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/settings_get_company_details",
        { headers }
      )
      .then((response) => {
        console.log(response);
        // console.log("Access Token", JSON.stringify(accessToken));
        setdata(response.data);
      });
  }, []);

  
  return (
    <div>
      {data ? (
        <TableContainer>
          <Table sx={{ width: "650px", marginBottom: "25px" }} size="small">
            <TableBody sx={{ borderTop: "1px solid rgba(224, 224, 224, 1)" }}>
              <TableRow>
                <TableCell>Contact name</TableCell>
                <TableCell>
                  {data.primary_account_details.first_name}
                  {data.primary_account_details.last_name}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Company / Organization</TableCell>
                <TableCell>
                  <Typography>
                    {data.primary_account_details.company}
                  </Typography>
                  <Typography>
                    {data.primary_account_details.website_url}
                  </Typography>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Address</TableCell>
                <TableCell>
                  <Typography>
                    {data.primary_account_details.contact_address}
                  </Typography>
                  <Typography>
                    {data.primary_account_details.contact_city},
                    {data.primary_account_details.contact_zip_code}
                  </Typography>
                  <Typography>
                    {data.primary_account_details.contact_country}
                  </Typography>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Phone</TableCell>
                <TableCell>
                  <Typography>
                    {data.primary_account_details.office_phone}
                  </Typography>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Email</TableCell>
                <TableCell>
                  <Typography>
                    {data.primary_account_details.email_id_at_work}
                  </Typography>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Tax Id</TableCell>
                <TableCell>
                  <Typography>
                    {data.primary_account_details.email_id_at_work}
                  </Typography>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
          <Button
            type="submit"
            fullWidth
            onClick={()=>setShowModal(true)}
            sx={{
              width: "204px",
              fontSize: "14px",
              textTransform: "capitalize",
              marginRight: "22px",
              backgroundColor: "transparent",
              border: "1px solid #9C27B5",
              color: "#9C27B5",
            }}
          >
            Edit Contact Information
          </Button>
          {showModal && <Modal closeModal={closeModal}/>}
        </TableContainer>
      ) : (
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: "32px",
          }}
        >
          <CircularProgress color="secondary" />
        </div>
      )}
    </div>
  );
}

export default AccountContact;
