import { Button, Grid, Typography } from "@mui/material";
import React from "react";

function User() {
  return (
    <div>
      <Typography
        style={{
          color: "#414446",
          fontFamily: "IBM Plex Serif",
          fontSize: "24px",
          fontStyle: "normal",
          fontWeight: "400",
          lineHeight: "normal",
          textTransform: "capitalize",
          paddingBottom: "12px",
          marginTop: "25px",
        }}
      >
        Users
      </Typography>

      <Grid style={{ display: "flex", justifyContent: "space-between" }}>
        <Typography
          style={{
            color: "#000",
            fontFamily: "Roboto",
            fontSize: "18px",
            fontStyle: "normal",
            fontWeight: "600",
            lineHeight: "normal",
            textTransform: "capitalize",
          }}
        >
          Users in Avanara
        </Typography>

        <Button
          variant="contained"
          color="secondary"
          type="submit"
          fullWidth
          sx={{
            width: {
              lg: "123px",
              fontSize: "14px",
              textTransform: "capitalize",
            },
          }}
        >
          Invite a user
        </Button>
      </Grid>
      <Grid container>
        <Grid item lg={9}></Grid>
        <Grid item lg={3} style={{display:"flex",justifyContent:"flex-end"}}>
          <Button
           
         
            type="submit"
            fullWidth
            sx={{
              width: {
                lg: "63px",
              },
              fontSize: "14px",
              textTransform: "capitalize",
              marginRight: "22px",
              backgroundColor:"transparent",
              border:"1px solid #9C27B5",
              color:"#9C27B5"
              
            }}
          >
            Edit
          </Button>
          <Button
            variant="contained"
            color="secondary"
            type="submit"
            fullWidth
            sx={{
              width: {
                lg: "134px",
                fontSize: "14px",
                textTransform: "capitalize",
              },
            }}
          >
            Revoke access
          </Button>
        </Grid>
      </Grid>
    </div>
  );
}

export default User;
