import { Backdrop, Box, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import DropDown from "../DropDown";
import {
  getHistoricalEventData,
  getTopPerformingKPI,
} from "../../../../services/OffersService";
import { offersActions } from "../../../../store/slices/offers";
import { useDispatch, useSelector } from "react-redux";
import Search from "../../../AllCampaigns/Search/Search";
import { CustomPaidSearchIcon } from "../../../Utils/icons/icons";

const { setOfferList } = offersActions;

const performanceFilterOptions = [
  {
    label: "By Top Performing",
    value: "by_top_performing",
  },
  {
    label: "Channels",
    options: [
      {
        label: "Direct Mail",
        value: "direct_mail",
      },
      { label: "Email", value: "email" },
      { label: "Telemarketing", value: "telemarketing" },
      { label: "SMS", value: "sms" },
      { label: "Social Media", value: "social_media" },
      { label: "Paid Search", value: "paid_search" },
      { label: "Paid Display", value: "paid_display" },
    ],
  },
  {
    label: "Unused",
    value: "unused",
  },
];

const timeFrameOptions = [
  {
    label: "By Time Frame",
    options: [
      {
        label: "Recent",
        value: "recent",
      },
      {
        label: "Past 30 Days",
        value: "before_30_days",
      },
      {
        label: "Past 90 Days",
        value: "before_90_days",
      },
      {
        label: "Past 120 Days",
        value: "before_120_days",
      },
      {
        label: "Archived",
        value: "archived",
      },
    ],
  },
];

const FilterAndSearch = ({ setDisplayDataList }) => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [byTopPerforming, setByTopPerforming] = useState({
    label: "By Top Performing",
    value: "by-top-performing",
  });
  const [byTimeFrame, setByTimeFrame] = useState({
    label: "Recent",
    value: "recent",
  });

  const { offerList } = useSelector((state) => state.offers);

  const handleOnTopPerformingChange = async (option) => {
    setIsLoading(true);
    setByTopPerforming(option);
    if (option.label === "By Top Performing") {
      const response = await getTopPerformingKPI();
      if (response.status === 200) {
        dispatch(setOfferList({ offerList: response.data }));
      } else {
        window.alert("error while fetching Top Performing KPI");
      }
    }
    setIsLoading(false);
  };

  const handleByTimeFrameChange = async (option) => {
    setIsLoading(true);
    setByTimeFrame(option);
    const response = await getHistoricalEventData(option.label);
    if (response.status === 200) {
      dispatch(setOfferList({ offerList: response.data }));
    } else {
      window.alert("error while fetching By Time Frame");
    }
    setIsLoading(false);
  };

  useEffect(() => {
    handleByTimeFrameChange({
      label: "Recent",
      value: "recent",
    });
  }, []);

  return (
    <Box
      sx={{
        display: "flex",
        width: "100%",
        alignItems: "center",
        gap: "1rem",
        paddingBottom: "1rem",
        borderBottom: "1px solid #ebe8f1",
      }}
    >
      <DropDown
        defaultValue={byTopPerforming}
        options={performanceFilterOptions}
        value={byTopPerforming}
        handleChange={handleOnTopPerformingChange}
      />
      <DropDown
        defaultValue={byTimeFrame}
        options={timeFrameOptions}
        value={byTimeFrame}
        handleChange={handleByTimeFrameChange}
      />
      <Search
        data={offerList}
        onSearchResult={(results) => {
          setDisplayDataList(results);
        }}
        style={{ marginLeft: "10px" }}
        CustomIcon={<CustomPaidSearchIcon />}
      />
      <Backdrop open={isLoading} sx={{ zIndex: 999999 }}>
        <CircularProgress color="inherit" />
      </Backdrop>
    </Box>
  );
};

export default FilterAndSearch;
