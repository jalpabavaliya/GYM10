import {
  Box,
  FormControl,
  Grid,
  IconButton,
  MenuItem,
  Select,
  Typography,
} from "@mui/material";
import React from "react";
import AddIcon from "../../assets/Add.svg";
import DeleteIcon from "../../assets/Delete.svg";
import { useState } from "react";

const AddConditionBox = () => {
  const [age, setAge] = useState("Select");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <Box
      sx={{
        p: 2,
        borderRadius: "5px",
        border: "1px solid #EBE8F1",
        background: "#FFF",
      }}
    >
      <Grid container justifyContent="space-between">
        <Grid item>
          <Typography
            sx={{
              color: "var(--col-8, #000)",
              fontFamily: "Roboto",
              fontSize: "18px",
              fontStyle: "normal",
              fontWeight: 600,
              lineHeight: "normal",
              textTransform: "capitalize",
            }}
          >
            Term Reduction
          </Typography>
        </Grid>
        <Grid item>
          <IconButton>
            <img src={AddIcon} alt="add" />
          </IconButton>
          <IconButton>
            <img src={DeleteIcon} alt="add" />
          </IconButton>
        </Grid>
      </Grid>
      <Grid container justifyContent="flex-start">
        <Grid item>
          <FormControl>
            <Select
              id="column-select"
              value={age}
              size="small"
              onChange={handleChange}
              sx={{
                borderRadius: "6px",
                border: "1px solid #EBE8F1",
                background: "#FFF",
                width: 200,
                height: 35,
              }}
            >
              <MenuItem value={10}>Is Empty</MenuItem>
              <MenuItem value={20}>Is Not Empty</MenuItem>
              <MenuItem value={30}>Is Null</MenuItem>
              <MenuItem value={40}>Is Not Null</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AddConditionBox;
