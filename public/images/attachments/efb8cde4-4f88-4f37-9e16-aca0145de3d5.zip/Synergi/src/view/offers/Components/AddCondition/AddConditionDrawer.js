import React from "react";
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";
import {
  Box,
  Divider,
  Drawer,
  Grid,
  IconButton,
  List,
  ListItemButton,
  ListItemText,
  Typography,
} from "@mui/material";
import { SearchBar } from "../../../Campaigns/Components/Utils/Search/Search";

const DRAWER_WIDTH = 240;

const COLUMN_LIST = [
  "First Name",
  "Last Name",
  "Full Name",
  "Date",
  "Age",
  "Mobile No.",
  "Birth_Date",
  "City",
  "Address",
  "Pin Code",
  "District",
];

const AddConditionDrawer = ({ isDrawerOpen, handleDrawerClose }) => {
  const handleColumnClick = (column) => {};

  return (
    <Box
      sx={{
        background: "#F6F5F8",
        width: DRAWER_WIDTH,
        flexShrink: 0,
        "& .MuiDrawer-paper": {
          width: DRAWER_WIDTH,
          boxSizing: "border-box",
        },
      }}
      //   variant="persistent"
      //   anchor="left"
      //   open={isDrawerOpen}
      //   onClose={handleDrawerClose}
    >
      {/* <Box sx={{ display: "flex", justifyContent: "flex-end", p: 0.5 }}>
        <IconButton
          onClick={handleDrawerClose}
          sx={{ width: "12px", height: "12px" }}
        >
          <CloseOutlinedIcon />
        </IconButton>
      </Box> */}
      <Grid
        container
        direction="column"
        justifyContent="flex-start"
        alignItems="flex-start"
        spacing={1}
        sx={{ px: 5 }}
      >
        <Grid item sx={{ mt: 3 }}>
          <Typography
            style={{
              color: "var(--col-6, #000)",
              fontFamily: "Roboto",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: "600",
              lineHeight: "normal",
            }}
          >
            Select Offer Type
          </Typography>
        </Grid>
        <Grid item>
          <Divider light />
        </Grid>
        <Grid item>
          <SearchBar />
        </Grid>
        <Grid item>
          <List
            sx={{
              width: "100%",
              maxWidth: 360,
              bgcolor: "#F6F5F8",
            }}
            component="nav"
          >
            {Array.isArray(COLUMN_LIST) &&
              COLUMN_LIST.length > 0 &&
              COLUMN_LIST.map((column, index) => (
                <ListItemButton
                  key={index}
                  onClick={() => handleColumnClick(column)}
                  sx={{
                    paddingLeft: "0px !important",
                    paddingRight: "0px !important",
                    paddingBottom: "0px !important",
                    paddingTop: 1,
                    "&:hover": { bgcolor: "background.paper" },
                  }}
                >
                  <ListItemText
                    primary={column}
                    sx={{
                      color: "#A35BB1",
                      fontFamily: "Roboto",
                      fontSize: "14px",
                      fontStyle: "normal",
                      fontWeight: 400,
                      lineHeight: "231.188%",
                      textTransform: "capitalize",
                    }}
                  />
                </ListItemButton>
              ))}
          </List>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AddConditionDrawer;
