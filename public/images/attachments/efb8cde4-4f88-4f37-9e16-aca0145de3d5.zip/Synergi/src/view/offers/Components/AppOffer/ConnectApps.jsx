import { Button, Grid, TextField } from "@mui/material";
import React from "react";
import FilterHorizontal from "../../../assets/filterHorizontal.svg";
import Synergicon from "../../../assets/synergiIcon.svg";
import { LineWeight } from "@mui/icons-material";
import { SynergyIcon } from "../../../../Campaigns/Components/Utils/icons/icons";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";

const ConnectApps = () => {
  return (
    <div
      style={{
        backgroundColor: "#ffffff",
        width: "100%",
        height: "100%",
        borderRadius: "6px",
      }}
    >
      <div
        style={{
          borderBottom: "1px solid #EBE8F1",
        }}
      >
        <div
          style={{
            fontFamily: "IBM Flex serif",
            color: "#414446",
            fontSize: "24px",
            padding: "2rem 1rem",
          }}
        >
          Connected apps that powere your leads
        </div>
      </div>
      <section
        style={{
          padding: "2rem 1rem",
        }}
      >
        <span
          style={{
            fontFamily: "Roboto",
            fontSize: "14px",
            color: "#414446",
          }}
        >
          Discover new ways to save time and expand your reachwith these
          powerful apps & integrations.
        </span>

        <div
          style={{
            display: "flex",
            padding: "2rem 0",
            columnGap: "2rem",
          }}
        >
          <Button
            variant='outline'
            style={{
              fontFamily: "Roboto",
              fontStyle: "medium",
              fontSize: "12px",
              border: "2px solid #A35BB1",
              color: "#A35BB1",
              display: "flex",
              width: "fit-content",
              height: "2rem",
              alignItems: "center",
              padding: "1rem",
              gap: "10px",
              borderRadius: "3px",
            }}
          >
            <img className='icon' src={FilterHorizontal} alt='filter' />
            <span>By Channels</span>
          </Button>

          <div>
            <TextField
              id='app-integration-search'
              size='small'
              margin='none'
              variant='outlined'
              style={{}}
              InputProps={{
                style: {
                  height: "2.3rem",
                },
              }}
            />
          </div>
        </div>

        <div
          style={{
            display: "flex",
            border: "1px solid #D0B6D6",
            backgroundColor: "#EFE7EF",
            padding: "1rem",
            boxShadow: "0px 8px 20px 0px rgba(0, 0, 0, 0.06)",
            borderRadius: "6px",
            columnGap: "2rem",
          }}
        >
          <div
            style={{
              width: "55px",
              height: "55px",
              padding: "0.5rem 0",
            }}
          >
            <img src={Synergicon} alt='app' height='55px' width='55px' />
          </div>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              rowGap: "0.3rem",
              alignItems: "flex-start",
            }}
          >
            <div
              style={{
                color: "#414446",
                fontFamily: "IBM Plex Serif",
                fontSize: "24px",
                fontWeight: "600",
                lineHeight: "40px",
                textTransform: "capitalize",
              }}
            >
              Barn
            </div>
            <div
              style={{
                color: "#5D596C",
                fontFamily: "Roboto",
                fontSize: "14px",
                fontWeight: "400",
                width: "550px",
              }}
            >
              Experience optimal campaign outcomes with Barn - Synergi's
              recommended choice for data-rich insights.
            </div>
            <Button
              type='button'
              variant='text'
              style={{
                color: "#852598",
                fontFamily: "Roboto",
                fontSize: "14px",
                fontWeight: "600",
                textAlign: "start",
                width: "fit-content",
                padding: "0.5rem 0",
              }}
            >
              Connect
            </Button>
          </div>
        </div>

        <Grid container spacing={2} p='2rem 1rem' column={{ lg: 12 }} gap={2}>
          <Grid
            item
            lg={4}
            style={{
              borderRadius: "5px",
              border: "1px solid #E2DDED",
              background: "#ffffff",
              padding: "1rem",
              display: "flex",
              gap: "1rem",
            }}
          >
            <div
              style={{
                width: "55px",
                height: "55px",
                padding: "0.5rem 0",
              }}
            >
              <img src={Synergicon} alt='Adobe' height='55px' width='55px' />
            </div>
            <div>
              <div
                style={{
                  color: "#414446",
                  fontFamily: "IBM Plex Serif",
                  fontSize: "20px",
                  fontWeight: "bold",
                  lineHeight: "40px",
                  textTransform: "capitalize",
                }}
              >
                Adobe
              </div>
              <div
                style={{
                  color: "#414446",
                  fontFamily: "Roboto",
                  fontSize: "14px",
                  fontWeight: "medium",
                }}
              >
                Boost creative design and asset managment with Adobe.
              </div>
            </div>
          </Grid>
          <Grid
            item
            lg={4}
            style={{
              borderRadius: "5px",
              border: "1px solid #E2DDED",
              background: "#ffffff",
              padding: "1rem",
              display: "flex",
              gap: "1rem",
            }}
          >
            <div
              style={{
                width: "55px",
                height: "55px",
                padding: "0.5rem 0",
              }}
            >
              <img src={Synergicon} alt='Adobe' height='55px' width='55px' />
            </div>
            <div>
              <div
                style={{
                  color: "#414446",
                  fontFamily: "IBM Plex Serif",
                  fontSize: "20px",
                  fontWeight: "bold",
                  lineHeight: "40px",
                  textTransform: "capitalize",
                }}
              >
                Altair
              </div>
              <div
                style={{
                  color: "#414446",
                  fontFamily: "Roboto",
                  fontSize: "14px",
                  fontWeight: "medium",
                }}
              >
                Amplify targeting precision with Altair.
              </div>
            </div>
          </Grid>
          <Grid
            item
            lg={4}
            style={{
              borderRadius: "5px",
              border: "1px solid #E2DDED",
              background: "#ffffff",
              padding: "1rem",
              display: "flex",
              gap: "1rem",
            }}
          >
            <div
              style={{
                width: "55px",
                height: "55px",
                padding: "0.5rem 0",
              }}
            >
              <img src={Synergicon} alt='Adobe' height='55px' width='55px' />
            </div>
            <div>
              <div
                style={{
                  color: "#414446",
                  fontFamily: "IBM Plex Serif",
                  fontSize: "20px",
                  fontWeight: "bold",
                  lineHeight: "40px",
                  textTransform: "capitalize",
                }}
              >
                BK MSP
              </div>
              <div
                style={{
                  color: "#414446",
                  fontFamily: "Roboto",
                  fontSize: "14px",
                  fontWeight: "medium",
                }}
              >
                Enhance loan servicing and default management with BK MSP.
              </div>
            </div>
          </Grid>
        </Grid>
      </section>
    </div>
  );
};

export default ConnectApps;
