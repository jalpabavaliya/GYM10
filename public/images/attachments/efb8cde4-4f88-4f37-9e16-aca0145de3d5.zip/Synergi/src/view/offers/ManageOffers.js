import React, { useState, useEffect } from "react";
import Grid from "@mui/material/Grid";
import AppOffer from "./Components/AppOffer/AppOffer";
import SubHeader from "../../ui-components/pageHeaders/SubHeader";
import Header from "../../ui-components/pageHeaders/Header";
import Channel from "./Components/OffersChannel/OffersChannel";
import { Paper } from "@mui/material";

const ManageOffers = () => {
  const [selectedChannel, setChannel] = useState("Ai");
  const [selectedChannelData, setChannelData] = useState([]);
  const [isSelectedDataCorrect, setCorrect] = useState("Ai");

  return (
    <>
      <Paper
        sx={{
          backgroundColor: "#ffffff",
          width: "100%",
          height: "100%",
          borderRadius: "6px",
        }}
      >
        <AppOffer />
      </Paper>
      <Paper
        sx={{
          backgroundColor: "#ffffff",
          width: "100%",
          height: "100%",
          borderRadius: "6px",
          mb: 1
        }}
      >
        <Channel
          setChannel={setChannel}
          setChannelData={setChannelData}
          setCorrect={setCorrect}
        />
      </Paper>
    </>

    // <Grid container direction="column" sx={{ backgroundColor: "#FAF8F7" }}>
    //   <Grid item>
    //     <Header />
    //   </Grid>
    //   <Grid item sx={{ mt: "10px", mb: "5px" }}>
    //     <SubHeader title="Offers" />
    //   </Grid>
    //   <Grid item>
    //     <Grid container spacing={2}>
    //       <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}>
    //         <SideBar />
    //       </Grid>
    //       <Grid
    //         item
    //         xs={12}
    //         sm={8.6}
    //         md={8.6}
    //         lg={9.6}
    //         sx={{
    //           bgcolor: "background.paper",
    //           m: 2,
    //           borderRadius: 2,
    //         }}
    //       >
    //         <Grid container direction="column" spacing={1}>
    //           <Grid item xs={12}>
    //             <AppOffer />
    //           </Grid>
    //         </Grid>
    //       </Grid>
    //     </Grid>

    //     <Grid container spacing={2}>
    //       <Grid item xs={10} sm={2.5} md={2.5} lg={2.1}>
    //         {/* <SideBar /> */}
    //       </Grid>
    //       <Grid
    //         item
    //         xs={12}
    //         sm={8.6}
    //         md={8.6}
    //         lg={9.6}
    //         sx={{
    //           bgcolor: "background.paper",
    //           m: 2,
    //           borderRadius: 2,
    //         }}
    //       >
    //         <Grid container direction="column" spacing={1}>
    //           <Grid item xs={12}>
    //             <Channel
    //               setChannel={setChannel}
    //               setChannelData={setChannelData}
    //               setCorrect={setCorrect}
    //             />
    //           </Grid>
    //         </Grid>
    //       </Grid>
    //     </Grid>
    //   </Grid>
    //   <Grid item sx={{ paddingLeft: "35vh" }}>
    //     <MainFooter />
    //   </Grid>
    // </Grid>
  );
};

export default ManageOffers;
