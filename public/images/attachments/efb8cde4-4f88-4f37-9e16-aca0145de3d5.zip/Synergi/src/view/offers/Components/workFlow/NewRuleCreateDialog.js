import React, { useEffect } from "react";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import PropTypes from "prop-types";
import CreateWorkflowAutomation from "./CreateRuleSteps";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { addNewAutomation } from "../../../../store/actions/rulesAction";
import {
  Backdrop,
  Button,
  CircularProgress,
  DialogActions,
  Grid,
} from "@mui/material";
import { useState } from "react";
import { addOfferCondition } from "../../../../services/OffersService";
import { offersActions } from "../../../../store/slices/offers";
import ReviewOfferDialog from "../AddCondition/ReviewOfferDialog";

const { addOfferConditionDetails } = offersActions;

const NewRuleCreateDialog = ({  isOpen, handleClose, nextDailogue }) => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [isViewRuleDialog, setIsViewRuleDialog] = useState(false);
  const activeTriggerId = useSelector(
    (state) => state.workflowAutomation.activeTriggerId
  );
  const { waStepsInfo } = useSelector((state) => state.workflowAutomation);
  const { offerInfo } = useSelector((state) => state.offers);

  useEffect(() => {
    if (!activeTriggerId) {
      dispatch(addNewAutomation());
    }
  }, [activeTriggerId]);

  const handleSaveRules = async () => {
    setIsLoading(true);
    const offerAddConditionInfo = {
      offer_id: offerInfo?.offer_id,
      offer_name: offerInfo?.offer_name,
      offer_description: offerInfo?.offer_description,
      where_condition: waStepsInfo?.expression,
    };

    const response = await addOfferCondition(offerAddConditionInfo);
    if (response.status === 200) {
      handleClose(false);
      nextDailogue(true);
      dispatch(addOfferConditionDetails({ response: response.data.response }));
    } else {
      window.alert("error while add offer condition");
    }
    setIsLoading(false);
  };

  return (  
    <>
      {isViewRuleDialog && (
        <ReviewOfferDialog
          open={isViewRuleDialog}
          handleClose={(value) => setIsViewRuleDialog(value)}
        />
      )}

      <Dialog
        fullWidth
        maxWidth="lg"
        open={isOpen}
        onClose={handleClose}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle id="new-workflow-automation-dialog">
          {activeTriggerId ? "Edit Offer" : "Add New Offer"}
        </DialogTitle>
        <CreateWorkflowAutomation handleClose={handleClose} />
        <DialogActions>
          <Grid container justifyContent="center" alignItems="center">
            <Button
              type="submit"
              variant="contained"
              style={{
                color: "#FFF",
                textAlign: "center",
                fontFamily: "Roboto",
                fontSize: "16px",
                fontStyle: "normal",
                fontWeight: 600,
                lineHeight: "normal",
                textTransform: "capitalize",
                width: "10rem",
                height: "48px",
                borderRadius: "6px",
                background: "#852598",
              }}
              onClick={handleSaveRules}
            >
              Save
            </Button>
          </Grid>
        </DialogActions>
      </Dialog>
      <Backdrop open={isLoading} sx={{ zIndex: 999999 }}>
        <CircularProgress color="inherit" />
      </Backdrop>
    </>
  );
};

NewRuleCreateDialog.propTypes = {
  handleClose: PropTypes.func,
};

export default NewRuleCreateDialog;
