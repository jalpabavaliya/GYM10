import {
  Button,
  Divider,
  IconButton,
  TableCell,
  TableRow,
  Tooltip,
  Zoom,
} from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import "./IntegrateApp.css";
import ViewIcon from "../../assets/View.svg";
import CopyIcon from "../../assets/Copy.svg";
import DeleteIcon from "../../assets/Delete.svg";
import EditIcon from "../../assets/Edit.svg";
import ViewOfferDialog from "./ViewOfferDialog";
import moment from "moment-timezone";
import { deleteOffer } from "../../../../services/OffersService";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { offersActions } from "../../../../store/slices/offers";
import Data from "./Data";

const { setOfferList, setAICraftedClickedItems } = offersActions;

const ToolTipSelector = (type, dateTime, children) => {
  switch (type) {
    case "success":
      return (
        <Tooltip
          arrow
          placement="right"
          TransitionComponent={Zoom}
          followCursor={true}
          style={{
            backgroundColor: "#158C6F",
            borderColor: "2px solid #158C6F",
          }}
          title={
            <>
              <div>Integration Successful</div>
              <div>
                Connected To App Since {dateTime}. All Systems Functions
                Normally
              </div>
            </>
          }
        >
          {children}
        </Tooltip>
      );

    default:
  }
};

const AppNameCategoryConnection = ({
  created,
  offerData,
  popoverRef,
  popover,
  handlePopoverOpen,
  handlePopoverClose,
  setIsLoading
}) => {
  const dispatch = useDispatch();
  const { offerList } = useSelector((state) => state.offers);

  const handleDeleteOffer = async () => {
    setIsLoading(true);
    const payload = { event_id: offerData.sk };
    const responseData = await deleteOffer(payload);
    if (responseData.status === 200) {
      const newOfferList =
        offerList.length > 0 &&
        offerList.filter((offer) => offer.sk !== offerData.sk);
      dispatch(setOfferList({ offerList: newOfferList }));
      dispatch(setAICraftedClickedItems({ [offerData.sk]: false }));
    } else {
      window.alert("error while delete the offer");
    }
    setIsLoading(false);
  };

  const isButttonHidden = offerData?.total_run_campaigns === 0;
  return (
    <>
      <ViewOfferDialog
        popoverRef={popoverRef}
        popover={popover}
        handlePopoverClose={handlePopoverClose}
      />
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          fontFamily: "Roboto",
          lineHeight: 1.5,
          width: "100%",
        }}
      >
        {/* <ToolTipSelector type='success' dateTime=''> */}
        <span
          style={{
            color: "#852598",
            fontFamily: "Roboto",
            fontSize: "16px",
            fontStyle: "normal",
            fontWeight: 600,
            lineHeight: "normal",
            cursor: "pointer",
          }}
          onClick={(event) => handlePopoverOpen(event, offerData)}
        >
          {offerData?.name}
        </span>
        <ViewOfferDialog
          popoverRef={popoverRef}
          popover={popover}
          handlePopoverClose={handlePopoverClose}
        />

        <span
          style={{
            color: "var(--col-8, #112333)",
            fontFamily: "Roboto",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 400,
            lineHeight: "149.453%",
            marginTop: "10px",
          }}
        >
          {offerData?.description}
        </span>
        <span
          style={{
            color: "var(--col-12, #414446)",
            fontFamily: "Roboto",
            fontSize: "12px",
            fontStyle: "normal",
            fontWeight: 400,
            lineHeight: "173.7%",
          }}
        >
          {created}
        </span>
      </div>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          fontFamily: "Roboto",
          lineHeight: 1.5,
          width: "100%",
        }}
      >
        <IconButton
          title="View Offer"
          onClick={(event) => handlePopoverOpen(event, offerData)}
        >
          <img src={ViewIcon} alt="add" />
        </IconButton>
        <IconButton title="Copy Offer">
          <img src={CopyIcon} alt="add" />
        </IconButton>
        {isButttonHidden && (
          <>
            <Divider
              orientation="vertical"
              flexItem
              sx={{ mx: 1, my: 0.5, width: "10px" }}
            />
            <IconButton title="Delete Segment" onClick={handleDeleteOffer}>
              <img src={DeleteIcon} alt="add" />
            </IconButton>
            <IconButton title="Edit Segment">
              <img src={EditIcon} alt="add" />
            </IconButton>
          </>
        )}
      </div>
    </>
  );
};

const UsesCampaign = ({ totalCompaigns }) => (
  <div
    style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "flex",
      fontFamily: "Roboto",
      width: "100%",
    }}
  >
    <span style={{ color: "#5D596C" }}>Uses</span>
    <div
      style={{
        display: "flex",
        color: "#A35BB1",
        alignItems: "center",
        gap: "0.5rem",
      }}
    >
      <span style={{ fontFamily: "IBM Plex Serif", fontSize: "24px" }}>
        {totalCompaigns}
      </span>
      <span style={{ fontSize: "12px", fontWeight: "medium" }}>Campaigns</span>
    </div>
  </div>
);

const ConnectedAnalytics = ({ analytics }) => (
  <div
    style={{
      width: "100%",
      display: "flex",
      border: "2px solid #EBE8F1",
      backgroundColor: "#F6F5F8",
      gap: "1rem",
      padding: "0.5rem",
      borderRadius: "5px",
    }}
  >
    <div className="AnalyticsProperty">
      <span className="heading">Conversion</span>
      <span className="value">{analytics?.Engagement}</span>
    </div>
    <div className="AnalyticsProperty">
      <span className="heading">CPL</span>
      <span className="value">{analytics?.CAC}</span>
    </div>
    <div className="AnalyticsProperty">
      <span className="heading">CAC</span>
      <span className="value">{analytics?.CAC}</span>
    </div>
    <div className="AnalyticsProperty">
      <span className="heading">ROI</span>
      <span className="value">{analytics?.ROI}</span>
    </div>
  </div>
);

const IntegratedApp = ({ offerData, setIsLoading }) => {
  const [popover, setPopover] = useState({
    open: false,
    anchorEl: null,
    content: "",
  });

  const popoverRef = useRef();

  useEffect(() => {
    function handleClickOutside(event) {
      if (popoverRef.current && !popoverRef.current.contains(event.target)) {
        setPopover({ open: false, anchorEl: null, content: "" });
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [popover]);

  const handlePopoverOpen = (event, content) => {
    event.stopPropagation();
    event.preventDefault();
    setPopover({ open: true, anchorEl: event.currentTarget, content });
  };

  const handlePopoverClose = () => {
    setPopover({ open: false, anchorEl: null, content: "" });
  };

  const parsedDate = moment.tz(
    offerData?.created_datetime,
    "YYYY-MM-DD HH:mm:ss",
    "America/New_York"
  );
  const formattedDate = parsedDate.format("MM/DD/YY [at] hh:mma");
  const created = `Created by Synergi At ${formattedDate}`;
  return (
    <TableRow sx={{ height: "100%" }}>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem 0",
          width: "70%",
        }}
      >
        <AppNameCategoryConnection
          created={created}
          offerData={offerData}
          popoverRef={popoverRef}
          popover={popover}
          handlePopoverOpen={handlePopoverOpen}
          handlePopoverClose={handlePopoverClose}
          setIsLoading={setIsLoading}
        />
      </TableCell>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem 0",
          width: "8rem",
        }}
      >
        <UsesCampaign totalCompaigns={offerData?.total_run_campaigns} />
      </TableCell>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem 0",
          width: "8rem",
        }}
      >
        <Data value={offerData?.total_records} />
      </TableCell>
      <TableCell
        sx={{
          verticalAlign: "top",
          padding: "1rem",
          width: "16rem",
        }}
      >
        <ConnectedAnalytics analytics={offerData?.kpi} />
      </TableCell>
    </TableRow>
  );
};

export default IntegratedApp;
