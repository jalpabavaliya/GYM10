import { useState, useEffect } from "react";
import {
  Card,
  CardHeader,
  Checkbox,
  FormControlLabel,
  FormGroup,
  CardContent,
  Typography,
  CardActions,
  Button,
  Grid,
  IconButton,
  Backdrop,
  CircularProgress,
} from "@mui/material";
import { createAICraftedForOffer, getHistoricalEventData } from "../../../../../services/OffersService";
import LeftMoveIcon from "../../../assets/LeftMove.svg";
import RightMoveIcon from "../../../assets/RigthMove.svg";
import TruncatedDescription from "../../../../../ui-components/truncateTooltip/TruncateTooltip";
import { offersActions } from "../../../../../store/slices/offers";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";

const { setAICraftedClickedItems, setOfferList } = offersActions;

const AiCreatedOffers = ({ aiInput, setChannelData }) => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const { aICraftedClickedItems } = useSelector((state) => state.offers);

  const handleCreateAICrafted = async (event_id) => {
    setIsLoading(true);
    const payload = { event_id };
    const responseData = await createAICraftedForOffer(payload);

    if (responseData.status === 200) {
      window.alert("AI Crafted created successfully!");
      dispatch(setAICraftedClickedItems({ [event_id]: true }));
      setTimeout(async () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
        const response = await getHistoricalEventData("Recent");
      if (response.status === 200) {
          dispatch(setOfferList({ offerList: response.data }));
      } else {
        window.alert("error while fetching By Time Frame");
      }
      }, 100);
    } else {
      window.alert("error while creating AI Crafted");
    }
    setIsLoading(false);
  };

  return (
    <>
      {/* <Grid container justifyContent="flex-end" alignItems="flex-end">
        <Grid item>
          <IconButton title="Left Move">
            <img src={LeftMoveIcon} alt="left move" />
          </IconButton>
        </Grid>
        <Grid item>
          <IconButton title="Right Move">
            <img src={RightMoveIcon} alt="right move" />
          </IconButton>
        </Grid>
      </Grid> */}
      <div
        style={{
          display: "flex",
          width: "auto",
          gap: "15px",
        }}
      >
        {Array.isArray(aiInput) &&
          aiInput.length > 0 &&
          aiInput.map((item, index) => (
            <Card
              key={index}
              style={{
                width: "280px",
                height: "257px",
                flexShrink: "0",
                borderRadius: "5px",
                border: "1px solid #EBE8F1",
                background: "#FFF",
                boxShadow: "0px 8px 20px 0px rgba(0, 0, 0, 0.06)",
                padding: "10px",
              }}
            >
              <CardHeader
                title={item.title}
                sx={{
                  color: "var(--Col-8, #000)",
                  fontFamily: "Roboto",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: 600,
                  lineHeight: "151.188%",
                  textTransform: "capitalize",
                }}
              />
              <div className="customHR" style={{ margin: 0, padding: 0 }}></div>
              <CardContent style={{ paddingTop: "0px", height: 120 }}>
                <TruncatedDescription description={item.descritption} />
              </CardContent>
              <CardActions>
                <Button
                  sx={{
                    color: "var(--col-14, #A35BB1)",
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: "600",
                    textTransform: "capitalize",
                  }}
                  disabled={aICraftedClickedItems[item.sk]}
                  onClick={() => handleCreateAICrafted(item.sk)}
                >
                  Create
                </Button>
              </CardActions>
            </Card>
          ))}
      </div>
      <Backdrop open={isLoading} sx={{ zIndex: 999999 }}>
        <CircularProgress color="inherit" />
      </Backdrop>
    </>
  );
};

export default AiCreatedOffers;
