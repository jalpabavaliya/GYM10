import React, { useState } from "react";
import "./GlobalAnalytics.css";

const GlobalAnalytics = () => {
  const data = [
    {
      title: "Sales Pipeline",
      value: "$789M",
    },
    {
      title: "Conversion Rate",
      value: "34%",
    },
    {
      title: "Cost/Lead",
      value: "$23.56",
    },
    {
      title: "Lead Volume",
      value: "2526K",
    },

    {
      title: "ROI",
      value: "0.1812%",
    },
  ];

  const [anlayticsData, setAnalyticsData] = useState(data);

  return (
    <div style={{ display: "flex", direction: "row" }}>
      {anlayticsData.length &&
        anlayticsData.map((analytics) => (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              padding: "1rem 2rem",
            }}
          >
            <div
              style={{
                color: "#9853A6",
                fontFamily: "Roboto Condensed",
                fontSize: "0.8rem",
              }}
            >
              {analytics.title}
            </div>
            <div
              style={{
                color: "#414446",
                fontFamily: "IBM Plex Serif",
                fontSize: "1.5rem",
              }}
            >
              {analytics.value}
            </div>
          </div>
        ))}
    </div>
  );
};

export default GlobalAnalytics;
