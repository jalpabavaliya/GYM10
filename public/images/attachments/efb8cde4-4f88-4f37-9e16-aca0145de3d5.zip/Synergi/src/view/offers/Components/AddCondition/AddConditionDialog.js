import {
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  IconButton,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";
import AddConditionDrawer from "./AddConditionDrawer";
import AddConditionBox from "./AddConditionBox";
import ReviewSegmentDialog from "./ReviewSegmentDialog";

const AddConditionDialog = ({ open, handleClose }) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isReviewSegmentDialogOpen, setIsReviewSegmentDialogOpen] =
    useState(false);

  const handleDrawerOpen = () => {
    setIsDrawerOpen(true);
  };

  const handleDrawerClose = () => {
    setIsDrawerOpen(false);
  };

  const handleReviewSegmentDialog = () => {
    setIsReviewSegmentDialogOpen(true);
  };

  return (
    <Dialog
      fullWidth
      maxWidth="xl"
      open={open}
      onClose={handleClose}
      sx={{
        "& .MuiDialog-paper": {
          minHeight: "550px",
        },
      }}
    >
      {isReviewSegmentDialogOpen && (
        <ReviewSegmentDialog
          open={isReviewSegmentDialogOpen}
          handleClose={() => setIsReviewSegmentDialogOpen(false)}
        />
      )}
      <Grid container justifyContent="flex-start">
        <Grid>
          <AddConditionDrawer
            isDrawerOpen={isDrawerOpen}
            handleDrawerClose={handleDrawerClose}
          />
        </Grid>
        <Grid item xs={9.7}>
          <DialogTitle>
            <Grid container justifyContent="space-between">
              <Grid item>
                <Typography
                  sx={{
                    color: "#414446",
                    fontFamily: "IBM Plex Serif",
                    fontSize: "24px",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "40px",
                  }}
                >
                  Term Reduction
                </Typography>
              </Grid>
              <Grid item>
                <IconButton onClick={handleClose}>
                  <CloseOutlinedIcon />
                </IconButton>
              </Grid>
            </Grid>
          </DialogTitle>
          <DialogContent>
            <Grid container direction="column">
              <Grid item>
                <Typography
                  sx={{
                    color: "var(--col-12, #414446)",
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "173.7%",
                  }}
                >
                  Smarter Ownership Pathway; mortgage term based on your income,
                  expenses, and long-term financial goals.
                </Typography>
              </Grid>
              <Grid item>
                <Typography
                  sx={{
                    color: "var(--col-12, #414446)",
                    fontFamily: "Roboto",
                    fontSize: "14px",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "173.7%",
                  }}
                >
                  Find contacts that match Any of the following:
                </Typography>
              </Grid>
              <Grid item sx={{ pt: 2 }}>
                <AddConditionBox />
              </Grid>
              <Grid item>
                <Button
                  type="submit"
                  variant="outlined"
                  color="secondary"
                  sx={{
                    textAlign: "center",
                    fontFamily: "Roboto",
                    fontSize: "16px",
                    fontWeight: "600",
                    lineHeight: "normal",
                    textTransform: "capitalize",
                    width: "10rem",
                    height: "48px",
                    borderRadius: "6px",
                    marginTop: "2vh",
                  }}
                  onClick={handleDrawerOpen}
                >
                  Add Condition
                </Button>
              </Grid>
              <Grid item sx={{ pt: 5 }}>
                <Divider />
              </Grid>
              <Grid item sx={{ pt: 2 }}>
                <Button
                  type="submit"
                  variant="contained"
                  style={{
                    color: "#FFF",
                    textAlign: "center",
                    fontFamily: "Roboto",
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 600,
                    lineHeight: "normal",
                    textTransform: "capitalize",
                    width: "10rem",
                    height: "48px",
                    borderRadius: "6px",
                    background: "#852598",
                  }}
                  onClick={handleReviewSegmentDialog}
                >
                  Review Segment
                </Button>
              </Grid>
            </Grid>
          </DialogContent>
        </Grid>
      </Grid>
    </Dialog>
  );
};

export default AddConditionDialog;
