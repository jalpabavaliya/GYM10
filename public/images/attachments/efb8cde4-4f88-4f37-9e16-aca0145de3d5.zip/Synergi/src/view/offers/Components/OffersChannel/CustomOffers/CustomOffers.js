import {
  Backdrop,
  Button,
  CircularProgress,
  Grid,
  TextField,
  Typography,
} from "@mui/material";
import React from "react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import NewRuleCreateDialog from "../../workFlow/NewRuleCreateDialog";
import { addNewAutomation } from "../../../../../store/actions/rulesAction";
import {
  createOffer,
  getHistoricalEventData,
  getOfferConditionColumn,
} from "../../../../../services/OffersService";
import { offersActions } from "../../../../../store/slices/offers";
import ReviewOfferDialog from "../../AddCondition/ReviewOfferDialog";
import OfferCreateSuccessFullyDialog from "../../AddCondition/OfferCreateSuccessFullyDialog";

const { setCreateOfferDetails, setDataType, setOfferList } = offersActions;

const CustomOffers = () => {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [isNewRuleCreateOpen, setIsNewRuleCreateOpen] = useState(false);
  const [isReviewOfferOpen, setIsReviewOfferOpen] = useState(false);
  const [isOfferCreateSucessOpen, setIsOfferCreateSuccessOpen] =
    useState(false);
  const [offerName, setOfferName] = useState("");
  const [description, setDescription] = useState("");

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleOfferNameChange = (event) => {
    setOfferName(event.target.value);
  };

  const handleAddConditionDialog = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    const offerInfo = {
      offer_name: offerName,
      offer_description: description,
      event_type: "offer",
    };

    const responseData = await getOfferConditionColumn();
    if (responseData.status === 200) {
      dispatch(setDataType({ dataType: responseData.data }));
    } else {
      window.alert("error while geting dataType");
    }

    const response = await createOffer(offerInfo);
    if (response.status === 200) {
      setIsNewRuleCreateOpen(true);
      dispatch(addNewAutomation());
      dispatch(setCreateOfferDetails({ response: response.data.response }));
    } else {
      window.alert("error while creating offer");
    }
    setIsLoading(false);
  };

  return (
    <>
      <NewRuleCreateDialog
        isOpen={isNewRuleCreateOpen}
        handleClose={(value) => setIsNewRuleCreateOpen(value)}
        nextDailogue={(value) => setIsReviewOfferOpen(value)}
      />

      <ReviewOfferDialog
        isOpen={isReviewOfferOpen}
        handleClose={(value) => setIsReviewOfferOpen(value)}
        nextDailogue={(value) => setIsOfferCreateSuccessOpen(value)}
      />

      <OfferCreateSuccessFullyDialog
        isOpen={isOfferCreateSucessOpen}
        handleClose={(value) => setIsOfferCreateSuccessOpen(value)}
      />

      <Grid container justifyContent="flex-start" spacing={2}>
        <Grid item xs={12} md={12} sm={12} lg={12}>
          <Typography>All fields are required</Typography>
        </Grid>
        <Grid item xs={12} md={7} sm={7} lg={7}>
          <form>
            <Grid container spacing={3}>
              <Grid item xs={12} md={7} sm={7} lg={7}>
                <TextField
                  id="offerName"
                  type="text"
                  fullWidth
                  size="medium"
                  value={offerName}
                  placeholder="Enter offer name"
                  onChange={handleOfferNameChange}
                />
              </Grid>

              <Grid item xs={12} md={7} sm={7} lg={7}>
                <TextField
                  id="description"
                  type="text"
                  fullWidth
                  size="medium"
                  multiline
                  rows={4}
                  value={description}
                  placeholder="Breif description"
                  onChange={handleDescriptionChange}
                />
              </Grid>

              <Grid item xs={12} md={7} sm={7} lg={7}>
                <Typography>
                  Find contacts that match Any of the following:
                </Typography>
              </Grid>
              <Grid item xs={12} md={7} sm={7} lg={7}>
                <Button
                  type="submit"
                  variant="outlined"
                  color="secondary"
                  style={{
                    textAlign: "center",
                    fontFamily: "Roboto",
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 600,
                    lineHeight: "normal",
                    textTransform: "capitalize",
                    width: "10rem",
                    height: "48px",
                    borderRadius: "6px",
                  }}
                  onClick={(event) => handleAddConditionDialog(event)}
                >
                  Add Condition
                </Button>
              </Grid>
            </Grid>
          </form>
        </Grid>
        <Backdrop open={isLoading} sx={{ zIndex: 999999 }}>
          <CircularProgress color="inherit" />
        </Backdrop>
      </Grid>
    </>
  );
};

export default CustomOffers;
