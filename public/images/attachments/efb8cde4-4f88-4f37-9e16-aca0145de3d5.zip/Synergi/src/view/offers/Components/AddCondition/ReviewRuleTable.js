import { Table, TableBody } from '@mui/material';
import PropTypes from 'prop-types';
import React from 'react';
import { ExpressionReview } from './ExpressionReview';

const ReviewRuleTable = ({ expression }) => (
    <Table size="small">
        <TableBody>
            <ExpressionReview
                automation={{
                    expression
                }}
            />
        </TableBody>
    </Table>
);

export default ReviewRuleTable;