import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Utils as QbUtils } from '@react-awesome-query-builder/mui';
import { Grid, TableCell, TableRow } from '@mui/material';
import { getUserConfigWithSettings } from '../../../../store/actions/rulesAction';
import { Logic } from '../workFlow/ReadableExpression';

export const ExpressionReview = ({ automation }) => {
    const { industries, countries } = useSelector((state) => state.workflowAutomation);
    const [currConfig, setCurrConfig] = useState(null);
    const [logic, setLogic] = useState(null);

    useEffect(() => {
        const newConfig = getUserConfigWithSettings();
        const [immutableTree, ignoredPart] = QbUtils.loadFromSpel(automation.expression, newConfig);
        const JSON = QbUtils.getTree(immutableTree, newConfig);
        setLogic(JSON);
        setCurrConfig(newConfig);
        // console.log(expression);
    }, [automation]);

    if (logic === null) {
        return null;
    }

    return (
        <TableRow>
            <TableCell style={{ paddingBottom: 0, paddingTop: 0, borderBottom: 0 }} colSpan={5}>
                <Grid container direction="row" justifyContent="flex-start" alignItems="flex-start" sx={{ m: '5px' }}>
                    <Grid item xs={12}>
                        <Logic position="review" expression={logic} currConfig={currConfig} />
                    </Grid>
                </Grid>
            </TableCell>
        </TableRow>
    );
};
