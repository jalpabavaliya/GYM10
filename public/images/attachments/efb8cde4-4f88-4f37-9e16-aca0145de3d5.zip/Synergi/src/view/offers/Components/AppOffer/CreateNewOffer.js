import {
  Card,
  CardContent,
  CardHeader,
  DialogTitle,
  Divider,
  Grid,
  Typography,
} from "@mui/material";
import React from "react";

const AI_CRAFTED_OFFER_LIST = [
  "Payment Reduction",
  "Term Reduction",
  "Cash-Out",
  "Seccond Lien",
];

const CreateNewOffer = () => {
  return (
    <Grid
      item
      style={{
        backgroundColor: "#ffffff",
        width: "100%",
        height: "100%",
        borderRadius: "6px",
      }}
    >
      <Grid
        container
        justifyContent="flex-start"
        alignItems="flex-start"
        spacing={2}
        sx={{ px: 1 }}
      >
        <Grid item xs={12}>
          <Typography>Create New Offer</Typography>
        </Grid>
        <Grid item xs={8}>
          <Typography>
            Use Synergi AI to generate a new offer tailored to current market
            conditions and your data performance, or manually create a new offer
            to meet your unique needs.
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Card sx={{ width: "100%" }}>
            <DialogTitle>
              <span style={{ marginRight: "10px" }}>AI-Crafted Offers</span>
              <span>Custom offers</span>
              <Divider />
            </DialogTitle>
            <CardContent>
              <Grid
                container
                justifyContent="flex-start"
                alignItems="flex-start"
                spacing={2}
              >
                {Array.isArray(AI_CRAFTED_OFFER_LIST) &&
                  AI_CRAFTED_OFFER_LIST.length > 0 &&
                  AI_CRAFTED_OFFER_LIST.map((craftedOffer) => (
                    <Grid item>
                      <Card >
                        <DialogTitle>
                          <span>{craftedOffer}</span>
                          <Divider />
                        </DialogTitle>
                        <CardContent></CardContent>
                      </Card>
                    </Grid>
                  ))}
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default CreateNewOffer;
