import { Box, Grid, LinearProgress, Typography } from "@mui/material";
import React from "react";

import { ProgressBarComponent } from "@syncfusion/ej2-react-progressbar";
import jsonData from "./dashboard_data.json";

function PanelBodytitle() {
  const PanelHeaddata = jsonData["1D"].map((item) => ({
    stage_name: item.stage_name,
    present: item.present,
    forecast: item.forecast,
  }));

  const panelItem = jsonData["1D"][0].channel;

  return (
    <div>
      <Grid container spacing={2}>
        {PanelHeaddata.map((PanelHeaddata) => {
          return (
            <>
              <Grid
                item
                xs={2}
                style={{
                  backgroundColor: "#ccc9c957",
                  margin: "10px",
                  padding: "10px",
                }}
              >
                {panelItem.map((panelItem) => {
                  return (
                    <>
                      <Box
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography>{panelItem.name}</Typography>
                        <Typography>
                      
                          {panelItem.hover_data.values.map(
                            (value, valueIndex) => (
                              <li >
                              {value.value}
                              </li>
                            )
                          )}
                        </Typography>
                      </Box>
                    </>
                  );
                })}
              </Grid>
            </>
          );
        })}
      </Grid>
    </div>
  );
}

export default PanelBodytitle;
