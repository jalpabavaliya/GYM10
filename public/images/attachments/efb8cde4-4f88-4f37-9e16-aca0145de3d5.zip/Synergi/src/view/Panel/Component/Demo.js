import React from "react";
import jsonData from "./dashboard_data.json";

function Demo() {
  const channelsData = jsonData["1D"][0].channel;

  return (
    <div>
      {channelsData.map((channel, index) => (
        <div key={index}>
          <h1>{channel.name}</h1>
          <ul>
            {channel.hover_data.values.map((value, valueIndex) => (
              <li key={valueIndex}>
                {value.title}: {value.value}
              </li>
            ))}
          </ul>
         
        </div>
      ))}
    </div>
  );
}

export default Demo;
