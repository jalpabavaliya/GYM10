import { Box } from '@mui/material'
import React from 'react'
import PanelHead from './Component/PanelHead'
import PanelBodytitle from './Component/PanelBodytitle'
import Demo from './Component/Demo'


function Panel() {
    const PanelData=[
        {
            mainTitle:"Responsive",
            num:"378%",
        },
        {
            mainTitle:"Responsive",
            num:"378%",
        },
        {
            mainTitle:"Responsive",
            num:"378%",
        },
        {
            mainTitle:"Responsive",
            num:"378%",
        }
    ]
  return (
    <div>
   
    <PanelHead />
    <PanelBodytitle/>
   <Demo/>
    </div>
  )
}

export default Panel