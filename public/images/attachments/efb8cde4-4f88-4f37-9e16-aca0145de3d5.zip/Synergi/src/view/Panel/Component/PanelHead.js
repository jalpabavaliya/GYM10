import { Box, Button, Grid, Typography } from "@mui/material";
import React from "react";
import jsonData from "./dashboard_data.json";
function PanelHead() {
  const PanelHeaddata = jsonData["1D"].map((item) => ({
    stage_name: item.stage_name,
    present: item.present,
    forecast: item.forecast,
  }));
  return (
    <div>
      <Grid container spacing={2}>
        {PanelHeaddata.map((data) => {
          return (
            <>
              <Grid
                item
                xs={2}
                style={{
                  backgroundColor: "#ccc9c957",
                  margin: "10px",
                  padding: "10px",
                }}
              >
                <Typography >{data.stage_name}</Typography>
                <Box style={{ display: "flex",alignItems:"flex-end" , borderBottom:"1px solid #E0DBE9",paddingBottom:"9px"}}>
                  <Typography
                    style={{
                      color: "#414446",
                      fontFamily: "IBM Plex Serif",
                      fontSize: "24px",
                      fontStyle: "normal",
                      fontWeight: " 400",
                      lineHeight: "normal",
                      textTransform: "capitalize",
                     
                    }}
                  >
                    {data.present}
                  </Typography>
                  <Typography 
                    style={{
                      color: "#000",
                      fontFamily: "Roboto",
                      fontSize: "14px",
                      fontStyle: "normal",
                      fontWeight: " 400",
                      lineHeight: "normal",
                      textTransform: "capitalize",
                    }}>Present</Typography>
                </Box>
                <Box style={{ display: "flex" ,alignItems:"flex-end",paddingTop:"9px"}}>
                  <Typography 
                   style={{
                      color: "#414446",
                      fontFamily: "IBM Plex Serif",
                      fontSize: "24px",
                      fontStyle: "normal",
                      fontWeight: " 400",
                      lineHeight: "normal",
                      textTransform: "capitalize",
                    }}>{data.forecast}</Typography>
                  <Typography
                   style={{
                      color: "#000",
                      fontFamily: "Roboto",
                      fontSize: "14px",
                      fontStyle: "normal",
                      fontWeight: " 400",
                      lineHeight: "normal",
                      textTransform: "capitalize",
                    }}
                  >Forecast</Typography>
                </Box>
              </Grid>
            </>
          );
        })}
      </Grid>
    </div>
  );
}

export default PanelHead;
