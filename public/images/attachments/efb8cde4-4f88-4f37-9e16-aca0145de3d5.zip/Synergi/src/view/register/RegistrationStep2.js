import React, { useState } from "react";
import {
  Button,
  Divider,
  Grid,
  Typography,
  Snackbar,
  Dialog,
  DialogTitle,
  DialogContentText,
  IconButton,
} from "@mui/material";
import MuiAlert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import { CognitoUser, CognitoUserPool } from "amazon-cognito-identity-js";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import OTPInput from "otp-input-react";
import RegisterSuccessIcon from "./assets/RegisterSuccessIcon.svg";
import RegistrationLoadedDialog2 from "./RegistrationLoadedDialog2";
import RegistrationLoadedDialog1 from "./RegistrationLoadedDialog1";
import RegistrationLoadedDialog3 from "./RegistrationLoadedDialog3";

const poolData = {
  UserPoolId: "us-east-1_lSBztqHit", // Your user pool id here
  ClientId: "3bcfutrtvoh4fn838l4a6qfl6v", // Your client id here
};

const userPool = new CognitoUserPool(poolData);

const RegistrationStep2 = ({ handleNext }) => {
  const navigate = useNavigate();

  const [OTP, setOTP] = useState("");
  const [message, setMessage] = useState("");
  const [open, setOpen] = useState(true);
  const [isLoading, setLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);
  const [currentDialog, setCurrentDialog] = useState(0);

  const registrationDetails = useSelector((state) => state.login);

  const userData = {
    Username: registrationDetails.registration.email, //"krupali2711@gmail.com", // // the user's email
    Pool: userPool,
  };

  const cognitoUser = new CognitoUser(userData);
  const handleSubmit = () => {
    const firstTimer = setTimeout(() => setCurrentDialog(1), 0);
    const secondTimer = setTimeout(() => setCurrentDialog(2), 10000);
    const thirdTimer = setTimeout(() => setCurrentDialog(3), 20000);

    cognitoUser.confirmRegistration(OTP, true, function (err, result) {
      // Clear all timers when response is received
      clearTimeout(firstTimer);
      clearTimeout(secondTimer);
      clearTimeout(thirdTimer);

      if (err) {
        alert(err.message || JSON.stringify(err));
        setCurrentDialog(0); // Reset dialog state if there's an error
        return;
      }

      // If successful, clear the current dialog and show the success dialog
      setCurrentDialog(0);
      setSuccessDialogOpen(true);
    });
  };

  const handleResendEmail = () => {
    cognitoUser.resendConfirmationCode((err, result) => {
      if (err) {
        alert(err.message || JSON.stringify(err));
        return;
      }
      // console.log("Confirmation code resent successfully");
      setMessage(
        "Confirmation code resent successfully. Please check your email"
      );
      setOpen(true);
    });
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };
  const closeSuccessDialog = () => {
    setSuccessDialogOpen(false);
    navigate("/login");
  };

  return (
    <>
      {currentDialog === 1 && <RegistrationLoadedDialog1 open={true} />}
      {currentDialog === 2 && <RegistrationLoadedDialog2 open={true} />}
      {currentDialog === 3 && <RegistrationLoadedDialog3 open={true} />}
      <Dialog
        alignContent="center"
        fullWidth
        maxWidth="md"
        open={successDialogOpen}
        onClose={closeSuccessDialog}
      >
        <DialogContentText>
          <Grid
            container
            direction="column"
            justifyContent="center"
            alignItems="center"
            spacing={3}
            sx={{ p: 5 }}
          >
            <Grid item>
              <IconButton>
                <img
                  src={RegisterSuccessIcon}
                  alt="left move"
                  width="150px"
                  height="150px"
                />
              </IconButton>
            </Grid>
            <Grid item>
              <Typography
                sx={{
                  color: "#132529",
                  textAlign: "center",
                  fontFamily: "IBM Plex Serif",
                  fontSize: "25px",
                  fontStyle: "normal",
                  fontWeight: 400,
                  lineHeight: "normal",
                  textTransform: "capitalize",
                }}
              >
                Registration Successfully <br /> Completed
              </Typography>
            </Grid>
            <Grid item>
              <Button
                type="submit"
                variant="contained"
                sx={{
                  color: "#ffffff",
                  fontFamily: "Roboto",
                  fontSize: "1rem",
                  fontWeight: "Bold",
                  textAlign: "center",
                  textTransform: "capitalize",
                  width: "17rem",
                  height: "48px",
                  borderRadius: "6px",
                  backgroundColor: "#852598",
                  ":hover": {
                    backgroundColor: "#852598",
                  },
                }}
                onClick={closeSuccessDialog}
              >
                Log in
              </Button>
            </Grid>
          </Grid>
        </DialogContentText>
      </Dialog>
      <Grid
        container
        direction="column"
        justifyContent="flex-start"
        alignItems="flex-start"
        spacing={2}
        sx={{ pl: "3%" }}
      >
        <Grid
          item
          xs={12}
          variant="h5"
          sx={{ mt: "4%", fontSize: "18px" }}
          style={{ paddingTop: "0px" }}
        >
          <Typography color="secondary">Welcome to Synergi!</Typography>
        </Grid>
        <Grid item xs={12} sx={{ mt: "10px" }} style={{ paddingTop: "0px" }}>
          <Typography
            variant="h5"
            sx={{
              fontSize: { lg: 28, md: 25, sm: 20, xs: 16 },
              color: "#132529",
              fontFamily: "IBM Plex Serif",
              fontSize: "28px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "38px" /* 135.714% */,
              textTransform: "capitalize",
            }}
          >
            Your SYNERGI account
          </Typography>
        </Grid>
        <Grid item xs={12} style={{ paddingTop: "0px" }}>
          <Typography
            variant="h5"
            sx={{
              fontSize: { lg: 28, md: 25, sm: 20, xs: 16 },
              color: "#132529",
              fontFamily: "IBM Plex Serif",
              fontSize: "28px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "38px" /* 135.714% */,
              textTransform: "capitalize",
            }}
          >
            is almost ready.
          </Typography>
        </Grid>
        <Grid item xs={12} sx={{ mt: "30px" }} style={{ paddingTop: "0px" }}>
          <Typography
            variant="body2"
            sx={{
              fontSize: "16px",
              color: "#112333",
              fontFamily: "Roboto",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
            }}
          >
            We've sent a verification code to your email (
            {registrationDetails.registration.email}) via email.
          </Typography>
        </Grid>
        <Grid item xs={12} sx={{ mt: "10px" }} style={{ paddingTop: "0px" }}>
          <Typography
            sx={{
              fontSize: "16px",
              color: "#112333",
              fontFamily: "Roboto",

              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "normal",
            }}
          >
            Please enter the code below to verify your identity and complete
            your registration.
          </Typography>
        </Grid>
        <Grid item xs={12} style={{ paddingTop: "0px" }}>
          <Typography sx={{ fontSize: { lg: 30, md: 25, sm: 20, xs: 16 } }}>
            Thank you for helping us keep your account secure.
          </Typography>
        </Grid>

        <Grid item xs={12} sx={{ mt: "5%" }} style={{ paddingTop: "0px" }}>
          <OTPInput
            value={OTP}
            onChange={setOTP}
            autoFocus
            OTPLength={6}
            otpType="number"
            disabled={false}
            secure
          />
        </Grid>
        <Grid item xs={12} sx={{ mt: "5%" }} style={{ paddingTop: "0px" }}>
          <Button
            variant="contained"
            onClick={handleSubmit}
            size="large"
            color="secondary"
            // disabled={isLoading}
          >
            Verify And Complete Registration
          </Button>
        </Grid>
        <Grid item xs={12} sx={{ mt: "4%" }} style={{ paddingTop: "0px" }}>
          <Grid container direction="row">
            <Grid item xs={12}>
              <Divider />
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12} sx={{ mb: "8%" }} style={{ paddingTop: "0px" }}>
          <Typography>
            Didn't receive an email yet? &nbsp;
            <Button color="secondary" onClick={handleResendEmail}>
              Resend Email
            </Button>
          </Typography>
        </Grid>

        <Snackbar
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          open={open}
          autoHideDuration={6000}
          onClose={handleClose}
        >
          <MuiAlert
            onClose={handleClose}
            severity="success"
            sx={{ width: "100%" }}
          >
            {message}
          </MuiAlert>
        </Snackbar>
      </Grid>
    </>
  );
};

export default RegistrationStep2;
