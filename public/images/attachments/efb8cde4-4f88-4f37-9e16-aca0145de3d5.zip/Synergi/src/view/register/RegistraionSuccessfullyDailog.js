// const { Dialog, DialogContentText, DialogTitle, Typography, Button } = require("@mui/material");

// const RegistrationSuccessfullyDailog = () => (
//   <Dialog open={successDialogOpen} onClose={closeSuccessDialog}>
//     <DialogTitle>Registration Successfully Completed</DialogTitle>
//     <DialogContentText>
//       <Typography>
//         Your registration has been successfully completed. Click the button
//         below to proceed to the login page.
//       </Typography>
//       <Button onClick={closeSuccessDialog} color="secondary">
//         Go to Login
//       </Button>
//     </DialogContentText>
//   </Dialog>
// );
