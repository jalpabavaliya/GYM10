import { Grid, Typography } from "@mui/material";

const MainBody = ({ children }) => {
  return (
    <>
      <Grid className="body-background">
        <Grid className="Grid">
          <Grid className="overlap">
            <img
              className="group"
              alt="Group"
              src="https://generation-sessions.s3.amazonaws.com/c2fdc9dc1907f3591108e718a8db0a65/img/group-1000005273.png"
              style={{width:"86vh",height:"85vh"}}
            />
            ;
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};
export default MainBody;
