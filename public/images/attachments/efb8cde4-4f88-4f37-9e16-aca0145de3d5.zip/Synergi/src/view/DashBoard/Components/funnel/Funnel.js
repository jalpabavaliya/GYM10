import React, { useRef, useEffect, useState } from 'react';
import './Funnel.css';
import { createEmbeddingContext } from 'amazon-quicksight-embedding-sdk';

const Funnel = () => {
  const dashboardRef = useRef(null);
  const [embeddingContext, setEmbeddingContext] = useState(null);

  useEffect(() => {
    const loadEmbeddingContext = async () => {
      try {
        const context = await createEmbeddingContext();
        setEmbeddingContext(context);
      } catch (error) {
        console.error("Error creating embedding context:", error);
      }
    };

    loadEmbeddingContext().catch(error => {
      console.error("Unhandled error in loadEmbeddingContext:", error);
    });

  }, []);

  useEffect(() => {
    if (!embeddingContext) return;

    const embedDashboard = async () => {
      try {
        const accessToken = localStorage.getItem('accessToken');
        if (!accessToken) {
          throw new Error('Access token not found in localStorage');
        }

        const response = await fetch("https://aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/dashboard_embed_url_v2", {
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        });

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }

        const data = await response.json();
        const options = {
          url: data.EmbedUrl,
          container: dashboardRef.current,
          height: "100%",
          width: "80%",
          borderRadius: "6px",
        };

        await embeddingContext.embedDashboard(options);
        // embeddedDashboard.navigateToDashboard('9edef6ac-0bcf-4231-a669-5c9582b176af', {});

      } catch (error) {
        console.error("Error embedding dashboard:", error);
      }
    };

    embedDashboard().catch(error => {
      console.error("Unhandled error in embedDashboard:", error);
    });

  }, [embeddingContext]);

  return (
    <div ref={dashboardRef} className="dashboard-embed" />
  );
}

export default Funnel;
