import React from 'react';
import Funnel from './Components/funnel/Funnel';
import { Paper } from '@mui/material';

const DashBoard = () => {
    return(<>
        <Paper
          sx={{
            backgroundColor: "#ffffff",
            width: "100%",
            height: "100%",
            borderRadius: "6px",
          }}
        >
          <Funnel />
        </Paper>
      </>);
};

export default DashBoard;