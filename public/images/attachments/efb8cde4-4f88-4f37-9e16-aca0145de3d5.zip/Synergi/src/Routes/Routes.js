// import Synergi from "./view/Synergi";
// import PrivateRoute from "./PrivateRoute"; // Import your PrivateRoute component

// const routes = [
//   { path: "/", title: "Home", element: <Synergi /> },
//   { path: "/login", title: "Login", element: <Synergi /> },
//   // ... other routes ...
//   {
//     path: "/app-integrations",
//     title: "App Integrations",
//     element: <PrivateRoute element={<AppIntergrations />} isAuthenticated={/* Your authentication check here */} />,
//   },
//   // ... other routes ...
// ];

// export default routes;