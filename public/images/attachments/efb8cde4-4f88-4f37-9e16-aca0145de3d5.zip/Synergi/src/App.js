import { Provider } from "react-redux";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Layout from "./layout/Layout";
import store from "./store";
import AllCampaigns from "./view/AllCampaigns/AllCampaigns";
import Campaigns from "./view/Campaigns/Campaigns";
import CustomizeDataSolution from "./view/DataIntelligence/CustomerData/ContactConfermation/CustomizeDataSolution";
import DataIntelligence from "./view/DataIntelligence/DataIntelligence";
import FileInputs from "./view/FileInputs/FileInputs";
import MarketingAutomation from "./view/Onboarding/MarketingAutomation/MarketingAutomation";
import OnBoardingStep1 from "./view/Onboarding/OnBoarding";
import Synergi from "./view/Synergi";
import AppIntergrations from "./view/integration/AppIntegrations";
import Exports from "./view/integration/Exports";
import Imports from "./view/integration/Imports";
import PasswordRecoverySteps from "./view/login/PasswordRecoverySteps";
import ManageOffers from "./view/offers/ManageOffers";
import ManageSegments from "./view/segments/ManageSegments";
import DashBoard from "./view/DashBoard/DashBoard";
import Setting from "./view/Settings/Setting";
import Panel from "./view/Panel/Panel";

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <Routes>
          <Route exact path='/' title='Home' element={<Synergi />} />
          <Route path='/login' title='Login' element={<Synergi />} />
          <Route
            path='/registration'
            title='Registration'
            element={<Synergi />}
          />
          <Route
            path='/password-recovery'
            title='PasswordRecovery'
            element={<PasswordRecoverySteps />}
          />
          <Route element={<Layout />}>
            <Route
              path='/OnBoarding'
              title='OnBoarding'
              element={<OnBoardingStep1 />}
            />
            <Route path='/upload' title='Upload' element={<FileInputs />} />
            <Route
              path='/new-campaign'
              title='New Campaign'
              element={<Campaigns />}
            />
            <Route
              path='/all-campaigns'
              title='All-Campaigns'
              element={<AllCampaigns />}
            />
            <Route path='/offers' title='Offers' element={<ManageOffers />} />
            <Route
              path='/segments'
              title='Segments'
              element={<ManageSegments />}
            />
            <Route
              path='/app-integrations'
              title='App Integrations'
              element={<AppIntergrations />}
            />
            <Route path='/imports' title='Imports' element={<Imports />} />
            <Route path='/exports' title='Exports' element={<Exports />} />
            <Route
              path='/CustmerDataintelligence'
              title='Custmer Data Intelligence'
              element={<DataIntelligence />}
            />
            <Route
              path='/CustomizeDataSolution'
              title='CustomizeDataSolution'
              element={<CustomizeDataSolution />}
            />
            <Route
              path='/MarketingAutomation'
              title='MarketingAutomation'
              element={<MarketingAutomation />}
            />
            <Route path='/funnel' title='Funnel' element={<DashBoard />} />
            <Route path="/Setting" element={<Setting />}/>
            <Route path="/Panel" element={<Panel />}/>
          </Route>
        </Routes>
      </BrowserRouter>
    </Provider>
  );
}

export default App;
