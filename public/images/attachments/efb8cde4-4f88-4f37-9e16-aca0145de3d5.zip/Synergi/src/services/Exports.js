import axios from "axios";

const prepareHeaders = () => {
  let accessToken = localStorage.getItem("accessToken");

  console.log("Access Token", JSON.stringify(accessToken));
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
};

export const getListOfFiles = async (baseUrl, parameter) => {
  try {
    const response = await axios({
      method: "get",
      headers: prepareHeaders().headers,
      url: baseUrl,
      params: {
        parameter,
      },
    });
    return response;
  } catch (error) {
    console.log("Error:", error.message);
    return error;
  }
};

export const downloadS3File = async (baseUrl, pk) => {
  try {
    const response = await axios({
      method: "get",
      headers: prepareHeaders().headers,
      url: baseUrl,
      params: {
        pk,
      },
    });
    return response;
  } catch (error) {
    console.log("Error:", error.message);
  }
};
