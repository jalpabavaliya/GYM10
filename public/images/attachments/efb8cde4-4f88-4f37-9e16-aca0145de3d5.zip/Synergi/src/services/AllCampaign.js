import axios from "axios";
import {
  GET_MANAGE_ALL_CAMPAIGN_API,
  POST_MANAGE_ALL_CAMPAIGN_API,
} from "../common/config";
const prepareHeaders = () => {
  var accessToken =
    "eyJraWQiOiJHcm1IMFZ3TzFGMTd3cTVKYzRPaTVHdkxWS0llU3V2NjJyQ1VFTmZoTVBzPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI5NzY0OTZhNi1iMzczLTRkYmEtYThiNi03ZGYyYjg1NjkyNmUiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9sU0J6dHFIaXQiLCJ2ZXJzaW9uIjoyLCJjbGllbnRfaWQiOiIzYmNmdXRydHZvaDRmbjgzOGw0YTZxZmw2diIsImV2ZW50X2lkIjoiMmNiNzAzZWQtYzIxMC00MWI3LWJkMGUtM2VkOTE1NDlhZWQwIiwidG9rZW5fdXNlIjoiYWNjZXNzIiwic2NvcGUiOiJvcGVuaWQiLCJhdXRoX3RpbWUiOjE2OTQwNzY4ODYsImV4cCI6MTY5NDE2MzI4NiwiaWF0IjoxNjk0MDc2ODg2LCJqdGkiOiI2MjNjOTQxOS01MWZkLTQ5YTUtYTMzOC1iODhiZTYyNjI4ZjYiLCJ1c2VybmFtZSI6Ijk3NjQ5NmE2LWIzNzMtNGRiYS1hOGI2LTdkZjJiODU2OTI2ZSJ9.JFiqxqgqEDy5zuxMQ8NMveGGTis4ZGFGmjZzAykMZh_RJSvMNTNZyN8S-DP02GVQTqWc3LN6KUttvwG4vsTPkks9J9PV_6U4iYFDdYQT-5YGNn9VIvGSDpoLwqmL-Ujn4Gr17bZ4YwFqHeJRYVNA3AruM794Ryqx6GniJpClXGPKEfwGf6NnJXlQ8LACaj-lVC3cxONYjHzwIJrSiaX2ZlP5nlOjD8c-3mnvRH0th-PWp4Zwlnze408kgPCj7SONqjVsPiQ3id0NwMtDUK-8u_hqZbWTqTQ9wA7zeQSuVJS9bx7aevIzlrWERGEi9ijDPpj3pHNWyLpsxbKmtmAYTw";
  // var accessToken = localStorage.getItem("accessToken");
  console.log("Access Token", JSON.stringify(accessToken));
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
};

export const getManageAllCampaign = async (parameter) => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_MANAGE_ALL_CAMPAIGN_API}?parameter=${parameter}`,
      headers: prepareHeaders().headers,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const postManageAllCampaign = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_MANAGE_ALL_CAMPAIGN_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};
