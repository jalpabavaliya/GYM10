import axios from "axios";
import {
  DELETE_SEGMENT_API,
  GET_AI_CRAFTED_SEGMENT_API,
  GET_SEGMENT_CONDITION_COLUMNS_API,
  GET_SEGMENT_HISTORICAL_EVENT_DATA_API,
  GET_TOP_PERFORMING_SEGMENT_API,
  POST_AI_CRAFTED_SEGMENT_CREATE_API,
  POST_CREATE_SEGMENT_API,
  POST_SEGMENT_CUSTOM_ADD_CONDITION_API,
} from "../common/config";

const prepareHeaders = () => {
  const accessToken = localStorage.getItem("accessToken");
  return {
    headers: { Authorization: `Bearer ${accessToken}` },
  };
};

export const createSegment = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_CREATE_SEGMENT_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const addSegmentCondition = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_SEGMENT_CUSTOM_ADD_CONDITION_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getTopPerformingKPI = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_TOP_PERFORMING_SEGMENT_API}`,
      headers: prepareHeaders().headers,
      params: {
        parameter: "CAC_segment",
      },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getHistoricalEventData = async (paramValue) => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_SEGMENT_HISTORICAL_EVENT_DATA_API}`,
      headers: prepareHeaders().headers,
      params: { parameter: "segment" },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getSegmentConditionColumn = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_SEGMENT_CONDITION_COLUMNS_API}`,
      headers: prepareHeaders().headers,
      params: {
        event_type: "segment",
      },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getAICraftedListForSegment = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_AI_CRAFTED_SEGMENT_API}`,
      headers: prepareHeaders().headers,
      params: {
        event_type: "segment",
      },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const createAICraftedForSegment = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_AI_CRAFTED_SEGMENT_CREATE_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const deleteSegment = async (payload) => {
  try {
    const response = await axios({
      method: "delete",
      url: `${DELETE_SEGMENT_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};
