import axios from "axios";
import {
  DELETE_OFFER_API,
  GET_AI_CRAFTED_OFFER_API,
  GET_OFFER_CONDITION_COLUMNS_API,
  GET_OFFER_HISTORICAL_EVENT_DATA_API,
  GET_TOP_PERFORMING_OFFER_API,
  POST_AI_CRAFTED_OFFER_CREATE_API,
  POST_CREATE_OFFER_API,
  POST_OFFER_CUSTOM_ADD_CONDITION_API,
  POST_OFFER_CUSTOM_UPDATE_ADD_START_END_TIME_API,
} from "../common/config";

const prepareHeaders = () => {
  const accessToken = localStorage.getItem("accessToken");
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
};

export const createOffer = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_CREATE_OFFER_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const addOfferCondition = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_OFFER_CUSTOM_ADD_CONDITION_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const saveOfferInfo = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_OFFER_CUSTOM_UPDATE_ADD_START_END_TIME_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getTopPerformingKPI = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_TOP_PERFORMING_OFFER_API}`,
      headers: prepareHeaders().headers,
      params: {
        parameter: "CAC_offer",
      },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getHistoricalEventData = async (paramValue) => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_OFFER_HISTORICAL_EVENT_DATA_API}`,
      headers: prepareHeaders().headers,
      params: { parameter: "offer" },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getOfferConditionColumn = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_OFFER_CONDITION_COLUMNS_API}`,
      headers: prepareHeaders().headers,
      params: {
        event_type: "offer",
      },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getAICraftedListForOffer = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_AI_CRAFTED_OFFER_API}`,
      headers: prepareHeaders().headers,
      params: {
        event_type: "offer",
      },
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const createAICraftedForOffer = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_AI_CRAFTED_OFFER_CREATE_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const deleteOffer = async (payload) => {
  try {
    const response = await axios({
      method: "delete",
      url: `${DELETE_OFFER_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

