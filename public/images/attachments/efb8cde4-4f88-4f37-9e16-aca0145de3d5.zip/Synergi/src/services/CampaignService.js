import axios from "axios";
import {
  POST_CREATE_CAMPAIGN_ID_API,
  GET_AI_API_WITH_KPI,
  GET_SEGMENT_AI_API,
  GET_SEGMENT_OFFER_API,
  GET_SUMMARY_SEGMENT_OFFER_API,
  GET_ABOUT_CAMPAIGN_API,
  GET_FINALIZE_AND_CONFIRM_API,
} from "../common/config";

const prepareHeaders = () => {
  var accessToken = localStorage.getItem("accessToken");
  console.log("Access Token", JSON.stringify(accessToken));

  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
};

export const getCampaignSummary = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${POST_CREATE_CAMPAIGN_ID_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getCampaignSummary2 = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${GET_SUMMARY_SEGMENT_OFFER_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getDataSourceAI = async (parameter) => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_AI_API_WITH_KPI}?parameter=${parameter}`,
      headers: prepareHeaders().headers,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getSegmentsManual = async (parameter) => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_AI_API_WITH_KPI}?parameter=${parameter}`,
      headers: prepareHeaders().headers,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getSegmentsAI = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_SEGMENT_AI_API}`,
      headers: prepareHeaders().headers,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getSegmentOffers = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_SEGMENT_OFFER_API}`,
      headers: prepareHeaders().headers,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getAboutCampaigns = async () => {
  try {
    const response = await axios({
      method: "get",
      url: `${GET_ABOUT_CAMPAIGN_API}`,
      headers: prepareHeaders().headers,
    });
    return response;
  } catch (e) {
    return e;
  }
};

export const getFinalizeAndConfirm = async (payload) => {
  try {
    const response = await axios({
      method: "post",
      url: `${GET_FINALIZE_AND_CONFIRM_API}`,
      headers: prepareHeaders().headers,
      data: payload,
    });
    return response;
  } catch (e) {
    return e;
  }
};
