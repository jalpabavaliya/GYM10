import axios from "axios";

const prepareHeaders = () => {
  let accessToken = localStorage.getItem("accessToken");
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
};

export const getAppIntegrations = async (baseUrl, parameter) => {
  try {
    const response = await axios({
      method: "get",
      headers: prepareHeaders().headers,
      url: baseUrl,
      params: {
        parameter,
      },
    });
    return response;
  } catch (error) {
    console.log("Error:", error.message);
    return error;
  }
};
