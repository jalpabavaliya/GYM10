import axios from "axios";
import {
  GET_HISTORICAL_EVENT_DATA,
  GET_IMPORTS,
  GET_TYPES_OF_UPLOAD,
  POST_DOCUMENT_UPDATE_WITH_SLECTED_CHANNELS,
  POST_FILE_TO_S3,
  POST_MAPPED_DOCUMENT,
} from "../common/config";
import { data } from "jquery";

const prepareHeaders = () => {
  const accessToken = localStorage.getItem("accessToken");
  console.log("Access Token", JSON.stringify(accessToken));
  return {
    headers: { 
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
};

export const getTypesOfUpload = async () => {
  try {
    const response = await axios({
      method: "get",
      url: GET_TYPES_OF_UPLOAD,
      headers: prepareHeaders().headers,
    });
    return response;
  } catch (error) {
    console.log("Error:", error.message);
    return error;
  }
};

export const getImports = async (baseUrl, parameter) => {
  try {
    const response = await axios({
      method: "get",
      headers: prepareHeaders().headers,
      url: baseUrl,
      params: {
        parameter,
      },
    });
    return response;
  } catch (error) {
    console.log("Error:", error.message);
    return error;
  }
};

/* TODO: Need Help while uploading the data */
export const uploadFile = async (file, filename, uploadType, description) => {
  try {
    const formData = new FormData();
    formData.append("content", file);
    formData.append("filename", filename);
    formData.append("server_table", uploadType);
    formData.append("file_description", description);

    const response = await axios({
      method: "post",
      url: POST_FILE_TO_S3,
      maxBodyLength: "Infinity",
      headers: {
        ...prepareHeaders().headers,
        "Content-Type": "multipart/form-data",
      },
      data: formData,
    });

    return response;
  } catch (error) {
    console.log(error.message);
    return error;
  }
};

export const mappedFields = async (documentId, mappedDocument) => {
  try {
    const response = await axios({
      method: "post",
      url: POST_MAPPED_DOCUMENT,
      headers: prepareHeaders().headers,
      data: {
        document_id: documentId,
        mapped_document: mappedDocument,
      },
    });
    return response;
  } catch (error) {
    console.log(error.message);
    return error;
  }
};

//aizbg0sdta.execute-api.us-east-1.amazonaws.com/v1/document_update_with_selected_channels

export const documentUpdateWithSelectedChannels = async (
  documentId,
  selectedChannles
) => {
  try {
    const resposne = await axios({
      method: "post",
      url: POST_DOCUMENT_UPDATE_WITH_SLECTED_CHANNELS,
      headers: prepareHeaders().headers,
      data: {
        document_id: documentId,
        selected_channels: selectedChannles,
      },
    });

    return resposne;
  } catch (error) {}
};
