import { Box, Typography } from "@mui/material";
import { toast } from "react-toastify";

const NotificationMessage = ({ title, message }) => {
  return (
    <Box sx={{ display: "flex", flexDirection: "column" }}>
      <Typography>{title}</Typography>
      <Typography>{message}</Typography>
    </Box>
  );
};

const notification = (type, title, message) => {
  const toastParams = {
    position: "top-right",
    autoClose: 10000,
    hideProgressBar: true,
    pauseOnHover: true,
    closeButton: true,
  };

  switch (type) {
    case "error":
      toast.error(
        <NotificationMessage title={title} message={message} />,
        toastParams
      );
      break;

    case "success":
    default:
      toast.success(
        <NotificationMessage title={title} message={message} />,
        toastParams
      );
      break;
  }
};

export default notification;
